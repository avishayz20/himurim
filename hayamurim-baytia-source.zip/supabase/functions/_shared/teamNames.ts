// Shared Hebrew team-name translation (extracted from fetch-matches)
export const teamNames: Record<string, string> = {
  // England
  "Arsenal FC": "ארסנל",
  "Aston Villa FC": "אסטון וילה",
  "Chelsea FC": "צ'לסי",
  "Everton FC": "אברטון",
  "Liverpool FC": "ליברפול",
  "Manchester City FC": "מנצ'סטר סיטי",
  "Manchester United FC": "מנצ'סטר יונייטד",
  "Newcastle United FC": "ניוקאסל",
  "Tottenham Hotspur FC": "טוטנהאם",
  "West Ham United FC": "ווסטהאם",
  "Brighton & Hove Albion FC": "ברייטון",
  "Wolverhampton Wanderers FC": "וולבס",
  "Crystal Palace FC": "קריסטל פאלאס",
  "Fulham FC": "פולהאם",
  "Brentford FC": "ברנטפורד",
  "Nottingham Forest FC": "נוטינגהאם פורסט",
  "AFC Bournemouth": "בורנמות'",
  "Ipswich Town FC": "איפסוויץ'",
  "Leicester City FC": "לסטר סיטי",
  "Southampton FC": "סאות'המפטון",
  // Spain
  "Real Madrid CF": "ריאל מדריד",
  "FC Barcelona": "ברצלונה",
  "Club Atlético de Madrid": "אתלטיקו מדריד",
  "Sevilla FC": "סביליה",
  "Real Sociedad de Fútbol": "ריאל סוסיאדד",
  "Real Betis Balompié": "ריאל בטיס",
  "Villarreal CF": "ויאריאל",
  "Athletic Club": "אתלטיק בילבאו",
  "Valencia CF": "ולנסיה",
  "Girona FC": "חירונה",
  // Germany
  "FC Bayern München": "באיירן מינכן",
  "Borussia Dortmund": "בורוסיה דורטמונד",
  "RB Leipzig": "לייפציג",
  "Bayer 04 Leverkusen": "באייר לברקוזן",
  "VfB Stuttgart": "שטוטגרט",
  "Eintracht Frankfurt": "איינטרכט פרנקפורט",
  "VfL Wolfsburg": "וולפסבורג",
  "Borussia Mönchengladbach": "מנשנגלדבאך",
  "SC Freiburg": "פרייבורג",
  // Italy
  "FC Internazionale Milano": "אינטר מילאן",
  "AC Milan": "מילאן",
  "Juventus FC": "יובנטוס",
  "SSC Napoli": "נאפולי",
  "AS Roma": "רומא",
  "SS Lazio": "לאציו",
  "Atalanta BC": "אטאלנטה",
  "ACF Fiorentina": "פיורנטינה",
  "Bologna FC 1909": "בולוניה",
  "Torino FC": "טורינו",
  // France
  "Paris Saint-Germain FC": "פריז סן ז'רמן",
  "Olympique de Marseille": "מרסיי",
  "AS Monaco FC": "מונאקו",
  "Olympique Lyonnais": "ליון",
  "LOSC Lille": "ליל",
  "RC Lens": "לאנס",
  "OGC Nice": "ניס",
  "Stade Rennais FC 1901": "רן",
  // Champions League extras
  "FC Porto": "פורטו",
  "SL Benfica": "בנפיקה",
  "Sport Lisboa e Benfica": "בנפיקה",
  "Sporting Clube de Portugal": "ספורטינג ליסבון",
  "AFC Ajax": "אייאקס",
  "PSV": "פ.ס.וו איינדהובן",
  "Feyenoord Rotterdam": "פייאנורד",
  "Club Brugge KV": "קלאב ברוז'",
  "Celtic FC": "סלטיק",
  "Rangers FC": "ריינג'רס",
  "FC Salzburg": "זלצבורג",
  "SK Sturm Graz": "שטורם גראץ",
  "Galatasaray SK": "גלאטסאראי",
  "Fenerbahçe SK": "פנרבאצ'ה",
  "FC Shakhtar Donetsk": "שחטר דונייצק",
  "FK Crvena Zvezda": "כוכב אדום בלגרד",
  "BSC Young Boys": "יאנג בויז",
  "FC København": "קופנהגן",
  "SK Slavia Praha": "סלאביה פראג",
  "AC Sparta Praha": "ספרטה פראג",
  "GNK Dinamo Zagreb": "דינמו זאגרב",
  "Stade Brestois 29": "ברסט",
  "FK Bodø/Glimt": "בודו/גלימט",
  "PAE Olympiakos SFP": "אולימפיאקוס",
  "Paphos FC": "פאפוס",
  "Royale Union Saint-Gilloise": "אוניון סן ז'ילואז",
  "Qarabağ Ağdam FK": "קאראבאג",
  "Maccabi Tel-Aviv FC": "מכבי תל אביב",
  // World Cup 2026 - National Teams
  "Argentina": "ארגנטינה",
  "Brazil": "ברזיל",
  "France": "צרפת",
  "Germany": "גרמניה",
  "Spain": "ספרד",
  "England": "אנגליה",
  "Portugal": "פורטוגל",
  "Netherlands": "הולנד",
  "Italy": "איטליה",
  "Belgium": "בלגיה",
  "Croatia": "קרואטיה",
  "Uruguay": "אורוגוואי",
  "Colombia": "קולומביה",
  "Mexico": "מקסיקו",
  "United States": "ארה\"ב",
  "Canada": "קנדה",
  "Japan": "יפן",
  "South Korea": "דרום קוריאה",
  "Australia": "אוסטרליה",
  "Saudi Arabia": "ערב הסעודית",
  "Iran": "איראן",
  "Morocco": "מרוקו",
  "Senegal": "סנגל",
  "Ghana": "גאנה",
  "Cameroon": "קמרון",
  "Nigeria": "ניגריה",
  "Tunisia": "תוניסיה",
  "Egypt": "מצרים",
  "Ecuador": "אקוואדור",
  "Chile": "צ'ילה",
  "Paraguay": "פרגוואי",
  "Peru": "פרו",
  "Venezuela": "ונצואלה",
  "Bolivia": "בוליביה",
  "Serbia": "סרביה",
  "Switzerland": "שווייץ",
  "Denmark": "דנמרק",
  "Austria": "אוסטריה",
  "Poland": "פולין",
  "Ukraine": "אוקראינה",
  "Sweden": "שוודיה",
  "Czech Republic": "צ'כיה",
  "Wales": "וויילס",
  "Scotland": "סקוטלנד",
  "Turkey": "טורקיה",
  "Greece": "יוון",
  "Romania": "רומניה",
  "Hungary": "הונגריה",
  "Norway": "נורווגיה",
  "Israel": "ישראל",
  "Costa Rica": "קוסטה ריקה",
  "Panama": "פנמה",
  "Honduras": "הונדורס",
  "Jamaica": "ג'מייקה",
  "Qatar": "קטאר",
  "Iraq": "עיראק",
  "Uzbekistan": "אוזבקיסטן",
  "China PR": "סין",
  "Indonesia": "אינדונזיה",
  "Algeria": "אלג'יריה",
  "Congo DR": "קונגו",
  "Mali": "מאלי",
  "Ivory Coast": "חוף השנהב",
  "South Africa": "דרום אפריקה",
  "New Zealand": "ניו זילנד",
  "Bosnia-Herzegovina": "בוסניה והרצגובינה",
  "Bosnia and Herzegovina": "בוסניה והרצגובינה",
  "Cape Verde": "כף ורדה",
  "Cape Verde Islands": "כף ורדה",
  "Curaçao": "קוראסאו",
  "Curacao": "קוראסאו",
  "Czechia": "צ'כיה",
  "Haiti": "האיטי",
  "Jordan": "ירדן",
  "Kairat Almaty FK": "קאיראט אלמטי",
  "Athletic Bilbao": "אתלטיק בילבאו",
  "Atalanta": "אטאלנטה",
  "SK Slovan Bratislava": "סלובאן ברטיסלאבה",
  "Sturm Graz": "שטורם גראץ",
  "Malmö FF": "מאלמה",
  "FC Red Bull Salzburg": "זלצבורג",
  "Red Bull Salzburg": "זלצבורג",
  "Bayer Leverkusen": "באייר לברקוזן",
  "1. FC Union Berlin": "אוניון ברלין",
  "1. FSV Mainz 05": "מיינץ",
  "1. FC Heidenheim 1846": "היידנהיים",
  "TSG 1899 Hoffenheim": "הופנהיים",
  "SV Werder Bremen": "ורדר ברמן",
  "FC Augsburg": "אאוגסבורג",
  "1. FC Köln": "קלן",
  "FC St. Pauli 1910": "סנט פאולי",
  "Hamburger SV": "המבורג",
  "Borussia Monchengladbach": "מנשנגלדבאך",
  "RCD Espanyol de Barcelona": "אספניול",
  "RC Celta de Vigo": "סלטה ויגו",
  "Rayo Vallecano de Madrid": "ראיו וייקאנו",
  "CA Osasuna": "אוססונה",
  "Getafe CF": "חטאפה",
  "RCD Mallorca": "מיורקה",
  "Deportivo Alavés": "אלאבס",
  "Elche CF": "אלצ'ה",
  "Levante UD": "לבאנטה",
  "Real Oviedo": "ריאל אוביידו",
  "Real Valladolid CF": "ריאל ויאדוליד",
  "UD Las Palmas": "לאס פלמאס",
  "Rayo Vallecano": "ראיו וייקאנו",
  "Sevilla": "סביליה",
  "Genoa CFC": "ג'נואה",
  "US Lecce": "לצ'ה",
  "Cagliari Calcio": "קליארי",
  "Udinese Calcio": "אודינזה",
  "Hellas Verona FC": "ורונה",
  "Parma Calcio 1913": "פארמה",
  "Como 1907": "קומו",
  "US Sassuolo Calcio": "ססואולו",
  "Pisa Sporting Club": "פיזה",
  "US Cremonese": "קרמונזה",
  "Empoli FC": "אמפולי",
  "Venezia FC": "ונציה",
  "AC Monza": "מונזה",
  "Stade de Reims": "ריימס",
  "FC Nantes": "נאנט",
  "Toulouse FC": "טולוז",
  "RC Strasbourg Alsace": "שטרסבורג",
  "Angers SCO": "אנז'ה",
  "AJ Auxerre": "אוסר",
  "Le Havre AC": "לה האבר",
  "FC Lorient": "לוריאן",
  "FC Metz": "מץ",
  "AS Saint-Étienne": "סנט אטיין",
  "Montpellier HSC": "מונפלייה",
  "Paris FC": "פריז FC",
  "Leeds United FC": "לידס יונייטד",
  "Burnley FC": "ברנלי",
  "Sunderland AFC": "סנדרלנד",
  "Sheffield United FC": "שפילד יונייטד",
  "Luton Town FC": "לוטון טאון",
  "Watford FC": "ווטפורד",
  "Norwich City FC": "נוריץ'",
  "SC Braga": "בראגה",
  "Vitória SC": "ויטוריה גימראש",
  "Olympiacos FC": "אולימפיאקוס",
  "PAOK": "פאוק סלוניקי",
  "AEK Athens FC": "איי.אי.קיי אתונה",
  "Panathinaikos FC": "פנאתינייקוס",
  "Beşiktaş JK": "בשיקטאש",
  "Trabzonspor": "טרבזונספור",
  "FC Basel 1893": "באזל",
  "BSC Young Boys Bern": "יאנג בויז",
  "FC Zürich": "ציריך",
  "Ferencvárosi TC": "פרנצווארוש",
  "Legia Warszawa": "לגיה ורשה",
  "Raków Częstochowa": "ראקוב",
  "Dynamo Kyiv": "דינמו קייב",
  "FC Dynamo Kyiv": "דינמו קייב",
  "FC Viktoria Plzeň": "ויקטוריה פלזן",
  "FC Midtjylland": "מידטילנד",
  "Brøndby IF": "ברונדבי",
  "Molde FK": "מולדה",
  "Rosenborg BK": "רוזנבורג",
  "IF Elfsborg": "אלפסבורג",
  "Djurgårdens IF": "דיורגורדן",
  "AZ": "אלקמאר",
  "FC Twente '65": "טוונטה",
  "FC Utrecht": "אוטרכט",
  "SC Heerenveen": "הרנפין",
  "KAA Gent": "חנט",
  "RSC Anderlecht": "אנדרלכט",
  "KRC Genk": "חנק",
  "Standard Liège": "סטנדרד ליאז'",
  "Servette FC": "סרווט",
  "Ludogorets 1945 Razgrad": "לודוגורץ",
  "Slovan Bratislava": "סלובאן ברטיסלאבה",
  "Maccabi Haifa FC": "מכבי חיפה",
  "Hapoel Beer Sheva": "הפועל באר שבע",
  "Beitar Jerusalem FC": "בית\u05f4ר ירושלים",
  "FK Kairat": "קאיראט אלמטי",
  "Kairat Almaty": "קאיראט אלמטי",
};

const CLUB_SUFFIX_RE = /\b(FC|CF|AFC|SC|AC|SV|CD|CA|SK|FK|BK|IF|KV|SL|SSC|SS|VfB|VfL|RC|RCD|US|UD|GNK|PAE|BSC|TC|JK|KAA|KRC|RSC|TSG|AS|AJ|SCO|HSC|LOSC|OGC|PSV|MSV|1\.)\b/gi;

function stripClubNoise(name: string): string {
  return name
    .replace(CLUB_SUFFIX_RE, " ")
    .replace(/\b(1[89]\d{2}|20\d{2})\b/g, " ")
    .replace(/\s{2,}/g, " ")
    .trim();
}

export function translateTeam(name: string): string {
  if (!name) return name;
  const raw = name.trim();
  if (teamNames[raw]) return teamNames[raw];

  // Try a few normalized variants before giving up
  const stripped = stripClubNoise(raw);
  if (teamNames[stripped]) return teamNames[stripped];

  const noDiacritics = raw.normalize("NFD").replace(/[\u0300-\u036f]/g, "");
  if (teamNames[noDiacritics]) return teamNames[noDiacritics];
  const strippedNoDia = stripClubNoise(noDiacritics);
  if (teamNames[strippedNoDia]) return teamNames[strippedNoDia];

  // Case-insensitive lookup across all keys (raw + stripped forms)
  const lower = raw.toLowerCase();
  const lowerStripped = stripped.toLowerCase();
  for (const [key, value] of Object.entries(teamNames)) {
    const k = key.toLowerCase();
    if (k === lower || k === lowerStripped) return value;
    const ks = stripClubNoise(key).toLowerCase();
    if (ks && (ks === lower || ks === lowerStripped)) return value;
  }

  // Partial match: dictionary key contained in the name or vice versa (e.g. "Nice" in "OGC Nice")
  let best = "";
  let bestLen = 0;
  for (const [key, value] of Object.entries(teamNames)) {
    const k = stripClubNoise(key).toLowerCase();
    if (k.length < 4) continue;
    if ((lowerStripped.includes(k) || k.includes(lowerStripped)) && k.length > bestLen) {
      best = value;
      bestLen = k.length;
    }
  }
  if (best) return best;

  // Last resort: transliterate to Hebrew letters so nothing stays in Latin script
  return transliterateToHebrew(stripped || raw);
}

const HEB_DIGRAPHS: Array<[RegExp, string]> = [
  [/sch/g, "ש"],
  [/sh/g, "ש"],
  [/ch/g, "צ'"],
  [/tsch/g, "צ'"],
  [/ts/g, "צ"],
  [/tz/g, "צ"],
  [/ph/g, "פ"],
  [/th/g, "ת"],
  [/qu/g, "קוו"],
  [/ck/g, "ק"],
  [/gh/g, "ג"],
  [/ll/g, "ל"],
  [/rr/g, "ר"],
  [/ss/g, "ס"],
  [/tt/g, "ט"],
  [/nn/g, "נ"],
  [/mm/g, "מ"],
  [/pp/g, "פ"],
  [/oo/g, "ו"],
  [/ee/g, "י"],
  [/ou/g, "ו"],
  [/au/g, "או"],
  [/ei/g, "יי"],
  [/ai/g, "אי"],
  [/ie/g, "י"],
  [/ya/g, "יא"],
  [/j/g, "ז'"],
];

const HEB_LETTERS: Record<string, string> = {
  a: "א", b: "ב", c: "ק", d: "ד", e: "", f: "פ", g: "ג", h: "ה", i: "י",
  k: "ק", l: "ל", m: "מ", n: "נ", o: "ו", p: "פ", q: "ק", r: "ר", s: "ס",
  t: "ט", u: "ו", v: "ו", w: "וו", x: "קס", y: "י", z: "ז",
};

function transliterateWord(word: string): string {
  let w = word.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
  w = w.replace(/[^a-z]/g, "");
  if (!w) return "";
  for (const [re, rep] of HEB_DIGRAPHS) w = w.replace(re, rep);
  let out = "";
  for (const ch of w) {
    if (/[\u0590-\u05FF']/.test(ch)) {
      out += ch;
      continue;
    }
    out += HEB_LETTERS[ch] ?? "";
  }
  // final letter forms
  out = out
    .replace(/מ$/, "ם")
    .replace(/נ$/, "ן")
    .replace(/צ$/, "ץ")
    .replace(/פ$/, "ף")
    .replace(/כ$/, "ך");
  return out;
}

function transliterateToHebrew(name: string): string {
  const words = name.split(/[\s\-.]+/).filter(Boolean);
  const parts = words.map(transliterateWord).filter(Boolean);
  return parts.length ? parts.join(" ") : name;
}

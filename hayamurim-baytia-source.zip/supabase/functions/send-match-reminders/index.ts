// @ts-nocheck
// Edge function: send-match-reminders
// Runs on a 1-minute cron. Sends web-push notifications to users who haven't
// placed a bet on matches starting in ~60 or ~10 minutes (Israel time).

import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import webpush from "https://esm.sh/web-push@3.6.7";

const VAPID_PUBLIC =
  "BKPLzldcF_fJt6cOM-mIrxJdVJSo0dqn_m3tHjP_PebJkno4LpcLby8mZClAl0IyiKavw8q0szTOw8bBqwsR1l4";
const VAPID_PRIVATE = "_yxeSyxZvHG-HQ6DDmTK9ThymPXn9XE68K1swe8POwA";
const VAPID_SUBJECT = "mailto:notify@himurim-biyatzia.app";

webpush.setVapidDetails(VAPID_SUBJECT, VAPID_PUBLIC, VAPID_PRIVATE);

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

// Build kickoff Date assuming Asia/Jerusalem local wall-clock
const israelKickoffToUtcMs = (dateStr: string, timeStr: string): number | null => {
  if (!dateStr || !timeStr) return null;
  const [y, mo, d] = dateStr.split("-").map(Number);
  const [h, mi] = timeStr.slice(0, 5).split(":").map(Number);
  if ([y, mo, d, h, mi].some((n) => Number.isNaN(n))) return null;

  // Determine Israel UTC offset (+2 or +3 with DST) for this date.
  // We compare a UTC timestamp to its formatted Asia/Jerusalem clock.
  const guessUtc = Date.UTC(y, mo - 1, d, h, mi);
  const fmt = new Intl.DateTimeFormat("en-CA", {
    timeZone: "Asia/Jerusalem",
    year: "numeric", month: "2-digit", day: "2-digit",
    hour: "2-digit", minute: "2-digit", hourCycle: "h23",
  });
  const parts = Object.fromEntries(
    fmt.formatToParts(new Date(guessUtc)).filter((p) => p.type !== "literal").map((p) => [p.type, p.value]),
  );
  const ilAsUtc = Date.UTC(
    Number(parts.year), Number(parts.month) - 1, Number(parts.day),
    Number(parts.hour), Number(parts.minute),
  );
  const offsetMs = ilAsUtc - guessUtc; // how much Israel clock is ahead of UTC
  return guessUtc - offsetMs;
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });

  const supabase = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
  );

  const nowMs = Date.now();
  const WINDOWS = [
    { minutes: 60, label: "המשחק מתחיל בעוד שעה" },
    { minutes: 10, label: "המשחק מתחיל בעוד 10 דקות" },
  ];

  // Pull upcoming matches in the next ~70 minutes
  const horizon = new Date(nowMs + 75 * 60 * 1000);
  const horizonDate = horizon.toISOString().slice(0, 10);
  const { data: matches, error: matchErr } = await supabase
    .from("matches")
    .select("id, home_team, away_team, match_date, match_time, is_finished")
    .eq("is_finished", false)
    .lte("match_date", horizonDate)
    .gte("match_date", new Date(nowMs - 24 * 60 * 60 * 1000).toISOString().slice(0, 10));

  if (matchErr) {
    console.error("matches query failed", matchErr);
    return new Response(JSON.stringify({ error: matchErr.message }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  const dueReminders: { match: any; offset: number; label: string }[] = [];
  for (const m of matches || []) {
    if (!m.match_time) continue;
    const kickoff = israelKickoffToUtcMs(m.match_date, m.match_time);
    if (kickoff === null) continue;
    for (const w of WINDOWS) {
      const target = kickoff - w.minutes * 60 * 1000;
      const diff = target - nowMs;
      // fire window: -120s..+30s around target (cron runs every 60s)
      if (diff <= 30 * 1000 && diff >= -120 * 1000) {
        dueReminders.push({ match: m, offset: w.minutes, label: w.label });
      }
    }
  }

  if (dueReminders.length === 0) {
    return new Response(JSON.stringify({ ok: true, due: 0 }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }

  // Load all push subscriptions and all bets for those matches
  const matchIds = [...new Set(dueReminders.map((r) => r.match.id))];
  const [{ data: subs }, { data: bets }, { data: profiles }] = await Promise.all([
    supabase.from("push_subscriptions").select("*"),
    supabase.from("bets").select("match_id, user_id").in("match_id", matchIds),
    supabase.from("profiles").select("id, is_frozen"),
  ]);

  const frozen = new Set((profiles || []).filter((p: any) => p.is_frozen).map((p: any) => p.id));
  const betKey = new Set((bets || []).map((b: any) => `${b.match_id}:${b.user_id}`));

  // Group subscriptions by user
  const subsByUser = new Map<string, any[]>();
  for (const s of subs || []) {
    const arr = subsByUser.get(s.user_id) || [];
    arr.push(s);
    subsByUser.set(s.user_id, arr);
  }

  let sent = 0;
  let skipped = 0;
  const removeEndpoints: string[] = [];

  for (const reminder of dueReminders) {
    for (const [userId, userSubs] of subsByUser) {
      if (frozen.has(userId)) continue;
      if (betKey.has(`${reminder.match.id}:${userId}`)) continue;

      // Dedup via match_reminder_log
      const { error: logErr } = await supabase.from("match_reminder_log").insert({
        match_id: reminder.match.id,
        user_id: userId,
        offset_minutes: reminder.offset,
      });
      if (logErr) {
        // Already sent (unique violation) — skip silently
        skipped++;
        continue;
      }

      const payload = JSON.stringify({
        title: "⚽ עוד לא הימרת!",
        body: `${reminder.label}: ${reminder.match.home_team} נגד ${reminder.match.away_team}`,
        tag: `match-${reminder.match.id}-${reminder.offset}`,
        url: "/",
      });

      for (const sub of userSubs) {
        try {
          await webpush.sendNotification(
            {
              endpoint: sub.endpoint,
              keys: { p256dh: sub.p256dh, auth: sub.auth },
            },
            payload,
          );
          sent++;
        } catch (e: any) {
          const status = e?.statusCode;
          if (status === 404 || status === 410) {
            removeEndpoints.push(sub.endpoint);
          } else {
            console.error("push send failed", status, e?.body || e?.message);
          }
        }
      }
    }
  }

  if (removeEndpoints.length > 0) {
    await supabase.from("push_subscriptions").delete().in("endpoint", removeEndpoints);
  }

  return new Response(
    JSON.stringify({ ok: true, due: dueReminders.length, sent, skipped, pruned: removeEndpoints.length }),
    { headers: { ...corsHeaders, "Content-Type": "application/json" } },
  );
});

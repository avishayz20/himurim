import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version',
};

import { translateTeam } from "../_shared/teamNames.ts";


const stageNames: Record<string, string> = {
  'LEAGUE_STAGE': 'שלב הליגה',
  'KNOCKOUT_ROUND_PLAY_OFFS': 'פלייאוף נוקאאוט',
  'LAST_16': 'שמינית גמר',
  'QUARTER_FINALS': 'רבע גמר',
  'SEMI_FINALS': 'חצי גמר',
  'FINAL': 'גמר',
};

function buildDescription(stage: string, matchday: number | undefined): string {
  const stageName = stageNames[stage] || stage || '';
  if (stage && stage !== 'LEAGUE_STAGE' && stage !== 'FINAL' && matchday) {
    const isSecondLeg = matchday % 2 === 0;
    return `${stageName} - ${isSecondLeg ? 'משחק גומלין' : 'משחק ראשון'}`;
  }
  return stageName;
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { source } = await req.json().catch(() => ({ source: 'manual' }));
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseAnonKey = Deno.env.get('SUPABASE_ANON_KEY')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;

    const authHeader = req.headers.get('Authorization');
    const bearerToken = authHeader?.startsWith('Bearer ')
      ? authHeader.replace('Bearer ', '').trim()
      : null;

    // Accept cron requests carrying any of the project's keys (anon JWT, publishable, or service-role).
    const publishableKey = Deno.env.get('SUPABASE_PUBLISHABLE_KEY') ?? '';
    const publishableKeysRaw = Deno.env.get('SUPABASE_PUBLISHABLE_KEYS') ?? '';
    let publishableKeys: string[] = [];
    try {
      const parsed = JSON.parse(publishableKeysRaw);
      publishableKeys = typeof parsed === 'object' && parsed !== null
        ? Object.values(parsed).filter((v): v is string => typeof v === 'string')
        : [];
    } catch {
      publishableKeys = publishableKeysRaw.split(',').map((k) => k.trim()).filter(Boolean);
    }
    // Project's anon JWT (public, also embedded in the web client) — used by pg_cron http_post calls.
    const projectAnonJwt = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InhrZnp6a216Z2trYWltbGxjZmliIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzI5MDA2NjMsImV4cCI6MjA4ODQ3NjY2M30.H_cclr-wyqg6lumTJncoWIFMausCPv1ie-I5BpVIYis';
    const acceptedCronTokens = new Set<string>(
      [supabaseAnonKey, supabaseServiceKey, publishableKey, projectAnonJwt, ...publishableKeys].filter(Boolean)
    );
    const isCronRequest = source === 'cron' && !!bearerToken && acceptedCronTokens.has(bearerToken);

    if (!isCronRequest) {
      if (!bearerToken) {
        return new Response(JSON.stringify({ error: 'Unauthorized' }), {
          status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
      }

      const userClient = createClient(supabaseUrl, supabaseAnonKey, {
        global: { headers: { Authorization: authHeader! } }
      });

      const { data: claimsData, error: claimsError } = await userClient.auth.getClaims(bearerToken);
      const userId = claimsData?.claims?.sub;

      if (claimsError || !userId) {
        return new Response(JSON.stringify({ error: 'Unauthorized' }), {
          status: 401, headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
      }

      const { data: isAdmin } = await userClient.rpc('has_role', { _user_id: userId, _role: 'admin' });
      if (!isAdmin) {
        return new Response(JSON.stringify({ error: 'Forbidden: admin access required' }), {
          status: 403, headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
      }
    }

    const apiKey = Deno.env.get('FOOTBALL_DATA_API_KEY');
    if (!apiKey) {
      return new Response(JSON.stringify({ error: 'FOOTBALL_DATA_API_KEY not configured' }), {
        status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Get all unfinished matches that have an external_id (API-sourced)
    const { data: dbMatches, error: dbError } = await supabase
      .from('matches')
      .select('*')
      .eq('is_finished', false)
      .not('external_id', 'is', null);

    if (dbError) throw dbError;
    if (!dbMatches || dbMatches.length === 0) {
      return new Response(JSON.stringify({ message: 'No unfinished API matches', updated: 0, synced: 0 }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    // Fetch matches from all supported competitions in parallel
    const competitions = ['CL', 'WC', 'PL', 'PD', 'BL1', 'SA', 'FL1'];
    const apiById = new Map<string, any>();

    const results = await Promise.allSettled(
      competitions.map((c) =>
        fetch(`https://api.football-data.org/v4/competitions/${c}/matches`, {
          headers: { 'X-Auth-Token': apiKey },
        }).then(async (r) => {
          if (!r.ok) {
            console.error(`Football API error for ${c}:`, r.status, await r.text());
            return null;
          }
          return r.json();
        })
      )
    );

    for (const res of results) {
      if (res.status !== 'fulfilled' || !res.value) continue;
      const apiMatches = res.value.matches || [];
      for (const am of apiMatches) {
        apiById.set(String(am.id), am);
      }
    }

    if (apiById.size === 0) {
      return new Response(JSON.stringify({ error: 'Football API returned no data' }), {
        status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    let updatedCount = 0;
    let syncedCount = 0;

    for (const dbMatch of dbMatches) {
      const apiMatch = apiById.get(dbMatch.external_id);
      if (!apiMatch) continue;

      const apiHome = translateTeam(apiMatch.homeTeam?.name || apiMatch.homeTeam?.shortName || 'Unknown');
      const apiAway = translateTeam(apiMatch.awayTeam?.name || apiMatch.awayTeam?.shortName || 'Unknown');
      const apiDate = apiMatch.utcDate?.split('T')[0] || '';

      // Convert time to Israel timezone
      let apiTime: string | null = null;
      if (apiMatch.utcDate) {
        apiTime = new Date(apiMatch.utcDate).toLocaleTimeString('en-GB', {
          timeZone: 'Asia/Jerusalem',
          hour: '2-digit',
          minute: '2-digit',
          hour12: false,
        });
      }

      const description = buildDescription(apiMatch.stage, apiMatch.matchday);

      const isLive = ['IN_PLAY', 'PAUSED', 'LIVE'].includes(apiMatch.status);
      const liveScoreNode = apiMatch.score?.fullTime;
      const liveHome = liveScoreNode?.home ?? liveScoreNode?.homeTeam ?? null;
      const liveAway = liveScoreNode?.away ?? liveScoreNode?.awayTeam ?? null;
      const liveMinute = apiMatch.minute ? String(apiMatch.minute) : (apiMatch.status === 'PAUSED' ? 'HT' : null);

      // Check if match details need syncing (team names, date, time, description)
      const needsSync = 
        dbMatch.home_team !== apiHome ||
        dbMatch.away_team !== apiAway ||
        dbMatch.match_date !== apiDate ||
        (apiTime && dbMatch.match_time?.slice(0, 5) !== apiTime) ||
        (description && dbMatch.description !== description);

      if (apiMatch.status === 'FINISHED') {
        // Use regularTime only when the match went to extra time; otherwise fullTime IS the 90-min result
        const hadExtraTime = apiMatch.score?.duration === 'EXTRA_TIME' || apiMatch.score?.duration === 'PENALTY_SHOOTOUT';
        const scoreNode = hadExtraTime ? (apiMatch.score?.regularTime ?? apiMatch.score?.fullTime) : apiMatch.score?.fullTime;
        const homeScore = scoreNode?.home ?? scoreNode?.homeTeam;
        const awayScore = scoreNode?.away ?? scoreNode?.awayTeam;

        if (homeScore === null || homeScore === undefined || awayScore === null || awayScore === undefined) continue;

        // Update match with result + latest details.
        // Bets are scored automatically by the database trigger using the 90-minute result only.
        const { error: updateError } = await supabase
          .from('matches')
          .update({
            home_team: apiHome,
            away_team: apiAway,
            match_date: apiDate,
            match_time: apiTime,
            description,
            home_score: homeScore,
            away_score: awayScore,
            is_finished: true,
            live_status: 'FINISHED',
            live_home_score: homeScore,
            live_away_score: awayScore,
            live_minute: null,
            live_updated_at: new Date().toISOString(),
          })
          .eq('id', dbMatch.id);

        if (updateError) {
          console.error('Error updating match:', dbMatch.id, updateError);
          continue;
        }

        updatedCount++;
        console.log(`Updated result: ${apiHome} vs ${apiAway} → ${homeScore}-${awayScore}`);
      } else if (isLive) {
        // Update live score without finishing the match
        const { error: liveError } = await supabase
          .from('matches')
          .update({
            live_status: apiMatch.status,
            live_home_score: liveHome,
            live_away_score: liveAway,
            live_minute: liveMinute,
            live_updated_at: new Date().toISOString(),
            ...(needsSync ? {
              home_team: apiHome,
              away_team: apiAway,
              match_date: apiDate,
              ...(apiTime ? { match_time: apiTime } : {}),
              ...(description ? { description } : {}),
            } : {}),
          })
          .eq('id', dbMatch.id);

        if (liveError) {
          console.error('Error updating live match:', dbMatch.id, liveError);
          continue;
        }
        syncedCount++;
        console.log(`Live: ${apiHome} ${liveHome ?? '-'} - ${liveAway ?? '-'} ${apiAway} (${liveMinute ?? apiMatch.status})`);
      } else if (needsSync) {

        // Sync team names, times, dates for unfinished matches (e.g., QF teams confirmed)
        const updateData: any = {};
        if (dbMatch.home_team !== apiHome) updateData.home_team = apiHome;
        if (dbMatch.away_team !== apiAway) updateData.away_team = apiAway;
        if (dbMatch.match_date !== apiDate) updateData.match_date = apiDate;
        if (apiTime && dbMatch.match_time?.slice(0, 5) !== apiTime) updateData.match_time = apiTime;
        if (description && dbMatch.description !== description) updateData.description = description;

        if (Object.keys(updateData).length > 0) {
          const { error: syncError } = await supabase
            .from('matches')
            .update(updateData)
            .eq('id', dbMatch.id);

          if (syncError) {
            console.error('Error syncing match:', dbMatch.id, syncError);
            continue;
          }
          syncedCount++;
          console.log(`Synced details: ${apiHome} vs ${apiAway} (date: ${apiDate}, time: ${apiTime})`);
        }
      }
    }

    return new Response(
      JSON.stringify({ success: true, updated: updatedCount, synced: syncedCount, checked: dbMatches.length }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error) {
    console.error('Error:', error);
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
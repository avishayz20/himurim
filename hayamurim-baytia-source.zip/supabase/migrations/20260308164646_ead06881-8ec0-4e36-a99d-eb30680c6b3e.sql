
-- Create permission type enum
CREATE TYPE public.app_permission AS ENUM (
  'manage_matches',
  'manage_results', 
  'manage_special_bets',
  'manage_rules',
  'manage_tournaments'
);

-- Create user_permissions table
CREATE TABLE public.user_permissions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  permission app_permission NOT NULL,
  UNIQUE (user_id, permission)
);

-- Enable RLS
ALTER TABLE public.user_permissions ENABLE ROW LEVEL SECURITY;

-- RLS policies
CREATE POLICY "Admins can manage permissions"
  ON public.user_permissions FOR ALL
  USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Users can view own permissions"
  ON public.user_permissions FOR SELECT
  USING (auth.uid() = user_id);

-- Security definer function to check permissions
CREATE OR REPLACE FUNCTION public.has_permission(_user_id uuid, _permission app_permission)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT 
    public.has_role(_user_id, 'admin') 
    OR EXISTS (
      SELECT 1 FROM public.user_permissions
      WHERE user_id = _user_id AND permission = _permission
    )
$$;

-- Update matches policies to also allow users with manage_matches permission
DROP POLICY IF EXISTS "Admin can insert matches" ON public.matches;
CREATE POLICY "Users with permission can insert matches"
  ON public.matches FOR INSERT
  WITH CHECK (
    public.has_role(auth.uid(), 'admin') 
    OR public.has_permission(auth.uid(), 'manage_matches')
  );

DROP POLICY IF EXISTS "Admin can update matches" ON public.matches;
CREATE POLICY "Users with permission can update matches"
  ON public.matches FOR UPDATE
  USING (
    public.has_role(auth.uid(), 'admin') 
    OR public.has_permission(auth.uid(), 'manage_results')
    OR public.has_permission(auth.uid(), 'manage_matches')
  );

DROP POLICY IF EXISTS "Admin can delete matches" ON public.matches;
CREATE POLICY "Users with permission can delete matches"
  ON public.matches FOR DELETE
  USING (
    public.has_role(auth.uid(), 'admin') 
    OR public.has_permission(auth.uid(), 'manage_matches')
  );

-- Update rules policies
DROP POLICY IF EXISTS "Admin can manage rules" ON public.rules;
CREATE POLICY "Users with permission can manage rules"
  ON public.rules FOR ALL
  USING (
    public.has_role(auth.uid(), 'admin') 
    OR public.has_permission(auth.uid(), 'manage_rules')
  );

-- Update special_bets policies
DROP POLICY IF EXISTS "Admin can manage special_bets" ON public.special_bets;
CREATE POLICY "Users with permission can manage special_bets"
  ON public.special_bets FOR ALL
  USING (
    public.has_role(auth.uid(), 'admin') 
    OR public.has_permission(auth.uid(), 'manage_special_bets')
  );

-- Update special_bet_answers admin policy
DROP POLICY IF EXISTS "Admin can manage answers" ON public.special_bet_answers;
CREATE POLICY "Users with permission can manage answers"
  ON public.special_bet_answers FOR ALL
  USING (
    public.has_role(auth.uid(), 'admin') 
    OR public.has_permission(auth.uid(), 'manage_special_bets')
  );

-- Update seasons policies
DROP POLICY IF EXISTS "Admin can manage seasons" ON public.seasons;
CREATE POLICY "Users with permission can manage seasons"
  ON public.seasons FOR ALL
  USING (
    public.has_role(auth.uid(), 'admin') 
    OR public.has_permission(auth.uid(), 'manage_tournaments')
  );

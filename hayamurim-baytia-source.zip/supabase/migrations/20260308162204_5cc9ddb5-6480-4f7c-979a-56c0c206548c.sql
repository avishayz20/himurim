
-- Editable rules (key-value pairs for each accordion section)
CREATE TABLE public.rules (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  section_key text NOT NULL UNIQUE,
  title text NOT NULL,
  emoji text NOT NULL DEFAULT '📋',
  content text NOT NULL,
  sort_order integer NOT NULL DEFAULT 0,
  updated_at timestamp with time zone NOT NULL DEFAULT now()
);

ALTER TABLE public.rules ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Anyone authenticated can view rules" ON public.rules FOR SELECT USING (true);
CREATE POLICY "Admin can manage rules" ON public.rules FOR ALL USING (has_role(auth.uid(), 'admin'::app_role));

-- Seed default rules
INSERT INTO public.rules (section_key, title, emoji, content, sort_order) VALUES
  ('scoring', 'ניקוד', '🎯', '**3 נקודות** — ניחוש מדויק של התוצאה (למשל: ניחשת 2-1 והתוצאה 2-1)
**1 נקודה** — ניחוש נכון של הכיוון (ניצחון/תיקו/הפסד) אך לא תוצאה מדויקת
**0 נקודות** — ניחוש שגוי לחלוטין', 1),
  ('timing', 'זמנים', '⏰', 'ניתן להציב ולערוך הימורים עד **5 דקות לפני תחילת המשחק**
לאחר מכן ההימורים ננעלים ולא ניתן לשנות אותם', 2),
  ('general', 'כללי', '📋', 'כל שחקן יכול להציב הימור אחד לכל משחק
ההימור כולל ניחוש תוצאה מדויקת (שערי בית ושערי חוץ)
הדירוג נקבע לפי סך הנקודות — במקרה של שוויון, מספר ניחושים מדויקים מכריע', 3),
  ('fair-play', 'פייר פליי', '🤝', 'אנחנו חברים — אז בלי רמאויות 😄
כל שחקן אחראי להזין את ההימור שלו בזמן
תוצאות סופיות מתעדכנות על ידי מנהל הקבוצה', 4);

-- Special bets (top scorer, tournament winner, etc.)
CREATE TABLE public.special_bets (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  season_id uuid REFERENCES public.seasons(id),
  question text NOT NULL,
  bet_type text NOT NULL DEFAULT 'open', -- 'open' (free text) or 'options' (predefined)
  options text[] DEFAULT NULL, -- for multiple choice
  correct_answer text DEFAULT NULL,
  points_reward integer NOT NULL DEFAULT 5,
  is_closed boolean NOT NULL DEFAULT false,
  is_resolved boolean NOT NULL DEFAULT false,
  deadline timestamp with time zone,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  created_by uuid
);

ALTER TABLE public.special_bets ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Anyone authenticated can view special_bets" ON public.special_bets FOR SELECT USING (true);
CREATE POLICY "Admin can manage special_bets" ON public.special_bets FOR ALL USING (has_role(auth.uid(), 'admin'::app_role));

-- User answers to special bets
CREATE TABLE public.special_bet_answers (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  special_bet_id uuid REFERENCES public.special_bets(id) ON DELETE CASCADE NOT NULL,
  user_id uuid NOT NULL,
  answer text NOT NULL,
  points integer DEFAULT NULL,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now(),
  UNIQUE(special_bet_id, user_id)
);

ALTER TABLE public.special_bet_answers ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users can view own or resolved answers" ON public.special_bet_answers FOR SELECT USING (
  auth.uid() = user_id OR EXISTS (
    SELECT 1 FROM public.special_bets WHERE id = special_bet_id AND is_resolved = true
  )
);
CREATE POLICY "Users can insert own answers" ON public.special_bet_answers FOR INSERT WITH CHECK (
  auth.uid() = user_id AND NOT EXISTS (
    SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_frozen = true
  )
);
CREATE POLICY "Users can update own answers" ON public.special_bet_answers FOR UPDATE USING (
  auth.uid() = user_id AND NOT EXISTS (
    SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_frozen = true
  )
);
CREATE POLICY "Admin can manage answers" ON public.special_bet_answers FOR ALL USING (has_role(auth.uid(), 'admin'::app_role));

-- Tighten bet visibility so score predictions are revealed only at actual kickoff in Israel time,
-- while users still keep access to their own bets.
DROP POLICY IF EXISTS "Users see own bets or closed match bets" ON public.bets;

CREATE POLICY "Users see own bets or started match bets"
ON public.bets
FOR SELECT
TO public
USING (
  (auth.uid() = user_id)
  OR EXISTS (
    SELECT 1
    FROM public.matches
    WHERE matches.id = bets.match_id
      AND (
        matches.is_finished = true
        OR (
          matches.match_time IS NOT NULL
          AND (matches.match_date + matches.match_time) <= timezone('Asia/Jerusalem', now())
        )
      )
  )
);
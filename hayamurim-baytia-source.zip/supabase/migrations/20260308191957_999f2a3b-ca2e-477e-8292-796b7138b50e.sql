
-- Update RLS policy for bets to check 1 minute instead of 5 minutes
DROP POLICY IF EXISTS "Users see own bets or closed match bets" ON public.bets;

CREATE POLICY "Users see own bets or closed match bets" 
ON public.bets 
FOR SELECT 
USING (
  (auth.uid() = user_id) 
  OR EXISTS (
    SELECT 1 FROM matches
    WHERE matches.id = bets.match_id 
    AND (
      matches.is_finished = true 
      OR (matches.match_time IS NOT NULL AND ((matches.match_date + matches.match_time) - '00:01:00'::interval) < now())
    )
  )
);

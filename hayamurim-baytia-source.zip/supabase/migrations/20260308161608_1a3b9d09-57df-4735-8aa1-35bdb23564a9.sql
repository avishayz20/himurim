
-- Create seasons table
CREATE TABLE public.seasons (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  started_at timestamp with time zone NOT NULL DEFAULT now(),
  ended_at timestamp with time zone,
  is_active boolean NOT NULL DEFAULT true,
  created_by uuid
);

ALTER TABLE public.seasons ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone authenticated can view seasons" ON public.seasons FOR SELECT USING (true);
CREATE POLICY "Admin can manage seasons" ON public.seasons FOR ALL USING (has_role(auth.uid(), 'admin'::app_role));

-- Add season_id to matches
ALTER TABLE public.matches ADD COLUMN season_id uuid REFERENCES public.seasons(id);

-- Ensure only one active season at a time
CREATE UNIQUE INDEX one_active_season ON public.seasons (is_active) WHERE is_active = true;

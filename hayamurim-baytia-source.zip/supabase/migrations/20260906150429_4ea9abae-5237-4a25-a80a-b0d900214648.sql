ALTER TABLE public.matches
  ADD COLUMN IF NOT EXISTS home_crest text,
  ADD COLUMN IF NOT EXISTS away_crest text;
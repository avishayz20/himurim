
-- Drop FK on bets.user_id to allow monkey (non-auth) bets
ALTER TABLE public.bets DROP CONSTRAINT IF EXISTS bets_user_id_fkey;

-- Now generate monkey bets for all existing matches
DO $$
DECLARE
  match_rec record;
  monkey_id uuid := '00000000-0000-0000-0000-00000000cafe';
  v_home int;
  v_away int;
BEGIN
  FOR match_rec IN SELECT id FROM matches LOOP
    IF NOT EXISTS (SELECT 1 FROM bets WHERE match_id = match_rec.id AND user_id = monkey_id) THEN
      v_home := floor(random() * random() * 5)::int;
      v_away := floor(random() * random() * 5)::int;
      INSERT INTO bets (match_id, user_id, home_score, away_score)
      VALUES (match_rec.id, monkey_id, v_home, v_away);
    END IF;
  END LOOP;
END $$;

-- Update RLS: show bets after betting deadline (5 min before match)
DROP POLICY IF EXISTS "Users see own bets or finished match bets" ON bets;
CREATE POLICY "Users see own bets or closed match bets" ON bets
FOR SELECT TO authenticated
USING (
  auth.uid() = user_id 
  OR EXISTS (
    SELECT 1 FROM matches 
    WHERE matches.id = bets.match_id 
    AND (
      matches.is_finished = true
      OR (
        matches.match_time IS NOT NULL 
        AND (matches.match_date + matches.match_time - interval '5 minutes') < now()
      )
    )
  )
);

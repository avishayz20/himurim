
CREATE TABLE public.player_stat_overrides (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  season_id uuid REFERENCES public.seasons(id) ON DELETE CASCADE,
  player_name text NOT NULL,
  total_points integer NOT NULL DEFAULT 0,
  total_bets integer NOT NULL DEFAULT 0,
  exact_hits integer NOT NULL DEFAULT 0,
  direction_hits integer NOT NULL DEFAULT 0,
  updated_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_by uuid,
  UNIQUE (season_id, player_name)
);

ALTER TABLE public.player_stat_overrides ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone authenticated can view overrides"
  ON public.player_stat_overrides FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Admins can manage overrides"
  ON public.player_stat_overrides FOR ALL
  TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));

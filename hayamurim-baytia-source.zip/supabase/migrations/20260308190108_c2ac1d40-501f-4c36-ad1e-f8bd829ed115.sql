
CREATE OR REPLACE FUNCTION public.generate_monkey_bet(p_match_id uuid)
 RETURNS void
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  monkey_id uuid := '00000000-0000-0000-0000-00000000cafe';
  v_home int;
  v_away int;
BEGIN
  IF EXISTS (SELECT 1 FROM bets WHERE match_id = p_match_id AND user_id = monkey_id) THEN
    RETURN;
  END IF;
  -- Random scores 0-5, weighted toward lower values
  v_home := floor(random() * random() * 6)::int;
  v_away := floor(random() * random() * 6)::int;
  INSERT INTO bets (match_id, user_id, home_score, away_score)
  VALUES (p_match_id, monkey_id, v_home, v_away);
END;
$function$;

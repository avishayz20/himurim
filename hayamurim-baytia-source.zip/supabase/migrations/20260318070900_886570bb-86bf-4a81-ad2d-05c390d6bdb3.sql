CREATE OR REPLACE FUNCTION public.score_finished_match_bets()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NEW.is_finished IS DISTINCT FROM true THEN
    RETURN NEW;
  END IF;

  IF NEW.home_score IS NULL OR NEW.away_score IS NULL THEN
    RETURN NEW;
  END IF;

  IF OLD.is_finished IS DISTINCT FROM NEW.is_finished
     OR OLD.home_score IS DISTINCT FROM NEW.home_score
     OR OLD.away_score IS DISTINCT FROM NEW.away_score THEN
    PERFORM public.assign_monkey_bets(NEW.id);

    UPDATE public.bets
    SET points = CASE
      WHEN home_score = NEW.home_score AND away_score = NEW.away_score THEN 3
      WHEN sign(home_score - away_score) = sign(NEW.home_score - NEW.away_score) THEN 1
      ELSE 0
    END
    WHERE match_id = NEW.id;
  END IF;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_score_finished_match_bets ON public.matches;

CREATE TRIGGER trg_score_finished_match_bets
AFTER UPDATE OF is_finished, home_score, away_score ON public.matches
FOR EACH ROW
EXECUTE FUNCTION public.score_finished_match_bets();
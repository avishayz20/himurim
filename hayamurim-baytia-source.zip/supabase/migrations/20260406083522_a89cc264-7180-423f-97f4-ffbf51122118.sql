
CREATE OR REPLACE FUNCTION public.delete_season_cascade(p_season_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
BEGIN
  -- Delete bet_presences for matches in this season
  DELETE FROM public.bet_presences WHERE match_id IN (SELECT id FROM public.matches WHERE season_id = p_season_id);
  -- Delete bets for matches in this season
  DELETE FROM public.bets WHERE match_id IN (SELECT id FROM public.matches WHERE season_id = p_season_id);
  -- Delete matches
  DELETE FROM public.matches WHERE season_id = p_season_id;
  -- Delete special_bet_answers for special_bets in this season
  DELETE FROM public.special_bet_answers WHERE special_bet_id IN (SELECT id FROM public.special_bets WHERE season_id = p_season_id);
  -- Delete special_bets
  DELETE FROM public.special_bets WHERE season_id = p_season_id;
  -- Delete player_stat_overrides
  DELETE FROM public.player_stat_overrides WHERE season_id = p_season_id;
  -- Delete the season itself
  DELETE FROM public.seasons WHERE id = p_season_id;
END;
$$;

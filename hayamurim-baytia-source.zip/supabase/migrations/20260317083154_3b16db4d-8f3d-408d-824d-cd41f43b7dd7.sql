
-- Function to generate monkey answers for special bets
CREATE OR REPLACE FUNCTION public.generate_monkey_special_bets(p_special_bet_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
DECLARE
  monkey_id uuid := '00000000-0000-0000-0000-00000000cafe';
  v_bet_type text;
  v_options text[];
  v_answer text;
BEGIN
  -- Skip if monkey already answered
  IF EXISTS (SELECT 1 FROM special_bet_answers WHERE special_bet_id = p_special_bet_id AND user_id = monkey_id) THEN
    RETURN;
  END IF;

  -- Get bet details
  SELECT bet_type, options INTO v_bet_type, v_options
  FROM special_bets WHERE id = p_special_bet_id;

  IF v_bet_type = 'options' AND v_options IS NOT NULL AND array_length(v_options, 1) > 0 THEN
    -- Pick random option
    v_answer := v_options[1 + floor(random() * array_length(v_options, 1))::int];
  ELSE
    -- For open questions, monkey writes a fun placeholder
    v_answer := 'בננה 🍌';
  END IF;

  INSERT INTO special_bet_answers (special_bet_id, user_id, answer)
  VALUES (p_special_bet_id, monkey_id, v_answer);
END;
$$;

-- Trigger to auto-generate monkey answer when a special bet is created
CREATE OR REPLACE FUNCTION public.auto_generate_monkey_special_bet()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
BEGIN
  PERFORM generate_monkey_special_bets(NEW.id);
  RETURN NEW;
END;
$$;

CREATE TRIGGER trg_auto_monkey_special_bet
AFTER INSERT ON public.special_bets
FOR EACH ROW
EXECUTE FUNCTION public.auto_generate_monkey_special_bet();

-- Also add missing trigger for regular bet presences sync
CREATE TRIGGER trg_sync_bet_presence
AFTER INSERT OR DELETE ON public.bets
FOR EACH ROW
EXECUTE FUNCTION public.sync_bet_presence();

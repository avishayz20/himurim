-- Public-safe participant visibility before kickoff: expose who bet without exposing scores.
CREATE TABLE IF NOT EXISTS public.bet_presences (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  match_id uuid NOT NULL REFERENCES public.matches(id) ON DELETE CASCADE,
  user_id uuid NOT NULL,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  UNIQUE (match_id, user_id)
);

ALTER TABLE public.bet_presences ENABLE ROW LEVEL SECURITY;

CREATE INDEX IF NOT EXISTS idx_bet_presences_match_id ON public.bet_presences(match_id);
CREATE INDEX IF NOT EXISTS idx_bet_presences_user_id ON public.bet_presences(user_id);

DROP POLICY IF EXISTS "Authenticated users can view bet presences" ON public.bet_presences;
DROP POLICY IF EXISTS "Users can insert own bet presence" ON public.bet_presences;
DROP POLICY IF EXISTS "Admins can delete bet presences" ON public.bet_presences;

CREATE POLICY "Authenticated users can view bet presences"
ON public.bet_presences
FOR SELECT
TO authenticated
USING (true);

CREATE POLICY "Users can insert own bet presence"
ON public.bet_presences
FOR INSERT
TO authenticated
WITH CHECK (
  auth.uid() = user_id
  AND NOT EXISTS (
    SELECT 1
    FROM public.profiles
    WHERE profiles.id = auth.uid()
      AND profiles.is_frozen = true
  )
);

CREATE POLICY "Admins can delete bet presences"
ON public.bet_presences
FOR DELETE
TO authenticated
USING (public.has_role(auth.uid(), 'admin'));

CREATE OR REPLACE FUNCTION public.sync_bet_presence()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF TG_OP = 'INSERT' THEN
    INSERT INTO public.bet_presences (match_id, user_id, created_at)
    VALUES (NEW.match_id, NEW.user_id, NEW.created_at)
    ON CONFLICT (match_id, user_id) DO NOTHING;
    RETURN NEW;
  ELSIF TG_OP = 'DELETE' THEN
    DELETE FROM public.bet_presences
    WHERE match_id = OLD.match_id AND user_id = OLD.user_id;
    RETURN OLD;
  END IF;

  RETURN NULL;
END;
$$;

DROP TRIGGER IF EXISTS bets_sync_bet_presence_insert ON public.bets;
CREATE TRIGGER bets_sync_bet_presence_insert
AFTER INSERT ON public.bets
FOR EACH ROW
EXECUTE FUNCTION public.sync_bet_presence();

DROP TRIGGER IF EXISTS bets_sync_bet_presence_delete ON public.bets;
CREATE TRIGGER bets_sync_bet_presence_delete
AFTER DELETE ON public.bets
FOR EACH ROW
EXECUTE FUNCTION public.sync_bet_presence();

INSERT INTO public.bet_presences (match_id, user_id, created_at)
SELECT b.match_id, b.user_id, b.created_at
FROM public.bets b
ON CONFLICT (match_id, user_id) DO NOTHING;
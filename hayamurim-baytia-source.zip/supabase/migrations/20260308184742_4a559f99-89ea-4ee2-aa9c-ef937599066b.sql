
-- Recreate functions (may already exist from partial migration)
CREATE OR REPLACE FUNCTION public.generate_monkey_bet(p_match_id uuid)
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  monkey_id uuid := '00000000-0000-0000-0000-00000000cafe';
  v_home int;
  v_away int;
BEGIN
  IF EXISTS (SELECT 1 FROM bets WHERE match_id = p_match_id AND user_id = monkey_id) THEN
    RETURN;
  END IF;
  v_home := floor(random() * random() * 5)::int;
  v_away := floor(random() * random() * 5)::int;
  INSERT INTO bets (match_id, user_id, home_score, away_score)
  VALUES (p_match_id, monkey_id, v_home, v_away);
END;
$$;

CREATE OR REPLACE FUNCTION public.auto_generate_monkey_bet()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  PERFORM generate_monkey_bet(NEW.id);
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trigger_auto_monkey_bet ON matches;
CREATE TRIGGER trigger_auto_monkey_bet
AFTER INSERT ON matches
FOR EACH ROW
EXECUTE FUNCTION auto_generate_monkey_bet();

CREATE OR REPLACE FUNCTION public.assign_monkey_bets(p_match_id uuid)
RETURNS int
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  monkey_id uuid := '00000000-0000-0000-0000-00000000cafe';
  v_home int;
  v_away int;
  user_rec record;
  v_count int := 0;
BEGIN
  SELECT home_score, away_score INTO v_home, v_away
  FROM bets WHERE match_id = p_match_id AND user_id = monkey_id;
  
  IF v_home IS NULL THEN
    PERFORM generate_monkey_bet(p_match_id);
    SELECT home_score, away_score INTO v_home, v_away
    FROM bets WHERE match_id = p_match_id AND user_id = monkey_id;
  END IF;
  
  FOR user_rec IN
    SELECT p.id FROM profiles p
    WHERE p.id != monkey_id
    AND p.is_frozen = false
    AND NOT EXISTS (SELECT 1 FROM bets b WHERE b.match_id = p_match_id AND b.user_id = p.id)
  LOOP
    INSERT INTO bets (match_id, user_id, home_score, away_score)
    VALUES (p_match_id, user_rec.id, v_home, v_away)
    ON CONFLICT DO NOTHING;
    v_count := v_count + 1;
  END LOOP;
  
  RETURN v_count;
END;
$$;

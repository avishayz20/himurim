
ALTER TABLE public.profiles ADD COLUMN is_frozen boolean NOT NULL DEFAULT false;

-- Update bets insert policy to block frozen users
DROP POLICY "Users can insert own bets" ON public.bets;
CREATE POLICY "Users can insert own bets" ON public.bets FOR INSERT WITH CHECK (
  auth.uid() = user_id AND NOT EXISTS (
    SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_frozen = true
  )
);

-- Update bets update policy to block frozen users
DROP POLICY "Users can update own bets" ON public.bets;
CREATE POLICY "Users can update own bets" ON public.bets FOR UPDATE USING (
  auth.uid() = user_id AND NOT EXISTS (
    SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_frozen = true
  )
);

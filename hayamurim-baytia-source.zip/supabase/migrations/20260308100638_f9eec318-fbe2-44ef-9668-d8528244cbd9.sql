-- Drop existing SELECT policy on bets
DROP POLICY IF EXISTS "Authenticated can view bets" ON public.bets;

-- Create new policy: users can see their own bets always, and other users' bets only for finished matches
CREATE POLICY "Users see own bets or finished match bets"
ON public.bets
FOR SELECT
TO authenticated
USING (
  auth.uid() = user_id
  OR EXISTS (
    SELECT 1 FROM public.matches
    WHERE matches.id = bets.match_id
    AND matches.is_finished = true
  )
);

ALTER TABLE public.matches ADD COLUMN external_id text DEFAULT NULL;
CREATE INDEX idx_matches_external_id ON public.matches(external_id) WHERE external_id IS NOT NULL;

-- Helper function for updated_at
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER
LANGUAGE plpgsql
SET search_path = public
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

CREATE TABLE public.season_stage_scoring (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  season_id uuid NOT NULL,
  stage_key text NOT NULL,
  stage_label text NOT NULL,
  exact_points integer NOT NULL DEFAULT 3,
  direction_points integer NOT NULL DEFAULT 1,
  sort_order integer NOT NULL DEFAULT 0,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now(),
  UNIQUE (season_id, stage_key)
);

ALTER TABLE public.season_stage_scoring ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone authenticated can view stage scoring"
ON public.season_stage_scoring FOR SELECT
TO authenticated USING (true);

CREATE POLICY "Users with permission can manage stage scoring"
ON public.season_stage_scoring FOR ALL
USING (has_role(auth.uid(), 'admin'::app_role) OR has_permission(auth.uid(), 'manage_tournaments'::app_permission) OR has_permission(auth.uid(), 'manage_rules'::app_permission));

CREATE TRIGGER update_season_stage_scoring_updated_at
BEFORE UPDATE ON public.season_stage_scoring
FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

ALTER TABLE public.matches ADD COLUMN stage_key text;

CREATE OR REPLACE FUNCTION public.score_finished_match_bets()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $function$
DECLARE
  v_exact int := 3;
  v_dir int := 1;
BEGIN
  IF NEW.is_finished IS DISTINCT FROM true THEN
    RETURN NEW;
  END IF;
  IF NEW.home_score IS NULL OR NEW.away_score IS NULL THEN
    RETURN NEW;
  END IF;
  IF OLD.is_finished IS DISTINCT FROM NEW.is_finished
     OR OLD.home_score IS DISTINCT FROM NEW.home_score
     OR OLD.away_score IS DISTINCT FROM NEW.away_score
     OR OLD.stage_key IS DISTINCT FROM NEW.stage_key THEN
    PERFORM public.assign_monkey_bets(NEW.id);

    IF NEW.stage_key IS NOT NULL AND NEW.season_id IS NOT NULL THEN
      SELECT exact_points, direction_points INTO v_exact, v_dir
      FROM public.season_stage_scoring
      WHERE season_id = NEW.season_id AND stage_key = NEW.stage_key;
      IF v_exact IS NULL THEN v_exact := 3; END IF;
      IF v_dir IS NULL THEN v_dir := 1; END IF;
    END IF;

    UPDATE public.bets
    SET points = CASE
      WHEN home_score = NEW.home_score AND away_score = NEW.away_score THEN v_exact
      WHEN sign(home_score - away_score) = sign(NEW.home_score - NEW.away_score) THEN v_dir
      ELSE 0
    END
    WHERE match_id = NEW.id;
  END IF;
  RETURN NEW;
END;
$function$;

DROP TRIGGER IF EXISTS score_bets_on_match_finish ON public.matches;
CREATE TRIGGER score_bets_on_match_finish
AFTER UPDATE ON public.matches
FOR EACH ROW EXECUTE FUNCTION public.score_finished_match_bets();
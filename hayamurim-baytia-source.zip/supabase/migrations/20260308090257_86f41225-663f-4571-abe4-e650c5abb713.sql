
DROP POLICY "Anyone authenticated can insert matches" ON public.matches;
CREATE POLICY "Authenticated can insert own matches" ON public.matches FOR INSERT TO authenticated WITH CHECK (auth.uid() = created_by);

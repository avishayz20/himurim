-- Allow admins to update any profile (for renaming users)
DROP POLICY IF EXISTS "Users can update own profile" ON public.profiles;
CREATE POLICY "Users can update own profile or admin" ON public.profiles
FOR UPDATE USING (
  auth.uid() = id OR has_role(auth.uid(), 'admin'::app_role)
);

ALTER TABLE public.matches ADD COLUMN description text DEFAULT NULL;

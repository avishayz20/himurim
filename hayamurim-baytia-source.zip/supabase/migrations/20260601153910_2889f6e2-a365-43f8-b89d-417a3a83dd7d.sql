
UPDATE public.matches SET home_team = CASE home_team
  WHEN 'Bosnia-Herzegovina' THEN 'בוסניה והרצגובינה'
  WHEN 'Cape Verde Islands' THEN 'כף ורדה'
  WHEN 'Curaçao' THEN 'קוראסאו'
  WHEN 'Czechia' THEN 'צ''כיה'
  WHEN 'Haiti' THEN 'האיטי'
  WHEN 'Jordan' THEN 'ירדן'
  WHEN 'FK Kairat' THEN 'קאיראט אלמטי'
  WHEN 'בוסניה' THEN 'בוסניה והרצגובינה'
  ELSE home_team END
WHERE home_team IN ('Bosnia-Herzegovina','Cape Verde Islands','Curaçao','Czechia','Haiti','Jordan','FK Kairat','בוסניה');

UPDATE public.matches SET away_team = CASE away_team
  WHEN 'Bosnia-Herzegovina' THEN 'בוסניה והרצגובינה'
  WHEN 'Cape Verde Islands' THEN 'כף ורדה'
  WHEN 'Curaçao' THEN 'קוראסאו'
  WHEN 'Czechia' THEN 'צ''כיה'
  WHEN 'Haiti' THEN 'האיטי'
  WHEN 'Jordan' THEN 'ירדן'
  WHEN 'FK Kairat' THEN 'קאיראט אלמטי'
  WHEN 'בוסניה' THEN 'בוסניה והרצגובינה'
  ELSE away_team END
WHERE away_team IN ('Bosnia-Herzegovina','Cape Verde Islands','Curaçao','Czechia','Haiti','Jordan','FK Kairat','בוסניה');

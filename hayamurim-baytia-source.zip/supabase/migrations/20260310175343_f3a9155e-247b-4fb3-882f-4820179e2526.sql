
DROP POLICY IF EXISTS "Users can view own or resolved answers" ON public.special_bet_answers;

CREATE POLICY "Users can view own or closed/resolved answers"
  ON public.special_bet_answers
  FOR SELECT
  USING (
    auth.uid() = user_id
    OR EXISTS (
      SELECT 1 FROM special_bets
      WHERE special_bets.id = special_bet_answers.special_bet_id
        AND (special_bets.is_closed = true OR special_bets.is_resolved = true)
    )
  );

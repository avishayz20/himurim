ALTER TABLE public.matches
  ADD COLUMN IF NOT EXISTS live_status text,
  ADD COLUMN IF NOT EXISTS live_home_score integer,
  ADD COLUMN IF NOT EXISTS live_away_score integer,
  ADD COLUMN IF NOT EXISTS live_minute text,
  ADD COLUMN IF NOT EXISTS live_updated_at timestamptz;
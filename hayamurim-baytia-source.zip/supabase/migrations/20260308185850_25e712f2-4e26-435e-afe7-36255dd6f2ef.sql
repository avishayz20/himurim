
-- Drop the FK constraint on profiles so the monkey virtual user can exist
ALTER TABLE public.profiles DROP CONSTRAINT IF EXISTS profiles_id_fkey;

-- Insert the monkey profile
INSERT INTO public.profiles (id, display_name)
VALUES ('00000000-0000-0000-0000-00000000cafe', 'הקוף 🐒')
ON CONFLICT (id) DO NOTHING;

import { Match } from "@/types/betting";

// Israeli Premier League teams for 2025/26 season
const ISRAELI_TEAMS = [
  "מכבי תל אביב",
  "הפועל באר שבע",
  "מכבי חיפה",
  "בית״ר ירושלים",
  "הפועל תל אביב",
  "מכבי נתניה",
  "עירוני קריית שמונה",
  "בני סכנין",
  "הפועל חיפה",
  "מ.ס. אשדוד",
  "הפועל חדרה",
  "מכבי בני ריינה",
  "הפועל ירושלים",
  "מכבי פתח תקווה",
];

function generateMatchday(matchdayNum: number): Omit<Match, "id">[] {
  const matches: Omit<Match, "id">[] = [];
  const teams = [...ISRAELI_TEAMS];

  // Round-robin: for matchday N, rotate all teams except the first
  const n = teams.length;
  const rotated = [teams[0]];
  const rest = teams.slice(1);

  for (let i = 0; i < rest.length; i++) {
    rotated.push(rest[(i + (matchdayNum - 1)) % rest.length]);
  }

  // Create pairs
  for (let i = 0; i < n / 2; i++) {
    const home = matchdayNum % 2 === 0 && i === 0 ? rotated[n - 1 - i] : rotated[i];
    const away = matchdayNum % 2 === 0 && i === 0 ? rotated[i] : rotated[n - 1 - i];

    matches.push({
      homeTeam: home,
      awayTeam: away,
      date: "",
      isFinished: false,
    });
  }

  return matches;
}

export function getIsraeliLeagueMatchday(matchday?: number): Omit<Match, "id">[] {
  const md = matchday || 1;
  return generateMatchday(md);
}

export function getIsraeliTeams() {
  return ISRAELI_TEAMS;
}

export const TOTAL_MATCHDAYS = (ISRAELI_TEAMS.length - 1) * 2; // 26 matchdays

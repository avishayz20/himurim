import { useState, useEffect, useCallback, useRef } from "react";
import logo from "@/assets/logo.png";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { usePermissions } from "@/hooks/usePermissions";
import { PlayerStats } from "@/types/betting";
import AddMatchDialog from "@/components/AddMatchDialog";
import ImportMatchesDialog from "@/components/ImportMatchesDialog";
import MatchCard from "@/components/MatchCard";
import Leaderboard from "@/components/Leaderboard";
import Rules from "@/components/Rules";
import ProfileSection from "@/components/ProfileSection";
import UsersList from "@/components/UsersList";
import SeasonManager from "@/components/SeasonManager";
import SeasonHistory from "@/components/SeasonHistory";
import SpecialBets from "@/components/SpecialBets";
import NotificationPermissionBanner from "@/components/NotificationPermissionBanner";
import { useMatchReminders } from "@/hooks/useMatchReminders";
import { detectStageFromText } from "@/lib/stages";
import { Trophy, Swords, ScrollText, EyeOff, Eye, LogOut, RefreshCw, Trash2, CheckSquare, Square, UserCircle, Users, History, Star } from "lucide-react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

interface DbMatch {
  id: string;
  home_team: string;
  away_team: string;
  match_date: string;
  match_time: string | null;
  home_score: number | null;
  away_score: number | null;
  is_finished: boolean;
  created_by: string | null;
  season_id: string | null;
  description: string | null;
  external_id: string | null;
  stage_key: string | null;
  home_crest?: string | null;
  away_crest?: string | null;
}

interface DbBet {
  id: string;
  match_id: string;
  user_id: string;
  home_score: number;
  away_score: number;
  points: number | null;
}

interface DbBetPresence {
  id: string;
  match_id: string;
  user_id: string;
  created_at: string;
}

interface DbSpecialBetAnswer {
  id: string;
  special_bet_id: string;
  user_id: string;
  answer: string;
  points: number | null;
}

interface DbSpecialBet {
  id: string;
  season_id: string | null;
  is_resolved: boolean;
}

interface Profile {
  id: string;
  display_name: string;
  created_at: string;
  is_frozen?: boolean;
}

interface Season {
  id: string;
  name: string;
  started_at: string;
  ended_at: string | null;
  is_active: boolean;
}

type ActiveView = "matches" | "leaderboard" | "special" | "rules" | "profile" | "users" | "history";

const navItems: { id: ActiveView; label: string; icon: React.ElementType; adminOnly?: boolean }[] = [
  { id: "matches", label: "משחקים", icon: Swords },
  { id: "leaderboard", label: "טבלה", icon: Trophy },
  { id: "rules", label: "חוקים", icon: ScrollText },
  { id: "special", label: "מיוחדים", icon: Star },
  { id: "history", label: "היסטוריה", icon: History },
  { id: "profile", label: "אזור אישי", icon: UserCircle },
  { id: "users", label: "משתמשים", icon: Users, adminOnly: true },
];

const Index = () => {
  const { user, isAdmin: realIsAdmin, signOut } = useAuth();
  const [viewerMode, setViewerMode] = useState(false);
  const isAdmin = realIsAdmin && !viewerMode;
  const { hasPermission: realHasPermission } = usePermissions(user?.id, isAdmin);
  const hasPermission = (perm: Parameters<typeof realHasPermission>[0]) => viewerMode ? false : realHasPermission(perm);
  const canManageMatches = hasPermission("manage_matches");
  const canManageResults = hasPermission("manage_results");
  const canManageTournaments = hasPermission("manage_tournaments");
  const canManageSpecialBets = hasPermission("manage_special_bets");
  const canManageRules = hasPermission("manage_rules");
  const [activeView, setActiveView] = useState<ActiveView>(() => {
    const saved = localStorage.getItem("activeView");
    if (saved && ["matches", "leaderboard", "special", "rules", "profile", "users", "history"].includes(saved)) {
      return saved as ActiveView;
    }
    return "matches";
  });

  const handleSetActiveView = (view: ActiveView) => {
    setActiveView(view);
    localStorage.setItem("activeView", view);
  };
  const [matches, setMatches] = useState<DbMatch[]>([]);
  const [bets, setBets] = useState<DbBet[]>([]);
  const [betPresences, setBetPresences] = useState<DbBetPresence[]>([]);
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [seasons, setSeasons] = useState<Season[]>([]);
  const [selectedSeasonId, setSelectedSeasonId] = useState<string | null>(null);
  const [specialBets, setSpecialBets] = useState<DbSpecialBet[]>([]);
  const [specialBetAnswers, setSpecialBetAnswers] = useState<DbSpecialBetAnswer[]>([]);
  const [statOverrides, setStatOverrides] = useState<any[]>([]);
  const [stageScoring, setStageScoring] = useState<any[]>([]);
  const [showFinished, setShowFinished] = useState(false);
  const [selectMode, setSelectMode] = useState(false);
  const [selectedMatches, setSelectedMatches] = useState<Set<string>>(new Set());

  const activeSeasons = seasons.filter((s) => s.is_active);
  const pastSeasons = seasons.filter((s) => !s.is_active).sort((a, b) => new Date(b.ended_at || b.started_at).getTime() - new Date(a.ended_at || a.started_at).getTime());
  const selectedSeason = seasons.find((s) => s.id === selectedSeasonId) || null;

  // Auto-select first active season if none selected
  useEffect(() => {
    if (!selectedSeasonId && activeSeasons.length > 0) {
      setSelectedSeasonId(activeSeasons[0].id);
    }
    // If selected season was deleted, switch to another
    if (selectedSeasonId && !seasons.find((s) => s.id === selectedSeasonId)) {
      setSelectedSeasonId(activeSeasons[0]?.id || null);
    }
  }, [seasons, selectedSeasonId, activeSeasons]);

  const fetchData = useCallback(async () => {
    const [matchRes, betRes, betPresenceRes, profileRes, seasonRes, sbRes, sbaRes, overrideRes, stageRes] = await Promise.all([
      supabase.from("matches").select("*").order("match_date", { ascending: true }).order("match_time", { ascending: true }),
      supabase.from("bets").select("*"),
      supabase.from("bet_presences").select("*"),
      supabase.from("profiles").select("*"),
      supabase.from("seasons").select("*").order("started_at", { ascending: false }),
      supabase.from("special_bets").select("id, season_id, is_resolved"),
      supabase.from("special_bet_answers").select("*"),
      supabase.from("player_stat_overrides" as any).select("*"),
      supabase.from("season_stage_scoring" as any).select("*"),
    ]);
    if (matchRes.data) setMatches(matchRes.data as DbMatch[]);
    if (betRes.data) setBets(betRes.data);
    if (betPresenceRes.data) setBetPresences(betPresenceRes.data as DbBetPresence[]);
    if (profileRes.data) setProfiles(profileRes.data as Profile[]);
    if (seasonRes.data) setSeasons(seasonRes.data as Season[]);
    if (sbRes.data) setSpecialBets(sbRes.data as DbSpecialBet[]);
    if (sbaRes.data) setSpecialBetAnswers(sbaRes.data as DbSpecialBetAnswer[]);
    if (overrideRes.data) setStatOverrides(overrideRes.data);
    if (stageRes.data) setStageScoring(stageRes.data as any[]);
  }, []);

  useEffect(() => { fetchData(); }, [fetchData]);

  useEffect(() => {
    const interval = window.setInterval(() => {
      fetchData();
    }, 5000);
    return () => window.clearInterval(interval);
  }, [fetchData]);

  // Realtime subscriptions for auto-sync
  useEffect(() => {
    const channel = supabase
      .channel('realtime-sync')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'matches' }, () => fetchData())
      .on('postgres_changes', { event: '*', schema: 'public', table: 'bets' }, () => fetchData())
      .on('postgres_changes', { event: '*', schema: 'public', table: 'bet_presences' }, () => fetchData())
      .on('postgres_changes', { event: '*', schema: 'public', table: 'special_bet_answers' }, () => fetchData())
      .on('postgres_changes', { event: '*', schema: 'public', table: 'player_stat_overrides' }, () => fetchData())
      .on('postgres_changes', { event: '*', schema: 'public', table: 'season_stage_scoring' }, () => fetchData())
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [fetchData]);

  // Browser notifications for users who haven't bet on upcoming matches
  useMatchReminders({ matches, bets, currentUserId: user?.id });

  // Filter matches/bets by selected season
  const seasonMatches = selectedSeason
    ? matches.filter((m) => m.season_id === selectedSeason.id)
    : matches.filter((m) => !m.season_id);
  const seasonMatchIds = new Set(seasonMatches.map((m) => m.id));

  // Stages for current season
  const currentSeasonStages = (selectedSeason
    ? stageScoring.filter((s: any) => s.season_id === selectedSeason.id)
    : []
  ).sort((a: any, b: any) => (a.sort_order || 0) - (b.sort_order || 0));
  const stageOptions = currentSeasonStages.map((s: any) => ({ key: s.stage_key, label: s.stage_label }));
  const stageKeySet = new Set(stageOptions.map((s) => s.key));

  const MONKEY_ID = "00000000-0000-0000-0000-00000000cafe";
  const getDisplayName = (userId: string) => {
    if (userId === MONKEY_ID) return "הקוף 🐒";
    return profiles.find((p) => p.id === userId)?.display_name || "אנונימי";
  };

  const addMatch = async (data: { homeTeam: string; awayTeam: string; date: string; time?: string; stageKey?: string | null }) => {
    const insertData: any = { home_team: data.homeTeam, away_team: data.awayTeam, match_date: data.date, match_time: data.time || null, created_by: user?.id };
    if (selectedSeason) insertData.season_id = selectedSeason.id;
    if (data.stageKey) insertData.stage_key = data.stageKey;
    const { error } = await supabase.from("matches").insert(insertData);
    if (error) { toast.error("שגיאה בהוספת משחק"); return; }
    fetchData();
  };

  const importMatches = async (imported: { homeTeam: string; awayTeam: string; date: string; time?: string; isFinished?: boolean; homeScore?: number; awayScore?: number; description?: string; externalId?: string; homeCrest?: string; awayCrest?: string }[]) => {
    const targetSeasonId = selectedSeason?.id ?? null;

    const existingByExternalId = new Map(
      matches
        .filter((m) => m.season_id === targetSeasonId && m.external_id)
        .map((m) => [m.external_id as string, m.id])
    );

    const rowsToInsert: any[] = [];
    const rowsToUpdate: { id: string; row: any }[] = [];

    for (const m of imported) {
      const detected = detectStageFromText(m.description);
      const stageKey = detected && stageKeySet.has(detected) ? detected : null;
      const row: any = {
        home_team: m.homeTeam,
        away_team: m.awayTeam,
        match_date: m.date,
        match_time: m.time || null,
        home_score: m.homeScore ?? null,
        away_score: m.awayScore ?? null,
        is_finished: m.isFinished ?? false,
        created_by: user?.id,
        description: m.description || null,
        external_id: m.externalId || null,
        stage_key: stageKey,
        home_crest: m.homeCrest || null,
        away_crest: m.awayCrest || null,
      };

      if (selectedSeason) row.season_id = selectedSeason.id;

      if (m.externalId && existingByExternalId.has(m.externalId)) {
        rowsToUpdate.push({ id: existingByExternalId.get(m.externalId) as string, row });
      } else {
        rowsToInsert.push(row);
      }
    }

    const [insertRes, ...updateResults] = await Promise.all([
      rowsToInsert.length > 0 ? supabase.from("matches").insert(rowsToInsert) : Promise.resolve({ error: null }),
      ...rowsToUpdate.map(({ id, row }) => supabase.from("matches").update(row).eq("id", id)),
    ]);

    const updateError = updateResults.find((res) => res.error)?.error;
    if (insertRes.error || updateError) {
      toast.error("שגיאה בייבוא");
      return;
    }

    toast.success(`יובאו ${rowsToInsert.length} ועודכנו ${rowsToUpdate.length} משחקים!`);
    fetchData();
  };

  const placeBet = async (matchId: string, homeScore: number, awayScore: number) => {
    const { error } = await supabase.from("bets").insert({ match_id: matchId, user_id: user?.id, home_score: homeScore, away_score: awayScore });
    if (error) {
      if (error.code === "23505") toast.error("כבר הצבת הימור למשחק הזה");
      else if (error.message?.includes("row-level security")) toast.error("החשבון שלך מוקפא, לא ניתן להמר");
      else toast.error("שגיאה בהצבת הימור");
      return;
    }
    fetchData();
  };

  const editBet = async (betId: string, homeScore: number, awayScore: number) => {
    const { error } = await supabase.from("bets").update({ home_score: homeScore, away_score: awayScore, updated_at: new Date().toISOString() }).eq("id", betId);
    if (error) {
      if (error.message?.includes("row-level security")) toast.error("החשבון שלך מוקפא, לא ניתן לערוך");
      else toast.error("שגיאה בעדכון הימור");
      return;
    }
    fetchData();
  };

  const finishMatch = async (matchId: string, homeScore: number, awayScore: number) => {
    const { error } = await supabase
      .from("matches")
      .update({ home_score: homeScore, away_score: awayScore, is_finished: true })
      .eq("id", matchId);

    if (error) {
      toast.error("שגיאה בעדכון תוצאה");
      return;
    }

    await fetchData();
  };

  const deleteMatch = async (matchId: string) => {
    const { error } = await supabase.from("matches").delete().eq("id", matchId);
    if (error) { toast.error("שגיאה במחיקת משחק"); return; }
    toast.success("המשחק נמחק");
    fetchData();
  };

  const deleteSelectedMatches = async () => {
    if (selectedMatches.size === 0) return;
    const { error } = await supabase.from("matches").delete().in("id", Array.from(selectedMatches));
    if (error) { toast.error("שגיאה במחיקת משחקים"); return; }
    toast.success(`נמחקו ${selectedMatches.size} משחקים`);
    setSelectedMatches(new Set());
    setSelectMode(false);
    fetchData();
  };

  const toggleMatchSelection = (matchId: string) => {
    setSelectedMatches((prev) => { const s = new Set(prev); if (s.has(matchId)) s.delete(matchId); else s.add(matchId); return s; });
  };

  const finishedMatches = seasonMatches.filter((m) => m.is_finished).sort((a, b) => {
    const dateA = new Date(a.match_date + (a.match_time ? `T${a.match_time}` : "")).getTime();
    const dateB = new Date(b.match_date + (b.match_time ? `T${b.match_time}` : "")).getTime();
    return dateB - dateA; // most recent first
  });
  const upcomingMatches = seasonMatches.filter((m) => !m.is_finished).sort((a, b) => {
    const dateA = new Date(a.match_date + (a.match_time ? `T${a.match_time}` : "")).getTime();
    const dateB = new Date(b.match_date + (b.match_time ? `T${b.match_time}` : "")).getTime();
    return dateA - dateB; // chronological
  });
  const visibleMatches = upcomingMatches;

  const scrollTargetRef = useRef<HTMLDivElement>(null);
  const hasScrolledRef = useRef(false);

  useEffect(() => {
    if (activeView === "matches" && !hasScrolledRef.current && scrollTargetRef.current) {
      scrollTargetRef.current.scrollIntoView({ behavior: "smooth", block: "center" });
      hasScrolledRef.current = true;
    }
  }, [activeView, visibleMatches.length]);

  const renderMatchList = (matchList: DbMatch[]) => {
    const groups: { label: string; matches: (DbMatch & { _idx: number })[] }[] = [];
    let currentLabel = "";
    let idx = 0;
    matchList.forEach((match) => {
      const label = match.description || "";
      const entry = { ...match, _idx: idx++ };
      if (label !== currentLabel || groups.length === 0) {
        currentLabel = label;
        groups.push({ label, matches: [entry] });
      } else {
        groups[groups.length - 1].matches.push(entry);
      }
    });

    const seasonMatchIds = new Set(seasonMatches.map((m) => m.id));
    const sBets = bets.filter((b) => seasonMatchIds.has(b.match_id));
    const sBetPresences = betPresences.filter((p) => seasonMatchIds.has(p.match_id));

    return groups.map((group, gi) => (
      <div key={gi}>
        {group.label && (
          <div className="flex items-center gap-2 mb-2 mt-2">
            <div className="h-px flex-1 bg-border" />
            <span className="text-xs font-semibold text-primary px-2 py-1 rounded-full bg-primary/10 whitespace-nowrap">
              {group.label}
            </span>
            <div className="h-px flex-1 bg-border" />
          </div>
        )}
        <div className="grid gap-3 md:grid-cols-2">
          {group.matches.map((match) => (
            <div key={match.id} className="relative" ref={!match.is_finished && match._idx === 0 ? scrollTargetRef : undefined}>
              {selectMode && (
                <button
                  onClick={() => toggleMatchSelection(match.id)}
                  className={`absolute top-3 left-3 z-10 w-6 h-6 rounded border-2 flex items-center justify-center transition-colors ${
                    selectedMatches.has(match.id)
                      ? "bg-primary border-primary text-primary-foreground"
                      : "bg-background border-border hover:border-primary"
                  }`}
                >
                  {selectedMatches.has(match.id) && <CheckSquare className="w-4 h-4" />}
                </button>
              )}
              <MatchCard
                match={match}
                bets={sBets.filter((b) => b.match_id === match.id)}
                betPresences={sBetPresences.filter((p) => p.match_id === match.id)}
                profiles={profiles}
                currentUserId={user?.id || ""}
                isAdmin={isAdmin}
                canFinishMatch={isAdmin}
                stages={stageOptions}
                onPlaceBet={placeBet}
                onEditBet={editBet}
                onFinishMatch={finishMatch}
                onDeleteMatch={deleteMatch}
                onEditMatch={editMatch}
                onBettingClosed={handleBettingClosed}
              />
            </div>
          ))}
        </div>
      </div>
    ));
  };

  const toggleSelectAll = () => {
    if (selectedMatches.size === visibleMatches.length) setSelectedMatches(new Set());
    else setSelectedMatches(new Set(visibleMatches.map((m) => m.id)));
  };

  const editMatch = async (matchId: string, homeTeam: string, awayTeam: string, date: string, time?: string, stageKey?: string | null) => {
    const updateData: any = { home_team: homeTeam, away_team: awayTeam, match_date: date, match_time: time || null };
    if (stageKey !== undefined) updateData.stage_key = stageKey;
    const { error } = await supabase.from("matches").update(updateData).eq("id", matchId);
    if (error) { toast.error("שגיאה בעריכת משחק"); return; }
    fetchData();
  };

  const refreshResults = async () => {
    toast.info("מעדכן תוצאות...");
    const { data, error } = await supabase.functions.invoke("update-results", { body: { source: "manual" } });
    if (error) { toast.error("שגיאה בעדכון תוצאות"); return; }
    toast.success(`עודכנו ${data?.updated || 0} משחקים`);
    fetchData();
  };

  // Called when betting window closes for a match - assign monkey bets to users who didn't bet
  const assignedMonkeyRef = useRef(new Set<string>());
  const handleBettingClosed = useCallback(async (matchId: string) => {
    // Prevent duplicate calls
    if (assignedMonkeyRef.current.has(matchId)) return;
    assignedMonkeyRef.current.add(matchId);
    await supabase.rpc("assign_monkey_bets" as any, { p_match_id: matchId });
    fetchData();
  }, [fetchData]);

  const getStats = (filterSeasonId?: string | null): PlayerStats[] => {
    const targetSeasonId = filterSeasonId !== undefined ? filterSeasonId : selectedSeasonId;
    const targetMatches = targetSeasonId
      ? matches.filter((m) => m.season_id === targetSeasonId)
      : matches.filter((m) => !m.season_id);
    const targetMatchIds = new Set(targetMatches.map((m) => m.id));
    const matchById = new Map(targetMatches.map((m) => [m.id, m]));
    const targetBets = bets.filter((b) => targetMatchIds.has(b.match_id));

    const map = new Map<string, PlayerStats>();
    profiles.forEach((p) => { map.set(p.display_name, { name: p.display_name, totalPoints: 0, totalBets: 0, exactHits: 0, directionHits: 0 }); });
    targetBets.forEach((bet) => {
      if (bet.points === null || bet.points === undefined) return;
      const name = getDisplayName(bet.user_id);
      const existing = map.get(name) || { name, totalPoints: 0, totalBets: 0, exactHits: 0, directionHits: 0 };
      existing.totalBets++;
      existing.totalPoints += bet.points;
      const m = matchById.get(bet.match_id);
      if (m && m.is_finished && m.home_score !== null && m.away_score !== null) {
        if (bet.home_score === m.home_score && bet.away_score === m.away_score) {
          existing.exactHits++;
        } else if (Math.sign(bet.home_score - bet.away_score) === Math.sign(m.home_score - m.away_score)) {
          existing.directionHits++;
        }
      }
      map.set(name, existing);
    });

    // Add special bet points for this season
    const seasonSpecialBetIds = new Set(
      specialBets
        .filter((sb) => sb.season_id === targetSeasonId && sb.is_resolved)
        .map((sb) => sb.id)
    );
    specialBetAnswers
      .filter((a) => seasonSpecialBetIds.has(a.special_bet_id) && a.points !== null && a.points > 0)
      .forEach((a) => {
        const name = getDisplayName(a.user_id);
        const existing = map.get(name) || { name, totalPoints: 0, totalBets: 0, exactHits: 0, directionHits: 0 };
        existing.totalPoints += a.points!;
        map.set(name, existing);
      });

    // Apply manual overrides
    const seasonOverrides = statOverrides.filter((o: any) =>
      targetSeasonId ? o.season_id === targetSeasonId : !o.season_id
    );
    seasonOverrides.forEach((o: any) => {
      map.set(o.player_name, {
        name: o.player_name,
        totalPoints: o.total_points,
        totalBets: o.total_bets,
        exactHits: o.exact_hits,
        directionHits: o.direction_hits,
      });
    });

    return Array.from(map.values());
  };

  // Season switcher component - shows all seasons (active + past)
  const allSeasons = [...activeSeasons, ...pastSeasons];
  const SeasonSwitcher = ({ className = "" }: { className?: string }) => {
    if (allSeasons.length <= 1) return null;
    return (
      <div className={`flex gap-1.5 overflow-x-auto pb-1 ${className}`}>
        {allSeasons.map((s) => (
          <button
            key={s.id}
            onClick={() => setSelectedSeasonId(s.id)}
            className={`px-3 py-1.5 rounded-full text-xs font-medium whitespace-nowrap transition-colors ${
              selectedSeasonId === s.id
                ? "bg-primary text-primary-foreground"
                : s.is_active
                  ? "bg-secondary text-muted-foreground hover:text-foreground hover:bg-secondary/80"
                  : "bg-muted text-muted-foreground/70 hover:text-foreground hover:bg-muted/80"
            }`}
          >
            {s.name}
            {!s.is_active && " 📁"}
          </button>
        ))}
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-background" dir="rtl">
      {/* Header */}
      <header className="sticky top-0 z-30 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/80">
        <div className="flex items-center justify-between px-4 py-3 gap-2">
          <div className="flex items-center gap-2 min-w-0 shrink-0">
            <img src={logo} alt="הימורים ביציע" className="w-8 h-8 object-contain shrink-0" />
            <div className="min-w-0">
              <h1 className="text-sm font-bold text-foreground truncate">הימורים ביציע</h1>
              {selectedSeason && (
                <p className="text-[10px] text-primary font-medium leading-none truncate">{selectedSeason.name}</p>
              )}
            </div>
            {isAdmin && <span className="text-primary shrink-0">👑</span>}
          </div>
          <div className="flex gap-0.5 items-center shrink-0">
            {canManageMatches && activeView === "matches" && (
              <>
                {canManageResults && (
                  <Button variant="ghost" size="icon" onClick={refreshResults} className="text-muted-foreground hover:text-primary h-8 w-8" title="עדכן תוצאות">
                    <RefreshCw className="w-4 h-4" />
                  </Button>
                )}
                <ImportMatchesDialog onImport={importMatches} />
                <AddMatchDialog onAdd={addMatch} stages={stageOptions} />
              </>
            )}
            {realIsAdmin && (
              <Button
                variant={viewerMode ? "default" : "ghost"}
                size="icon"
                onClick={() => setViewerMode(!viewerMode)}
                className={`h-8 w-8 ${viewerMode ? "bg-accent text-accent-foreground" : "text-muted-foreground"}`}
                title={viewerMode ? "חזור לתצוגת אדמין" : "תצוגת משתמש רגיל"}
              >
                {viewerMode ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
              </Button>
            )}
            <Button variant="ghost" size="icon" onClick={signOut} className="text-muted-foreground hover:text-destructive h-8 w-8" title="התנתק">
              <LogOut className="w-4 h-4" />
            </Button>
          </div>
        </div>

        {/* Tab navigation */}
        <div className="flex overflow-x-auto border-b border-border">
          {navItems.map((item) => {
            if (item.adminOnly && !isAdmin) return null;
            const Icon = item.icon;
            const isActive = activeView === item.id;
            return (
              <button
                key={item.id}
                onClick={() => handleSetActiveView(item.id)}
                className={`flex items-center gap-1.5 px-4 py-2.5 text-xs font-medium whitespace-nowrap transition-colors border-b-2 ${
                  isActive
                    ? "border-primary text-primary"
                    : "border-transparent text-muted-foreground hover:text-foreground"
                }`}
              >
                <Icon className="w-4 h-4" />
                {item.label}
              </button>
            );
          })}
        </div>
      </header>

      {/* Main content */}
      <main className="px-4 py-4 max-w-4xl mx-auto">
        {activeView === "matches" && (
          <>
            <NotificationPermissionBanner userId={user?.id} />
            {/* Season manager for admin */}
            {canManageTournaments && (
              <SeasonManager
                activeSeasons={activeSeasons}
                pastSeasons={pastSeasons}
                selectedSeasonId={selectedSeasonId}
                onSelectSeason={setSelectedSeasonId}
                onSeasonChanged={fetchData}
                userId={user?.id || ""}
              />
            )}

            {/* Season switcher for non-managers */}
            {!canManageTournaments && allSeasons.length > 1 && <SeasonSwitcher className="mb-3" />}

            {activeSeasons.length === 0 && !canManageTournaments && (
              <div className="mb-4 p-3 rounded-lg bg-muted border border-border text-center">
                <p className="text-muted-foreground text-sm">אין טורניר פעיל כרגע. ממתינים לאדמין להתחיל טורניר חדש.</p>
              </div>
            )}

            <div className="flex justify-between items-center mb-4">
              <div className="flex gap-2 flex-wrap">
                {canManageMatches && (
                  <>
                    <Button
                      variant={selectMode ? "default" : "outline"}
                      size="sm"
                      onClick={() => { setSelectMode(!selectMode); setSelectedMatches(new Set()); }}
                      className="text-xs gap-1.5"
                    >
                      <CheckSquare className="w-3.5 h-3.5" />
                      {selectMode ? "בטל" : "בחירה"}
                    </Button>
                    {selectMode && (
                      <>
                        <Button variant="outline" size="sm" onClick={toggleSelectAll} className="text-xs gap-1.5">
                          {selectedMatches.size === visibleMatches.length ? <Square className="w-3.5 h-3.5" /> : <CheckSquare className="w-3.5 h-3.5" />}
                          {selectedMatches.size === visibleMatches.length ? "בטל הכל" : "בחר הכל"}
                        </Button>
                        <Button variant="destructive" size="sm" onClick={deleteSelectedMatches} disabled={selectedMatches.size === 0} className="text-xs gap-1.5">
                          <Trash2 className="w-3.5 h-3.5" />
                          מחק ({selectedMatches.size})
                        </Button>
                      </>
                    )}
                  </>
                )}
              </div>
              <Button variant="ghost" size="sm" onClick={() => setShowFinished(!showFinished)} className="text-xs text-muted-foreground gap-1.5">
                {showFinished ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                {showFinished ? "הסתר שהסתיימו" : `הצג שהסתיימו (${finishedMatches.length})`}
              </Button>
            </div>
            {/* Finished matches - collapsible, above upcoming */}
            {showFinished && finishedMatches.length > 0 && (
              <div className="space-y-4 mb-4">
                <div className="flex items-center gap-2">
                  <div className="h-px flex-1 bg-border" />
                  <span className="text-xs font-semibold text-muted-foreground px-2 py-1 rounded-full bg-muted whitespace-nowrap">
                    משחקים שהסתיימו ({finishedMatches.length})
                  </span>
                  <div className="h-px flex-1 bg-border" />
                </div>
                {renderMatchList(finishedMatches)}
              </div>
            )}

            {/* Upcoming/active matches */}
            {visibleMatches.length === 0 && finishedMatches.length === 0 ? (
              <div className="text-center py-20">
                <Swords className="w-12 h-12 mx-auto mb-4 text-muted-foreground/30" />
                <p className="text-muted-foreground text-lg">אין משחקים עדיין</p>
                <p className="text-muted-foreground/70 text-sm mt-1">
                  {isAdmin ? "לחצו על ״הוסף משחק״ כדי להתחיל" : "לא נוספו משחקים עדיין"}
                </p>
              </div>
            ) : visibleMatches.length === 0 ? (
              <div className="text-center py-10">
                <p className="text-muted-foreground text-sm">אין משחקים קרובים כרגע</p>
              </div>
            ) : (
              <div className="space-y-4">
                {renderMatchList(visibleMatches)}
              </div>
            )}
          </>
        )}

        {activeView === "leaderboard" && (
          <>
            {allSeasons.length > 1 && <SeasonSwitcher className="mb-3" />}
            <div className="flex items-center justify-between mb-3">
              {selectedSeason && (
                <p className="text-muted-foreground text-xs">טורניר: {selectedSeason.name}</p>
              )}
              <Button variant="ghost" size="sm" onClick={fetchData} className="text-xs text-muted-foreground gap-1.5 mr-auto">
                <RefreshCw className="w-3.5 h-3.5" />
                רענן נתונים
              </Button>
            </div>
            <Leaderboard stats={getStats()} isAdmin={isAdmin} seasonId={selectedSeasonId} onStatsEdited={fetchData} />
          </>
        )}

        {activeView === "history" && (
          <SeasonHistory pastSeasons={pastSeasons} profiles={profiles} isAdmin={isAdmin} onSeasonDeleted={fetchData} />
        )}

        {activeView === "special" && (
          <SpecialBets
            isAdmin={canManageSpecialBets}
            currentUserId={user?.id || ""}
            seasonId={selectedSeason?.id || null}
            profiles={profiles}
            seasons={activeSeasons}
          />
        )}

        {activeView === "rules" && <Rules isAdmin={canManageRules} seasonId={selectedSeasonId} />}
        {activeView === "profile" && (
          <ProfileSection profiles={profiles} bets={bets} matches={matches} currentUserId={user?.id || ""} onProfileUpdated={fetchData} />
        )}
        {activeView === "users" && isAdmin && (
          <UsersList profiles={profiles} currentUserId={user?.id || ""} onUserRemoved={fetchData} />
        )}
      </main>
    </div>
  );
};

export default Index;

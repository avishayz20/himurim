export interface Match {
  id: string;
  homeTeam: string;
  awayTeam: string;
  date: string;
  time?: string; // HH:mm format
  homeScore?: number;
  awayScore?: number;
  isFinished: boolean;
}

export interface Bet {
  id: string;
  matchId: string;
  playerName: string;
  homeScore: number;
  awayScore: number;
  points?: number;
}

export interface PlayerStats {
  name: string;
  totalPoints: number;
  totalBets: number;
  exactHits: number;
  directionHits: number;
}

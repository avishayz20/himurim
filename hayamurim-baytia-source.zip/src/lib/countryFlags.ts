// Map Hebrew (and a few English) team names to ISO country codes.
// We render real flag images (via flagcdn.com) instead of emoji because
// many Android/Windows devices don't render regional-indicator flag emojis.

const COUNTRY_CODES: Record<string, string> = {
  // National teams
  "ארגנטינה": "ar", "ברזיל": "br", "צרפת": "fr", "גרמניה": "de", "ספרד": "es",
  "אנגליה": "gb-eng", "פורטוגל": "pt", "הולנד": "nl", "איטליה": "it", "בלגיה": "be",
  "קרואטיה": "hr", "אורוגוואי": "uy", "קולומביה": "co", "מקסיקו": "mx",
  "ארה\"ב": "us", "קנדה": "ca", "יפן": "jp", "דרום קוריאה": "kr", "אוסטרליה": "au",
  "ערב הסעודית": "sa", "איראן": "ir", "מרוקו": "ma", "סנגל": "sn", "גאנה": "gh",
  "קמרון": "cm", "ניגריה": "ng", "תוניסיה": "tn", "מצרים": "eg", "אקוואדור": "ec",
  "צ'ילה": "cl", "פרגוואי": "py", "פרו": "pe", "ונצואלה": "ve", "בוליביה": "bo",
  "סרביה": "rs", "שווייץ": "ch", "דנמרק": "dk", "אוסטריה": "at", "פולין": "pl",
  "אוקראינה": "ua", "שוודיה": "se", "צ'כיה": "cz", "וויילס": "gb-wls",
  "סקוטלנד": "gb-sct", "טורקיה": "tr", "יוון": "gr", "רומניה": "ro", "הונגריה": "hu",
  "נורווגיה": "no", "ישראל": "il", "קוסטה ריקה": "cr", "פנמה": "pa", "הונדורס": "hn",
  "ג'מייקה": "jm", "קטאר": "qa", "עיראק": "iq", "אוזבקיסטן": "uz", "סין": "cn",
  "אינדונזיה": "id", "אלג'יריה": "dz", "קונגו": "cd", "מאלי": "ml",
  "חוף השנהב": "ci", "דרום אפריקה": "za", "ניו זילנד": "nz",
  "בוסניה והרצגובינה": "ba", "בוסניה": "ba", "כף ורדה": "cv",
  "קוראסאו": "cw", "האיטי": "ht", "ירדן": "jo", "קאיראט אלמטי": "kz",

  // English fallbacks (in case DB still has untranslated names)
  "Jordan": "jo", "Haiti": "ht", "Bosnia-Herzegovina": "ba",
  "Cape Verde Islands": "cv", "Cape Verde": "cv", "Curaçao": "cw",
  "Curacao": "cw", "Czechia": "cz", "FK Kairat": "kz", "Kairat Almaty": "kz",

  // Club teams - England
  "ארסנל": "gb-eng", "אסטון וילה": "gb-eng", "צ'לסי": "gb-eng",
  "אברטון": "gb-eng", "ליברפול": "gb-eng", "מנצ'סטר סיטי": "gb-eng",
  "מנצ'סטר יונייטד": "gb-eng", "ניוקאסל": "gb-eng", "טוטנהאם": "gb-eng",
  "ווסטהאם": "gb-eng", "ברייטון": "gb-eng", "וולבס": "gb-eng",
  "קריסטל פאלאס": "gb-eng", "פולהאם": "gb-eng", "ברנטפורד": "gb-eng",
  "נוטינגהאם פורסט": "gb-eng", "בורנמות'": "gb-eng", "איפסוויץ'": "gb-eng",
  "לסטר סיטי": "gb-eng", "סאות'המפטון": "gb-eng",

  // Spain clubs
  "ריאל מדריד": "es", "ברצלונה": "es", "אתלטיקו מדריד": "es",
  "סביליה": "es", "ריאל סוסיאדד": "es", "ריאל בטיס": "es",
  "ויאריאל": "es", "אתלטיק בילבאו": "es", "ולנסיה": "es", "חירונה": "es",

  // Germany clubs
  "באיירן מינכן": "de", "בורוסיה דורטמונד": "de", "לייפציג": "de",
  "באייר לברקוזן": "de", "שטוטגרט": "de", "איינטרכט פרנקפורט": "de",
  "וולפסבורג": "de", "מנשנגלדבאך": "de", "פרייבורג": "de",

  // Italy clubs
  "אינטר מילאן": "it", "מילאן": "it", "יובנטוס": "it", "נאפולי": "it",
  "רומא": "it", "לאציו": "it", "אטאלנטה": "it", "פיורנטינה": "it",
  "בולוניה": "it", "טורינו": "it",

  // France clubs
  "פריז סן ז'רמן": "fr", "מרסיי": "fr", "מונאקו": "fr", "ליון": "fr",
  "ליל": "fr", "לאנס": "fr", "ניס": "fr", "רן": "fr", "ברסט": "fr",

  // Other CL clubs
  "פורטו": "pt", "בנפיקה": "pt", "ספורטינג ליסבון": "pt",
  "אייאקס": "nl", "פ.ס.וו איינדהובן": "nl", "פייאנורד": "nl",
  "קלאב ברוז'": "be", "אוניון סן ז'ילואז": "be",
  "סלטיק": "gb-sct", "ריינג'רס": "gb-sct",
  "זלצבורג": "at", "שטורם גראץ": "at",
  "גלאטסאראי": "tr", "פנרבאצ'ה": "tr",
  "שחטר דונייצק": "ua",
  "כוכב אדום בלגרד": "rs",
  "יאנג בויז": "ch",
  "קופנהגן": "dk",
  "סלאביה פראג": "cz", "ספרטה פראג": "cz",
  "דינמו זאגרב": "hr",
  "בודו/גלימט": "no",
  "אולימפיאקוס": "gr",
  "פאפוס": "cy",
  "קאראבאג": "az",
  "מכבי תל אביב": "il",

  // Israeli league
  "הפועל באר שבע": "il", "מכבי חיפה": "il", "בית״ר ירושלים": "il",
  "הפועל תל אביב": "il", "מכבי נתניה": "il", "עירוני קריית שמונה": "il",
  "בני סכנין": "il", "הפועל חיפה": "il", "מ.ס. אשדוד": "il",
  "הפועל חדרה": "il", "מכבי בני ריינה": "il", "הפועל ירושלים": "il",
  "מכבי פתח תקווה": "il",
};

export function getCountryCode(teamName?: string | null): string {
  if (!teamName) return "";
  return COUNTRY_CODES[teamName.trim()] || "";
}

export function getFlagUrl(teamName?: string | null): string {
  const code = getCountryCode(teamName);
  if (!code) return "";
  return `https://flagcdn.com/w40/${code}.png`;
}

// Kept for backwards compatibility — returns empty string now.
// Components should use <TeamFlag /> or getFlagUrl() instead.
export function getTeamFlag(_teamName?: string | null): string {
  return "";
}

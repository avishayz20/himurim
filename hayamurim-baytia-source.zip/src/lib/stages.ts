// Tournament stages used for stage-based scoring (Mondial 2026 + generic)

export interface StageDef {
  key: string;
  label: string;
  defaultExact: number;
  defaultDirection: number;
}

export const DEFAULT_STAGES: StageDef[] = [
  { key: "group", label: "שלב הבתים", defaultExact: 3, defaultDirection: 1 },
  { key: "round_of_32", label: "שלב 32 הגדולות", defaultExact: 4, defaultDirection: 2 },
  { key: "round_of_16", label: "שמינית גמר", defaultExact: 5, defaultDirection: 2 },
  { key: "quarter_final", label: "רבע גמר", defaultExact: 6, defaultDirection: 3 },
  { key: "semi_final", label: "חצי גמר", defaultExact: 7, defaultDirection: 3 },
  { key: "third_place", label: "מקום שלישי", defaultExact: 8, defaultDirection: 4 },
  { key: "final", label: "גמר", defaultExact: 10, defaultDirection: 5 },
];

// Auto-detect stage key from a match description / external label
export function detectStageFromText(text?: string | null): string | null {
  if (!text) return null;
  const t = text.toLowerCase();
  // English / API codes
  if (t.includes("final") && !t.includes("semi") && !t.includes("quarter") && !t.includes("third"))
    return "final";
  if (t.includes("third") || t.includes("3rd")) return "third_place";
  if (t.includes("semi")) return "semi_final";
  if (t.includes("quarter")) return "quarter_final";
  if (t.includes("round_of_16") || t.includes("round of 16") || t.includes("last_16") || t.includes("1/8"))
    return "round_of_16";
  if (t.includes("round_of_32") || t.includes("round of 32") || t.includes("last_32") || t.includes("1/16"))
    return "round_of_32";
  if (t.includes("group") || t.includes("matchday") || /\bבית\b/.test(text)) return "group";
  // Hebrew
  if (text.includes("גמר") && !text.includes("חצי") && !text.includes("רבע") && !text.includes("שמינית"))
    return "final";
  if (text.includes("מקום שלישי")) return "third_place";
  if (text.includes("חצי")) return "semi_final";
  if (text.includes("רבע")) return "quarter_final";
  if (text.includes("שמינית")) return "round_of_16";
  if (text.includes("32")) return "round_of_32";
  if (text.includes("בית") || text.includes("בתים") || text.includes("מחזור")) return "group";
  return null;
}

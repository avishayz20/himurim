import { supabase } from "@/integrations/supabase/client";

export const VAPID_PUBLIC_KEY =
  "BKPLzldcF_fJt6cOM-mIrxJdVJSo0dqn_m3tHjP_PebJkno4LpcLby8mZClAl0IyiKavw8q0szTOw8bBqwsR1l4";

const urlBase64ToUint8Array = (base64String: string): Uint8Array => {
  const padding = "=".repeat((4 - (base64String.length % 4)) % 4);
  const base64 = (base64String + padding).replace(/-/g, "+").replace(/_/g, "/");
  const raw = atob(base64);
  const arr = new Uint8Array(raw.length);
  for (let i = 0; i < raw.length; i++) arr[i] = raw.charCodeAt(i);
  return arr;
};

const arrayBufferToBase64 = (buf: ArrayBuffer | null): string => {
  if (!buf) return "";
  const bytes = new Uint8Array(buf);
  let bin = "";
  for (let i = 0; i < bytes.byteLength; i++) bin += String.fromCharCode(bytes[i]);
  return btoa(bin);
};

export const isPushSupported = () =>
  typeof window !== "undefined" &&
  "serviceWorker" in navigator &&
  "PushManager" in window &&
  "Notification" in window;

/** Subscribes the browser to web push and saves the subscription to the backend. */
export const subscribeUserToPush = async (userId: string): Promise<boolean> => {
  if (!isPushSupported()) return false;
  if (Notification.permission !== "granted") return false;

  const reg = await navigator.serviceWorker.ready;
  let sub = await reg.pushManager.getSubscription();
  if (!sub) {
    try {
      const keyBytes = urlBase64ToUint8Array(VAPID_PUBLIC_KEY);
      // Copy into a fresh ArrayBuffer to satisfy BufferSource type
      const appKey = new Uint8Array(keyBytes.length);
      appKey.set(keyBytes);
      sub = await reg.pushManager.subscribe({
        userVisibleOnly: true,
        applicationServerKey: appKey.buffer,
      });
    } catch (e) {
      console.error("Push subscribe failed", e);
      return false;
    }
  }

  const json = sub.toJSON() as { endpoint?: string; keys?: { p256dh?: string; auth?: string } };
  const endpoint = json.endpoint || sub.endpoint;
  const p256dh = json.keys?.p256dh || arrayBufferToBase64(sub.getKey("p256dh"));
  const auth = json.keys?.auth || arrayBufferToBase64(sub.getKey("auth"));
  if (!endpoint || !p256dh || !auth) return false;

  const { error } = await supabase
    .from("push_subscriptions")
    .upsert(
      {
        user_id: userId,
        endpoint,
        p256dh,
        auth,
        user_agent: navigator.userAgent,
        last_used_at: new Date().toISOString(),
      },
      { onConflict: "endpoint" },
    );
  if (error) {
    console.error("Failed to save push subscription", error);
    return false;
  }
  return true;
};

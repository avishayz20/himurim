/// <reference lib="webworker" />
import { precacheAndRoute } from "workbox-precaching";
import { NavigationRoute, registerRoute } from "workbox-routing";
import { NetworkFirst } from "workbox-strategies";

declare const self: ServiceWorkerGlobalScope;

// Precache the build assets injected by vite-plugin-pwa
precacheAndRoute(self.__WB_MANIFEST || []);

// NetworkFirst for HTML navigations, deny /~oauth
registerRoute(
  new NavigationRoute(new NetworkFirst({ cacheName: "html", networkTimeoutSeconds: 3 }), {
    denylist: [/^\/~oauth/],
  }),
);

self.addEventListener("install", () => {
  self.skipWaiting();
});
self.addEventListener("activate", (event) => {
  event.waitUntil(self.clients.claim());
});

// Web Push handler — fires even when the app/tab is closed
self.addEventListener("push", (event: PushEvent) => {
  let data: { title?: string; body?: string; tag?: string; url?: string } = {};
  try {
    data = event.data ? event.data.json() : {};
  } catch {
    data = { title: "הימורים ביציע", body: event.data?.text() || "" };
  }
  const title = data.title || "⚽ עוד לא הימרת!";
  const body = data.body || "משחק מתקרב — אל תשכח להמר";
  const tag = data.tag || `match-${Date.now()}`;
  const url = data.url || "/";

  event.waitUntil(
    self.registration.showNotification(title, {
      body,
      tag,
      icon: "/pwa-icon-192.png",
      badge: "/pwa-icon-192.png",
      data: { url },
      dir: "rtl",
      lang: "he",
    }),
  );
});

self.addEventListener("notificationclick", (event: NotificationEvent) => {
  event.notification.close();
  const url = (event.notification.data as { url?: string } | null)?.url || "/";
  event.waitUntil(
    (async () => {
      const clientList = await self.clients.matchAll({ type: "window", includeUncontrolled: true });
      for (const client of clientList) {
        if ("focus" in client) {
          await client.focus();
          if ("navigate" in client) await (client as WindowClient).navigate(url);
          return;
        }
      }
      await self.clients.openWindow(url);
    })(),
  );
});

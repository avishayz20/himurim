import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { CalendarCheck, Play, Square, History, Plus, Trash2 } from "lucide-react";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter, DialogClose,
} from "@/components/ui/dialog";

interface Season {
  id: string;
  name: string;
  started_at: string;
  ended_at: string | null;
  is_active: boolean;
}

interface SeasonManagerProps {
  activeSeasons: Season[];
  pastSeasons: Season[];
  selectedSeasonId: string | null;
  onSelectSeason: (id: string) => void;
  onSeasonChanged: () => void;
  userId: string;
}

const SeasonManager = ({ activeSeasons, pastSeasons, selectedSeasonId, onSelectSeason, onSeasonChanged, userId }: SeasonManagerProps) => {
  const [seasonName, setSeasonName] = useState("");
  const [dialogOpen, setDialogOpen] = useState(false);

  const startSeason = async () => {
    if (!seasonName.trim()) {
      toast.error("נא להזין שם טורניר");
      return;
    }
    const { data, error } = await supabase.from("seasons").insert({
      name: seasonName.trim(),
      created_by: userId,
      is_active: true,
    }).select().single();
    if (error) {
      toast.error("שגיאה בהתחלת טורניר");
      console.error(error);
      return;
    }
    toast.success(`טורניר "${seasonName}" התחיל!`);
    setSeasonName("");
    setDialogOpen(false);
    onSeasonChanged();
    if (data) onSelectSeason(data.id);
  };

  const endSeason = async (season: Season) => {
    const { error } = await supabase
      .from("seasons")
      .update({ is_active: false, ended_at: new Date().toISOString() })
      .eq("id", season.id);
    if (error) {
      toast.error("שגיאה בסיום טורניר");
      return;
    }
    toast.success(`טורניר "${season.name}" הסתיים!`);
    onSeasonChanged();
  };

  const deleteSeason = async (season: Season) => {
    const { error } = await supabase.rpc("delete_season_cascade", { p_season_id: season.id });
    if (error) {
      toast.error("שגיאה במחיקת טורניר");
      console.error(error);
      return;
    }
    toast.success(`טורניר "${season.name}" נמחק!`);
    onSeasonChanged();
  };

  return (
    <Card className="border-border bg-card mb-4">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2 text-lg">
            <CalendarCheck className="w-5 h-5 text-primary" />
            ניהול טורנירים
          </CardTitle>
          <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
            <DialogTrigger asChild>
              <Button size="sm" className="text-xs gap-1.5">
                <Plus className="w-3.5 h-3.5" />
                טורניר חדש
              </Button>
            </DialogTrigger>
            <DialogContent className="max-w-sm">
              <DialogHeader>
                <DialogTitle>טורניר חדש</DialogTitle>
              </DialogHeader>
              <div className="space-y-3 py-2">
                <Input
                  placeholder='למשל: "ליגת האלופות" או "מונדיאל 2026"'
                  value={seasonName}
                  onChange={(e) => setSeasonName(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && startSeason()}
                  dir="rtl"
                />
              </div>
              <DialogFooter>
                <DialogClose asChild>
                  <Button variant="outline" size="sm">ביטול</Button>
                </DialogClose>
                <Button size="sm" onClick={startSeason}>התחל</Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Active tournaments */}
        {activeSeasons.length > 0 ? (
          <div className="space-y-2">
            {activeSeasons.map((s) => (
              <div
                key={s.id}
                onClick={() => onSelectSeason(s.id)}
                className={`flex items-center justify-between p-3 rounded-lg border cursor-pointer transition-colors ${
                  selectedSeasonId === s.id
                    ? "bg-primary/10 border-primary/30"
                    : "bg-secondary border-border hover:bg-secondary/80"
                }`}
              >
                <div>
                  <p className="text-foreground font-medium text-sm flex items-center gap-1.5">
                    <Play className="w-3.5 h-3.5 text-primary fill-primary" />
                    {s.name}
                    {selectedSeasonId === s.id && (
                      <span className="text-[10px] bg-primary/20 text-primary px-1.5 py-0.5 rounded-full">נבחר</span>
                    )}
                  </p>
                  <p className="text-muted-foreground text-xs mt-0.5">
                    התחיל: {new Date(s.started_at).toLocaleDateString("he-IL")}
                  </p>
                </div>
                <div className="flex gap-1.5" onClick={(e) => e.stopPropagation()}>
                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button variant="destructive" size="sm" className="text-xs gap-1.5">
                        <Square className="w-3.5 h-3.5" />
                        סיים
                      </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>סיום טורניר</AlertDialogTitle>
                        <AlertDialogDescription>
                          האם לסיים את הטורניר "{s.name}"? טבלת הדירוג תיארכב. לא ניתן לבטל.
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>ביטול</AlertDialogCancel>
                        <AlertDialogAction className="bg-destructive text-destructive-foreground hover:bg-destructive/90" onClick={() => endSeason(s)}>
                          סיים טורניר
                        </AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                  <AlertDialog>
                    <AlertDialogTrigger asChild>
                      <Button variant="ghost" size="sm" className="text-xs text-destructive hover:text-destructive">
                        <Trash2 className="w-3.5 h-3.5" />
                      </Button>
                    </AlertDialogTrigger>
                    <AlertDialogContent>
                      <AlertDialogHeader>
                        <AlertDialogTitle>מחיקת טורניר</AlertDialogTitle>
                        <AlertDialogDescription>
                          האם למחוק את הטורניר "{s.name}" לצמיתות? כל המשחקים, ההימורים והנתונים יימחקו. לא ניתן לשחזר!
                        </AlertDialogDescription>
                      </AlertDialogHeader>
                      <AlertDialogFooter>
                        <AlertDialogCancel>ביטול</AlertDialogCancel>
                        <AlertDialogAction className="bg-destructive text-destructive-foreground hover:bg-destructive/90" onClick={() => deleteSeason(s)}>
                          מחק לצמיתות
                        </AlertDialogAction>
                      </AlertDialogFooter>
                    </AlertDialogContent>
                  </AlertDialog>
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="flex items-center justify-center p-3 rounded-lg bg-muted border border-border">
            <p className="text-muted-foreground text-sm">אין טורנירים פעילים. צרו טורניר חדש כדי להתחיל!</p>
          </div>
        )}

        {/* Past seasons */}
        {pastSeasons.length > 0 && (
          <div>
            <p className="text-muted-foreground text-xs font-medium mb-2 flex items-center gap-1.5">
              <History className="w-3.5 h-3.5" />
              טורנירים קודמים
            </p>
            <div className="space-y-1.5">
              {pastSeasons.map((s) => (
                <div key={s.id} className="flex items-center justify-between p-2.5 rounded-lg bg-secondary text-sm">
                  <span className="text-foreground font-medium">{s.name}</span>
                  <div className="flex items-center gap-2">
                    <span className="text-muted-foreground text-xs">
                      {new Date(s.started_at).toLocaleDateString("he-IL")}
                      {s.ended_at && ` — ${new Date(s.ended_at).toLocaleDateString("he-IL")}`}
                    </span>
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button variant="ghost" size="sm" className="h-7 w-7 p-0 text-destructive hover:text-destructive">
                          <Trash2 className="w-3.5 h-3.5" />
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent>
                        <AlertDialogHeader>
                          <AlertDialogTitle>מחיקת טורניר</AlertDialogTitle>
                          <AlertDialogDescription>
                            האם למחוק את הטורניר "{s.name}" לצמיתות? כל המשחקים, ההימורים והנתונים יימחקו. לא ניתן לשחזר!
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel>ביטול</AlertDialogCancel>
                          <AlertDialogAction className="bg-destructive text-destructive-foreground hover:bg-destructive/90" onClick={() => deleteSeason(s)}>
                            מחק לצמיתות
                          </AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default SeasonManager;
import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus } from "lucide-react";

interface StageOption {
  key: string;
  label: string;
}

interface AddMatchDialogProps {
  onAdd: (match: { homeTeam: string; awayTeam: string; date: string; time?: string; stageKey?: string | null }) => void;
  stages?: StageOption[];
}

const AddMatchDialog = ({ onAdd, stages = [] }: AddMatchDialogProps) => {
  const [open, setOpen] = useState(false);
  const [homeTeam, setHomeTeam] = useState("");
  const [awayTeam, setAwayTeam] = useState("");
  const [date, setDate] = useState("");
  const [time, setTime] = useState("");
  const [stageKey, setStageKey] = useState<string>("__none__");

  const handleSubmit = () => {
    if (!homeTeam.trim() || !awayTeam.trim() || !date) return;
    onAdd({
      homeTeam: homeTeam.trim(),
      awayTeam: awayTeam.trim(),
      date,
      time: time || undefined,
      stageKey: stageKey === "__none__" ? null : stageKey,
    });
    setHomeTeam(""); setAwayTeam(""); setDate(""); setTime(""); setStageKey("__none__");
    setOpen(false);
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button className="gap-2 bg-primary text-primary-foreground hover:bg-primary/90 glow-primary font-semibold">
          <Plus className="w-4 h-4" />
          הוסף משחק
        </Button>
      </DialogTrigger>
      <DialogContent className="bg-card border-border" dir="rtl">
        <DialogHeader>
          <DialogTitle className="text-foreground text-xl">הוסף משחק חדש</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 mt-4">
          <div>
            <Label className="text-muted-foreground">קבוצת בית</Label>
            <Input value={homeTeam} onChange={(e) => setHomeTeam(e.target.value)} placeholder="למשל: מכבי חיפה" className="bg-secondary border-border text-foreground mt-1" />
          </div>
          <div>
            <Label className="text-muted-foreground">קבוצת חוץ</Label>
            <Input value={awayTeam} onChange={(e) => setAwayTeam(e.target.value)} placeholder="למשל: הפועל באר שבע" className="bg-secondary border-border text-foreground mt-1" />
          </div>
          <div>
            <Label className="text-muted-foreground">תאריך</Label>
            <Input type="date" value={date} onChange={(e) => setDate(e.target.value)} className="bg-secondary border-border text-foreground mt-1" />
          </div>
          <div>
            <Label className="text-muted-foreground">שעה (אופציונלי)</Label>
            <Input type="time" value={time} onChange={(e) => setTime(e.target.value)} className="bg-secondary border-border text-foreground mt-1" />
          </div>
          {stages.length > 0 && (
            <div>
              <Label className="text-muted-foreground">שלב בטורניר (אופציונלי)</Label>
              <Select value={stageKey} onValueChange={setStageKey}>
                <SelectTrigger className="bg-secondary border-border text-foreground mt-1">
                  <SelectValue placeholder="ללא שלב" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="__none__">ללא שלב (ניקוד ברירת מחדל)</SelectItem>
                  {stages.map((s) => (
                    <SelectItem key={s.key} value={s.key}>{s.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          )}
          <Button onClick={handleSubmit} className="w-full bg-primary text-primary-foreground hover:bg-primary/90 font-semibold">
            הוסף
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default AddMatchDialog;

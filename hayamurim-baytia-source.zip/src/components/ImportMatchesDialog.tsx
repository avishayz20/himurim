import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Download, Loader2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { getIsraeliLeagueMatchday, TOTAL_MATCHDAYS } from "@/data/israeliLeague";

const COMPETITIONS = [
  { id: "ISR", name: "🇮🇱 ליגת העל", isLocal: true, hasStages: false },
  { id: "CL", name: "🏆 ליגת האלופות", isLocal: false, hasStages: true, stages: "CL" },
  { id: "WC", name: "🌍 מונדיאל 2026", isLocal: false, hasStages: true, stages: "WC" },
  { id: "PL", name: "🏴󠁧󠁢󠁥󠁮󠁧󠁿 פרמייר ליג", isLocal: false, hasStages: false },
  { id: "PD", name: "🇪🇸 לה ליגה", isLocal: false, hasStages: false },
  { id: "BL1", name: "🇩🇪 בונדסליגה", isLocal: false, hasStages: false },
  { id: "SA", name: "🇮🇹 סריה A", isLocal: false, hasStages: false },
  { id: "FL1", name: "🇫🇷 ליג 1", isLocal: false, hasStages: false },
];

const STAGE_OPTIONS: Record<string, { id: string; name: string }[]> = {
  CL: [
    { id: "LEAGUE_STAGE", name: "שלב הליגה" },
    { id: "KNOCKOUT_ROUND_PLAY_OFFS", name: "פלייאוף נוקאאוט" },
    { id: "LAST_16", name: "שמינית גמר" },
    { id: "QUARTER_FINALS", name: "רבע גמר" },
    { id: "SEMI_FINALS", name: "חצי גמר" },
    { id: "FINAL", name: "גמר" },
  ],
  WC: [
    { id: "GROUP_STAGE", name: "שלב הבתים" },
    { id: "LAST_32", name: "שלושים ושתיים האחרונות" },
    { id: "LAST_16", name: "שמינית גמר" },
    { id: "QUARTER_FINALS", name: "רבע גמר" },
    { id: "SEMI_FINALS", name: "חצי גמר" },
    { id: "THIRD_PLACE", name: "מקום שלישי" },
    { id: "FINAL", name: "גמר" },
  ],
};

interface ImportMatchesDialogProps {
  onImport: (matches: { homeTeam: string; awayTeam: string; date: string; time?: string; isFinished?: boolean; homeScore?: number; awayScore?: number; description?: string; externalId?: string; homeCrest?: string; awayCrest?: string }[]) => void;
}

const ImportMatchesDialog = ({ onImport }: ImportMatchesDialogProps) => {
  const [open, setOpen] = useState(false);
  const [competition, setCompetition] = useState("ISR");
  const [matchday, setMatchday] = useState("1");
  const [selectedStages, setSelectedStages] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);

  const selectedComp = COMPETITIONS.find((c) => c.id === competition);

  const toggleStage = (stageId: string) => {
    setSelectedStages((prev) =>
      prev.includes(stageId) ? prev.filter((s) => s !== stageId) : [...prev, stageId]
    );
  };

  const handleFetch = async () => {
    setLoading(true);
    try {
      if (selectedComp?.isLocal) {
        const md = matchday ? Number(matchday) : 1;
        if (md < 1 || md > TOTAL_MATCHDAYS) {
          toast.error(`מחזור לא תקין. בחר בין 1 ל-${TOTAL_MATCHDAYS}`);
          return;
        }
        const matches = getIsraeliLeagueMatchday(md);
        onImport(matches);
        toast.success(`יובאו ${matches.length} משחקי מחזור ${md} של ליגת העל!`);
        setOpen(false);
      } else if (selectedComp?.hasStages && selectedStages.length > 0) {
        // Fetch multiple stages in parallel
        const results = await Promise.all(
          selectedStages.map((stage) =>
            supabase.functions.invoke("fetch-matches", {
              body: { competitionId: competition, stage },
            })
          )
        );

        const allMatches: any[] = [];
        for (const { data, error } of results) {
          if (error) throw error;
          if (!data?.success) throw new Error(data?.error || "Failed to fetch matches");
          allMatches.push(
            ...data.matches.map((m: any) => ({
              homeTeam: m.homeTeam,
              awayTeam: m.awayTeam,
              date: m.date,
              time: m.time,
              homeScore: m.homeScore,
              awayScore: m.awayScore,
              isFinished: m.isFinished,
              description: m.description,
              externalId: m.externalId,
              homeCrest: m.homeCrest,
              awayCrest: m.awayCrest,
            }))
          );
        }
        onImport(allMatches);
        toast.success(`יובאו ${allMatches.length} משחקים בהצלחה!`);
        setOpen(false);
      } else {
        const { data, error } = await supabase.functions.invoke("fetch-matches", {
          body: {
            competitionId: competition,
            matchday: matchday ? Number(matchday) : undefined,
          },
        });
        if (error) throw error;
        if (!data?.success) throw new Error(data?.error || "Failed to fetch matches");

        const matches = data.matches.map((m: any) => ({
          homeTeam: m.homeTeam,
          awayTeam: m.awayTeam,
          date: m.date,
          time: m.time,
          homeScore: m.homeScore,
          awayScore: m.awayScore,
          isFinished: m.isFinished,
          description: m.description,
          externalId: m.externalId,
          homeCrest: m.homeCrest,
          awayCrest: m.awayCrest,
        }));
        onImport(matches);
        toast.success(`יובאו ${matches.length} משחקים בהצלחה!`);
        setOpen(false);
      }
    } catch (err: any) {
      console.error("Error fetching matches:", err);
      toast.error(err.message || "שגיאה בייבוא משחקים");
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" className="gap-2 border-accent/50 text-accent hover:bg-accent/10">
          <Download className="w-4 h-4" />
          ייבוא משחקים
        </Button>
      </DialogTrigger>
      <DialogContent className="bg-card border-border" dir="rtl">
        <DialogHeader>
          <DialogTitle className="text-foreground text-xl">ייבוא משחקים</DialogTitle>
        </DialogHeader>
        <div className="space-y-4 mt-4">
          <div>
            <Label className="text-muted-foreground">ליגה</Label>
            <Select value={competition} onValueChange={(v) => { setCompetition(v); setSelectedStages([]); }}>
              <SelectTrigger className="bg-secondary border-border text-foreground mt-1">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-card border-border">
                {COMPETITIONS.map((c) => (
                  <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          {selectedComp?.hasStages && (
            <div>
              <Label className="text-muted-foreground">שלבים (ניתן לבחור מספר שלבים)</Label>
              <div className="grid grid-cols-2 gap-2 mt-2">
                {(STAGE_OPTIONS[selectedComp.stages || "CL"] || []).map((s) => (
                  <label
                    key={s.id}
                    className={`flex items-center gap-2 p-2 rounded-md cursor-pointer border transition-colors ${
                      selectedStages.includes(s.id)
                        ? "border-primary bg-primary/10"
                        : "border-border bg-secondary hover:bg-secondary/80"
                    }`}
                  >
                    <Checkbox
                      checked={selectedStages.includes(s.id)}
                      onCheckedChange={() => toggleStage(s.id)}
                    />
                    <span className="text-sm text-foreground">{s.name}</span>
                  </label>
                ))}
              </div>
            </div>
          )}
          {!selectedComp?.hasStages && (
            <div>
              <Label className="text-muted-foreground">
                מחזור {selectedComp?.isLocal ? `(1-${TOTAL_MATCHDAYS})` : "(אופציונלי)"}
              </Label>
              <Input
                type="number"
                min={1}
                max={selectedComp?.isLocal ? TOTAL_MATCHDAYS : undefined}
                value={matchday}
                onChange={(e) => setMatchday(e.target.value)}
                placeholder={selectedComp?.isLocal ? "בחר מחזור" : "השאר ריק לכל המשחקים"}
                className="bg-secondary border-border text-foreground mt-1"
              />
            </div>
          )}
          <Button onClick={handleFetch} disabled={loading} className="w-full bg-primary text-primary-foreground hover:bg-primary/90 font-semibold">
            {loading ? <Loader2 className="w-4 h-4 animate-spin ml-2" /> : null}
            {loading ? "מייבא..." : "ייבא משחקים"}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default ImportMatchesDialog;

import { useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/hooks/useAuth";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { User, Lock, Trophy, Target, Hash, Pencil, Check, X } from "lucide-react";
import { toast } from "sonner";

interface Profile {
  id: string;
  display_name: string;
}

interface DbBet {
  id: string;
  match_id: string;
  user_id: string;
  home_score: number;
  away_score: number;
  points: number | null;
}

interface DbMatch {
  id: string;
  home_team: string;
  away_team: string;
  match_date: string;
  match_time: string | null;
  home_score: number | null;
  away_score: number | null;
  is_finished: boolean;
}

interface ProfileSectionProps {
  profiles: Profile[];
  bets: DbBet[];
  matches: DbMatch[];
  currentUserId: string;
  onProfileUpdated: () => void;
}

const ProfileSection = ({ profiles, bets, matches, currentUserId, onProfileUpdated }: ProfileSectionProps) => {
  const { user } = useAuth();
  const [editingName, setEditingName] = useState(false);
  const [newName, setNewName] = useState("");
  const [changingPassword, setChangingPassword] = useState(false);
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");

  const currentProfile = profiles.find((p) => p.id === currentUserId);
  const myBets = bets.filter((b) => b.user_id === currentUserId);
  const scoredBets = myBets.filter((b) => b.points !== null && b.points !== undefined);
  const totalPoints = scoredBets.reduce((sum, b) => sum + (b.points || 0), 0);
  const exactHits = scoredBets.filter((b) => b.points === 3).length;
  const directionHits = scoredBets.filter((b) => b.points === 1).length;
  const totalBets = myBets.length;
  const avgPoints = scoredBets.length > 0 ? (totalPoints / scoredBets.length).toFixed(2) : "0";

  const startEditName = () => {
    setNewName(currentProfile?.display_name || "");
    setEditingName(true);
  };

  const saveDisplayName = async () => {
    if (!newName.trim()) { toast.error("שם תצוגה לא יכול להיות ריק"); return; }
    const { error } = await supabase.from("profiles").update({ display_name: newName.trim() }).eq("id", currentUserId);
    if (error) { toast.error("שגיאה בעדכון שם"); return; }
    toast.success("השם עודכן בהצלחה!");
    setEditingName(false);
    onProfileUpdated();
  };

  const handleChangePassword = async () => {
    if (newPassword.length < 6) { toast.error("סיסמה חייבת להכיל לפחות 6 תווים"); return; }
    if (newPassword !== confirmPassword) { toast.error("הסיסמאות לא תואמות"); return; }
    const { error } = await supabase.auth.updateUser({ password: newPassword });
    if (error) { toast.error("שגיאה בעדכון סיסמה"); return; }
    toast.success("הסיסמה עודכנה בהצלחה!");
    setChangingPassword(false);
    setNewPassword("");
    setConfirmPassword("");
  };

  // Get bet history with match details
  const betHistory = myBets
    .map((bet) => {
      const match = matches.find((m) => m.id === bet.match_id);
      return { ...bet, match };
    })
    .filter((b) => b.match)
    .sort((a, b) => {
      const dateA = a.match!.match_date;
      const dateB = b.match!.match_date;
      return dateB.localeCompare(dateA);
    });

  return (
    <div className="space-y-6">
      {/* Profile Info */}
      <Card className="border-border bg-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg">
            <User className="w-5 h-5 text-primary" />
            פרטים אישיים
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label className="text-muted-foreground text-xs">אימייל</Label>
            <p className="text-foreground text-sm">{user?.email}</p>
          </div>
          <div>
            <Label className="text-muted-foreground text-xs">שם תצוגה</Label>
            {editingName ? (
              <div className="flex gap-2 mt-1">
                <Input
                  value={newName}
                  onChange={(e) => setNewName(e.target.value)}
                  className="h-8 text-sm"
                  autoFocus
                  onKeyDown={(e) => e.key === "Enter" && saveDisplayName()}
                />
                <Button size="icon" variant="ghost" className="h-8 w-8 text-primary" onClick={saveDisplayName}>
                  <Check className="w-4 h-4" />
                </Button>
                <Button size="icon" variant="ghost" className="h-8 w-8 text-muted-foreground" onClick={() => setEditingName(false)}>
                  <X className="w-4 h-4" />
                </Button>
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <p className="text-foreground text-sm">{currentProfile?.display_name}</p>
                <Button size="icon" variant="ghost" className="h-6 w-6 text-muted-foreground hover:text-primary" onClick={startEditName}>
                  <Pencil className="w-3 h-3" />
                </Button>
              </div>
            )}
          </div>
          <Separator />
          <div>
            <Label className="text-muted-foreground text-xs flex items-center gap-1">
              <Lock className="w-3 h-3" />
              סיסמה
            </Label>
            {changingPassword ? (
              <div className="space-y-2 mt-2">
                <Input
                  type="password"
                  placeholder="סיסמה חדשה"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  className="h-8 text-sm"
                />
                <Input
                  type="password"
                  placeholder="אימות סיסמה"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  className="h-8 text-sm"
                />
                <div className="flex gap-2">
                  <Button size="sm" onClick={handleChangePassword} className="text-xs">שמור</Button>
                  <Button size="sm" variant="ghost" onClick={() => { setChangingPassword(false); setNewPassword(""); setConfirmPassword(""); }} className="text-xs">ביטול</Button>
                </div>
              </div>
            ) : (
              <Button size="sm" variant="outline" onClick={() => setChangingPassword(true)} className="mt-1 text-xs">
                שנה סיסמה
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Stats */}
      <Card className="border-border bg-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg">
            <Trophy className="w-5 h-5 text-accent" />
            סטטיסטיקות
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div className="text-center p-3 rounded-lg bg-secondary">
              <p className="text-2xl font-bold text-primary">{totalPoints}</p>
              <p className="text-xs text-muted-foreground">סה״כ נקודות</p>
            </div>
            <div className="text-center p-3 rounded-lg bg-secondary">
              <p className="text-2xl font-bold text-accent">{exactHits}</p>
              <p className="text-xs text-muted-foreground">דיוקים מושלמים</p>
            </div>
            <div className="text-center p-3 rounded-lg bg-secondary">
              <p className="text-2xl font-bold text-foreground">{directionHits}</p>
              <p className="text-xs text-muted-foreground">כיוונים נכונים</p>
            </div>
            <div className="text-center p-3 rounded-lg bg-secondary">
              <p className="text-2xl font-bold text-foreground">{totalBets}</p>
              <p className="text-xs text-muted-foreground">סה״כ הימורים</p>
            </div>
          </div>
          <div className="mt-3 text-center">
            <p className="text-xs text-muted-foreground">ממוצע נקודות להימור: <span className="text-foreground font-medium">{avgPoints}</span></p>
          </div>
        </CardContent>
      </Card>

      {/* Bet History */}
      <Card className="border-border bg-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-lg">
            <Hash className="w-5 h-5 text-primary" />
            היסטוריית הימורים
          </CardTitle>
        </CardHeader>
        <CardContent>
          {betHistory.length === 0 ? (
            <p className="text-muted-foreground text-sm text-center py-4">עדיין לא הצבת הימורים</p>
          ) : (
            <div className="space-y-2 max-h-96 overflow-y-auto">
              {betHistory.map((item) => (
                <div key={item.id} className="flex items-center justify-between p-3 rounded-lg bg-secondary text-sm">
                  <div className="flex-1">
                    <p className="text-foreground font-medium text-xs">
                      {item.match!.home_team} vs {item.match!.away_team}
                    </p>
                    <p className="text-muted-foreground text-xs">{item.match!.match_date}</p>
                  </div>
                  <div className="text-center px-3">
                    <p className="text-foreground font-bold">{item.home_score} - {item.away_score}</p>
                    <p className="text-muted-foreground text-xs">הניחוש שלי</p>
                  </div>
                  {item.match!.is_finished && (
                    <div className="text-center px-3">
                      <p className="text-muted-foreground font-medium">{item.match!.home_score} - {item.match!.away_score}</p>
                      <p className="text-muted-foreground text-xs">תוצאה</p>
                    </div>
                  )}
                  <div className={`min-w-[40px] text-center font-bold text-sm ${
                    item.points === 3 ? "text-accent" : item.points === 1 ? "text-primary" : "text-muted-foreground"
                  }`}>
                    {item.points !== null && item.points !== undefined ? `${item.points} נק׳` : "—"}
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default ProfileSection;

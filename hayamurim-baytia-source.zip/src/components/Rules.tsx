import { useState, useEffect } from "react";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { ScrollText, Pencil, Check, X, Plus, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

import StageScoringManager from "@/components/StageScoringManager";

interface RuleSection {
  id: string;
  section_key: string;
  title: string;
  emoji: string;
  content: string;
  sort_order: number;
}

interface RulesProps {
  isAdmin?: boolean;
  seasonId?: string | null;
}

const Rules = ({ isAdmin = false, seasonId = null }: RulesProps) => {
  const [rules, setRules] = useState<RuleSection[]>([]);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editTitle, setEditTitle] = useState("");
  const [editEmoji, setEditEmoji] = useState("");
  const [editContent, setEditContent] = useState("");
  const [adding, setAdding] = useState(false);
  const [newTitle, setNewTitle] = useState("");
  const [newEmoji, setNewEmoji] = useState("📌");
  const [newContent, setNewContent] = useState("");

  const fetchRules = async () => {
    const { data } = await supabase.from("rules").select("*").order("sort_order", { ascending: true });
    if (data) setRules(data as RuleSection[]);
  };

  useEffect(() => { fetchRules(); }, []);

  const startEdit = (rule: RuleSection) => {
    setEditingId(rule.id);
    setEditTitle(rule.title);
    setEditEmoji(rule.emoji);
    setEditContent(rule.content);
  };

  const saveEdit = async () => {
    if (!editingId) return;
    const { error } = await supabase.from("rules").update({
      title: editTitle,
      emoji: editEmoji,
      content: editContent,
      updated_at: new Date().toISOString(),
    } as any).eq("id", editingId);
    if (error) { toast.error("שגיאה בשמירה"); return; }
    toast.success("החוק עודכן");
    setEditingId(null);
    fetchRules();
  };

  const addRule = async () => {
    if (!newTitle.trim() || !newContent.trim()) return;
    const key = `custom_${Date.now()}`;
    const { error } = await supabase.from("rules").insert({
      section_key: key,
      title: newTitle,
      emoji: newEmoji,
      content: newContent,
      sort_order: rules.length + 1,
    } as any);
    if (error) { toast.error("שגיאה בהוספה"); return; }
    toast.success("חוק חדש נוסף");
    setAdding(false);
    setNewTitle("");
    setNewContent("");
    fetchRules();
  };

  const deleteRule = async (id: string) => {
    const { error } = await supabase.from("rules").delete().eq("id", id);
    if (error) { toast.error("שגיאה במחיקה"); return; }
    toast.success("החוק נמחק");
    fetchRules();
  };

  // Simple markdown-ish bold rendering
  const renderContent = (text: string) => {
    return text.split("\n").map((line, i) => {
      const parts = line.split(/\*\*(.*?)\*\*/g);
      return (
        <p key={i}>
          {parts.map((part, j) =>
            j % 2 === 1 ? <strong key={j} className="text-foreground">{part}</strong> : part
          )}
        </p>
      );
    });
  };

  return (
    <div className="space-y-4" dir="rtl">
      <StageScoringManager seasonId={seasonId} isAdmin={isAdmin} />
      <div className="rounded-xl border border-border bg-card p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-accent/20 flex items-center justify-center">
            <ScrollText className="w-5 h-5 text-accent" />
          </div>
          <h2 className="text-xl font-bold text-foreground">חוקי התחרות</h2>
        </div>
        {isAdmin && !adding && (
          <Button variant="outline" size="sm" onClick={() => setAdding(true)} className="text-xs gap-1.5">
            <Plus className="w-3.5 h-3.5" />
            הוסף חוק
          </Button>
        )}
      </div>

      {/* Add new rule form */}
      {adding && (
        <div className="mb-4 p-4 rounded-lg border border-primary/30 bg-primary/5 space-y-3">
          <div className="flex gap-2">
            <Input value={newEmoji} onChange={(e) => setNewEmoji(e.target.value)} className="w-16 text-center bg-secondary border-border" placeholder="🎯" />
            <Input value={newTitle} onChange={(e) => setNewTitle(e.target.value)} className="flex-1 bg-secondary border-border" placeholder="כותרת החוק" />
          </div>
          <Textarea value={newContent} onChange={(e) => setNewContent(e.target.value)} className="bg-secondary border-border min-h-[80px] text-sm" placeholder="תוכן (השתמש ב-**טקסט** להדגשה)" />
          <div className="flex gap-2">
            <Button size="sm" onClick={addRule}><Check className="w-3.5 h-3.5 ml-1" />שמור</Button>
            <Button size="sm" variant="outline" onClick={() => setAdding(false)}><X className="w-3.5 h-3.5" /></Button>
          </div>
        </div>
      )}

      <Accordion type="single" collapsible className="space-y-2">
        {rules.map((rule) => (
          <AccordionItem key={rule.id} value={rule.section_key} className="border-border">
            <AccordionTrigger className="text-foreground hover:no-underline text-sm font-semibold">
              <div className="flex items-center gap-2 flex-1">
                <span>{rule.emoji} {rule.title}</span>
              </div>
            </AccordionTrigger>
            <AccordionContent className="text-muted-foreground text-sm space-y-2">
              {editingId === rule.id ? (
                <div className="space-y-3 pt-2">
                  <div className="flex gap-2">
                    <Input value={editEmoji} onChange={(e) => setEditEmoji(e.target.value)} className="w-16 text-center bg-secondary border-border" />
                    <Input value={editTitle} onChange={(e) => setEditTitle(e.target.value)} className="flex-1 bg-secondary border-border" />
                  </div>
                  <Textarea value={editContent} onChange={(e) => setEditContent(e.target.value)} className="bg-secondary border-border min-h-[80px] text-sm" />
                  <div className="flex gap-2">
                    <Button size="sm" onClick={saveEdit}><Check className="w-3.5 h-3.5 ml-1" />שמור</Button>
                    <Button size="sm" variant="outline" onClick={() => setEditingId(null)}><X className="w-3.5 h-3.5" /></Button>
                  </div>
                </div>
              ) : (
                <>
                  {renderContent(rule.content)}
                  {isAdmin && (
                    <div className="flex gap-2 pt-2">
                      <Button variant="ghost" size="sm" className="text-xs gap-1 text-muted-foreground hover:text-primary" onClick={() => startEdit(rule)}>
                        <Pencil className="w-3 h-3" />ערוך
                      </Button>
                      <Button variant="ghost" size="sm" className="text-xs gap-1 text-muted-foreground hover:text-destructive" onClick={() => deleteRule(rule.id)}>
                        <Trash2 className="w-3 h-3" />מחק
                      </Button>
                    </div>
                  )}
                </>
              )}
            </AccordionContent>
          </AccordionItem>
        ))}
      </Accordion>

      {rules.length === 0 && (
        <p className="text-center text-muted-foreground py-6">אין חוקים עדיין</p>
      )}
      </div>
    </div>
  );
};

export default Rules;

import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
import { Trophy, Plus, Trash2, Check, X, Pencil } from "lucide-react";
import { DEFAULT_STAGES } from "@/lib/stages";

export interface StageScoring {
  id: string;
  season_id: string;
  stage_key: string;
  stage_label: string;
  exact_points: number;
  direction_points: number;
  sort_order: number;
}

interface Props {
  seasonId: string | null;
  isAdmin: boolean;
}

const StageScoringManager = ({ seasonId, isAdmin }: Props) => {
  const [stages, setStages] = useState<StageScoring[]>([]);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editLabel, setEditLabel] = useState("");
  const [editExact, setEditExact] = useState(0);
  const [editDir, setEditDir] = useState(0);
  const [adding, setAdding] = useState(false);
  const [newKey, setNewKey] = useState("");
  const [newLabel, setNewLabel] = useState("");
  const [newExact, setNewExact] = useState(3);
  const [newDir, setNewDir] = useState(1);
  const [loading, setLoading] = useState(false);

  const fetchStages = async () => {
    if (!seasonId) {
      setStages([]);
      return;
    }
    const { data } = await supabase
      .from("season_stage_scoring" as any)
      .select("*")
      .eq("season_id", seasonId)
      .order("sort_order", { ascending: true });
    if (data) setStages(data as any);
  };

  useEffect(() => {
    fetchStages();
  }, [seasonId]);

  const seedDefaults = async () => {
    if (!seasonId) return;
    setLoading(true);
    const rows = DEFAULT_STAGES.map((s, i) => ({
      season_id: seasonId,
      stage_key: s.key,
      stage_label: s.label,
      exact_points: s.defaultExact,
      direction_points: s.defaultDirection,
      sort_order: i,
    }));
    const { error } = await supabase.from("season_stage_scoring" as any).insert(rows);
    setLoading(false);
    if (error) {
      toast.error("שגיאה בטעינת ברירת מחדל");
      return;
    }
    toast.success("נטענו שלבים ברירת מחדל");
    fetchStages();
  };

  const startEdit = (s: StageScoring) => {
    setEditingId(s.id);
    setEditLabel(s.stage_label);
    setEditExact(s.exact_points);
    setEditDir(s.direction_points);
  };

  const saveEdit = async () => {
    if (!editingId) return;
    const { error } = await supabase
      .from("season_stage_scoring" as any)
      .update({
        stage_label: editLabel,
        exact_points: editExact,
        direction_points: editDir,
      })
      .eq("id", editingId);
    if (error) {
      toast.error("שגיאה בשמירה");
      return;
    }
    toast.success("עודכן");
    setEditingId(null);
    fetchStages();
  };

  const deleteStage = async (id: string) => {
    const { error } = await supabase.from("season_stage_scoring" as any).delete().eq("id", id);
    if (error) {
      toast.error("שגיאה במחיקה");
      return;
    }
    toast.success("נמחק");
    fetchStages();
  };

  const addStage = async () => {
    if (!seasonId || !newKey.trim() || !newLabel.trim()) {
      toast.error("מפתח ושם נדרשים");
      return;
    }
    const { error } = await supabase.from("season_stage_scoring" as any).insert({
      season_id: seasonId,
      stage_key: newKey.trim(),
      stage_label: newLabel.trim(),
      exact_points: newExact,
      direction_points: newDir,
      sort_order: stages.length,
    });
    if (error) {
      toast.error("שגיאה (אולי המפתח קיים)");
      return;
    }
    toast.success("נוסף");
    setAdding(false);
    setNewKey("");
    setNewLabel("");
    setNewExact(3);
    setNewDir(1);
    fetchStages();
  };

  if (!seasonId) {
    return (
      <div className="rounded-xl border border-border bg-card p-4 text-center text-sm text-muted-foreground" dir="rtl">
        בחר עונה כדי להגדיר ניקוד לפי שלב
      </div>
    );
  }

  return (
    <div className="rounded-xl border border-border bg-card p-5" dir="rtl">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-primary/20 flex items-center justify-center">
            <Trophy className="w-5 h-5 text-primary" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-foreground">ניקוד לפי שלב</h3>
            <p className="text-[11px] text-muted-foreground">לכל שלב נקודות מדויק/כיוון משלו</p>
          </div>
        </div>
        {isAdmin && stages.length === 0 && (
          <Button size="sm" onClick={seedDefaults} disabled={loading} className="text-xs">
            טען שלבי מונדיאל
          </Button>
        )}
      </div>

      {stages.length === 0 ? (
        <p className="text-center text-muted-foreground py-6 text-sm">
          עדיין לא הוגדרו שלבים. בלי הגדרה - הניקוד יהיה 3 למדויק / 1 לכיוון.
        </p>
      ) : (
        <div className="space-y-2">
          <div className="grid grid-cols-[1fr_auto_auto_auto] gap-2 px-2 py-1 text-[11px] font-semibold text-muted-foreground">
            <span>שלב</span>
            <span className="w-14 text-center">מדויק</span>
            <span className="w-14 text-center">כיוון</span>
            {isAdmin && <span className="w-16" />}
          </div>
          {stages.map((s) => (
            <div key={s.id} className="grid grid-cols-[1fr_auto_auto_auto] gap-2 items-center bg-secondary/30 rounded-lg px-2 py-2">
              {editingId === s.id ? (
                <>
                  <Input value={editLabel} onChange={(e) => setEditLabel(e.target.value)} className="h-8 bg-background border-border text-sm" />
                  <Input type="number" value={editExact} onChange={(e) => setEditExact(parseInt(e.target.value) || 0)} className="h-8 w-14 text-center bg-background border-border text-sm" />
                  <Input type="number" value={editDir} onChange={(e) => setEditDir(parseInt(e.target.value) || 0)} className="h-8 w-14 text-center bg-background border-border text-sm" />
                  <div className="flex gap-1">
                    <Button size="sm" variant="ghost" onClick={saveEdit} className="h-8 w-8 p-0 text-primary"><Check className="w-4 h-4" /></Button>
                    <Button size="sm" variant="ghost" onClick={() => setEditingId(null)} className="h-8 w-8 p-0"><X className="w-4 h-4" /></Button>
                  </div>
                </>
              ) : (
                <>
                  <span className="text-sm text-foreground font-medium">{s.stage_label}</span>
                  <span className="w-14 text-center text-sm font-bold text-primary">{s.exact_points}</span>
                  <span className="w-14 text-center text-sm font-bold text-accent">{s.direction_points}</span>
                  {isAdmin && (
                    <div className="flex gap-1">
                      <Button size="sm" variant="ghost" onClick={() => startEdit(s)} className="h-8 w-8 p-0 text-muted-foreground hover:text-primary"><Pencil className="w-3.5 h-3.5" /></Button>
                      <Button size="sm" variant="ghost" onClick={() => deleteStage(s.id)} className="h-8 w-8 p-0 text-muted-foreground hover:text-destructive"><Trash2 className="w-3.5 h-3.5" /></Button>
                    </div>
                  )}
                </>
              )}
            </div>
          ))}
        </div>
      )}

      {isAdmin && (
        <div className="mt-4">
          {adding ? (
            <div className="p-3 rounded-lg border border-primary/30 bg-primary/5 space-y-2">
              <div className="grid grid-cols-2 gap-2">
                <Input placeholder="מפתח (אנגלית: round_of_8)" value={newKey} onChange={(e) => setNewKey(e.target.value)} className="bg-background border-border text-sm" />
                <Input placeholder="שם בעברית" value={newLabel} onChange={(e) => setNewLabel(e.target.value)} className="bg-background border-border text-sm" />
              </div>
              <div className="grid grid-cols-2 gap-2">
                <Input type="number" placeholder="מדויק" value={newExact} onChange={(e) => setNewExact(parseInt(e.target.value) || 0)} className="bg-background border-border text-sm" />
                <Input type="number" placeholder="כיוון" value={newDir} onChange={(e) => setNewDir(parseInt(e.target.value) || 0)} className="bg-background border-border text-sm" />
              </div>
              <div className="flex gap-2">
                <Button size="sm" onClick={addStage}><Check className="w-3.5 h-3.5 ml-1" />הוסף</Button>
                <Button size="sm" variant="outline" onClick={() => setAdding(false)}><X className="w-3.5 h-3.5" /></Button>
              </div>
            </div>
          ) : (
            <Button variant="outline" size="sm" onClick={() => setAdding(true)} className="text-xs gap-1.5">
              <Plus className="w-3.5 h-3.5" />
              הוסף שלב מותאם
            </Button>
          )}
        </div>
      )}
    </div>
  );
};

export default StageScoringManager;

import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { supabase } from "@/integrations/supabase/client";
import { History, Trophy, ChevronDown, ChevronUp, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { PlayerStats } from "@/types/betting";
import Leaderboard from "@/components/Leaderboard";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

interface Season {
  id: string;
  name: string;
  started_at: string;
  ended_at: string | null;
  is_active: boolean;
}

interface SeasonHistoryProps {
  pastSeasons: Season[];
  profiles: { id: string; display_name: string }[];
  isAdmin?: boolean;
  onSeasonDeleted?: () => void;
}

const SeasonHistory = ({ pastSeasons, profiles, isAdmin, onSeasonDeleted }: SeasonHistoryProps) => {
  const [expandedSeason, setExpandedSeason] = useState<string | null>(null);
  const [seasonStats, setSeasonStats] = useState<Record<string, PlayerStats[]>>({});

  const getDisplayName = (userId: string) =>
    profiles.find((p) => p.id === userId)?.display_name || "אנונימי";

  const loadSeasonStats = async (seasonId: string) => {
    if (seasonStats[seasonId]) {
      setExpandedSeason(expandedSeason === seasonId ? null : seasonId);
      return;
    }

    // Get matches for this season
    const { data: matches } = await supabase
      .from("matches")
      .select("id")
      .eq("season_id", seasonId)
      .eq("is_finished", true);

    if (!matches || matches.length === 0) {
      setSeasonStats((prev) => ({ ...prev, [seasonId]: [] }));
      setExpandedSeason(seasonId);
      return;
    }

    const matchIds = matches.map((m) => m.id);
    const { data: bets } = await supabase
      .from("bets")
      .select("*")
      .in("match_id", matchIds);

    const map = new Map<string, PlayerStats>();
    profiles.forEach((p) => {
      map.set(p.display_name, { name: p.display_name, totalPoints: 0, totalBets: 0, exactHits: 0, directionHits: 0 });
    });

    (bets || []).forEach((bet) => {
      if (bet.points === null || bet.points === undefined) return;
      const name = getDisplayName(bet.user_id);
      const existing = map.get(name) || { name, totalPoints: 0, totalBets: 0, exactHits: 0, directionHits: 0 };
      existing.totalBets++;
      existing.totalPoints += bet.points;
      if (bet.points === 3) existing.exactHits++;
      if (bet.points === 1) existing.directionHits++;
      map.set(name, existing);
    });

    const stats = Array.from(map.values()).filter((s) => s.totalBets > 0);
    setSeasonStats((prev) => ({ ...prev, [seasonId]: stats }));
    setExpandedSeason(seasonId);
  };

  const deleteSeason = async (seasonId: string, seasonName: string) => {
    const { error } = await supabase.rpc("delete_season_cascade", { p_season_id: seasonId });
    if (error) {
      toast.error("שגיאה במחיקת טורניר");
      console.error(error);
      return;
    }
    toast.success(`טורניר "${seasonName}" נמחק!`);
    onSeasonDeleted?.();
  };

  if (pastSeasons.length === 0) {
    return (
      <div className="text-center py-20">
        <History className="w-12 h-12 mx-auto mb-4 text-muted-foreground/30" />
        <p className="text-muted-foreground text-lg">אין עונות קודמות</p>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {pastSeasons.map((season) => {
        const isExpanded = expandedSeason === season.id;
        return (
          <Card key={season.id} className="border-border bg-card">
            <CardHeader className="pb-2 cursor-pointer" onClick={() => loadSeasonStats(season.id)}>
              <CardTitle className="flex items-center justify-between text-base">
                <div className="flex items-center gap-2">
                  <Trophy className="w-4 h-4 text-primary" />
                  {season.name}
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-muted-foreground text-xs font-normal">
                    {new Date(season.started_at).toLocaleDateString("he-IL")}
                    {season.ended_at && ` — ${new Date(season.ended_at).toLocaleDateString("he-IL")}`}
                  </span>
                  {isAdmin && (
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button variant="ghost" size="sm" className="h-7 w-7 p-0 text-destructive hover:text-destructive" onClick={(e) => e.stopPropagation()}>
                          <Trash2 className="w-3.5 h-3.5" />
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent>
                        <AlertDialogHeader>
                          <AlertDialogTitle>מחיקת טורניר</AlertDialogTitle>
                          <AlertDialogDescription>
                            האם למחוק את הטורניר "{season.name}" לצמיתות? כל המשחקים, ההימורים והנתונים יימחקו. לא ניתן לשחזר!
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel>ביטול</AlertDialogCancel>
                          <AlertDialogAction className="bg-destructive text-destructive-foreground hover:bg-destructive/90" onClick={() => deleteSeason(season.id, season.name)}>
                            מחק לצמיתות
                          </AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  )}
                  {isExpanded ? <ChevronUp className="w-4 h-4 text-muted-foreground" /> : <ChevronDown className="w-4 h-4 text-muted-foreground" />}
                </div>
              </CardTitle>
            </CardHeader>
            {isExpanded && (
              <CardContent>
                {seasonStats[season.id]?.length ? (
                  <Leaderboard stats={seasonStats[season.id]} />
                ) : (
                  <p className="text-muted-foreground text-sm text-center py-4">אין נתונים לעונה זו</p>
                )}
              </CardContent>
            )}
          </Card>
        );
      })}
    </div>
  );
};

export default SeasonHistory;

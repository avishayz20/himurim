import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Star, Plus, Check, X, Clock, Lock, Trophy, Pencil, Trash2 } from "lucide-react";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter, DialogClose,
} from "@/components/ui/dialog";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

interface SpecialBet {
  id: string;
  question: string;
  bet_type: string;
  options: string[] | null;
  correct_answer: string | null;
  points_reward: number;
  is_closed: boolean;
  is_resolved: boolean;
  deadline: string | null;
  season_id: string | null;
}

interface SpecialBetAnswer {
  id: string;
  special_bet_id: string;
  user_id: string;
  answer: string;
  points: number | null;
}

interface Season {
  id: string;
  name: string;
  is_active: boolean;
}

interface SpecialBetsProps {
  isAdmin: boolean;
  currentUserId: string;
  seasonId: string | null;
  profiles: { id: string; display_name: string }[];
  seasons?: Season[];
}

const SpecialBets = ({ isAdmin, currentUserId, seasonId, profiles, seasons = [] }: SpecialBetsProps) => {
  const [bets, setBets] = useState<SpecialBet[]>([]);
  const [answers, setAnswers] = useState<SpecialBetAnswer[]>([]);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [newQuestion, setNewQuestion] = useState("");
  const [newType, setNewType] = useState<"open" | "options">("open");
  const [newOptions, setNewOptions] = useState("");
  const [newPoints, setNewPoints] = useState("5");
  const [newDeadline, setNewDeadline] = useState("");
  const [userAnswers, setUserAnswers] = useState<Record<string, string>>({});
  const [resolveId, setResolveId] = useState<string | null>(null);
  const [resolveAnswer, setResolveAnswer] = useState("");

  const getDisplayName = (userId: string) => profiles.find((p) => p.id === userId)?.display_name || "אנונימי";

  const fetchData = async () => {
    const [betRes, ansRes] = await Promise.all([
      supabase.from("special_bets").select("*").order("created_at", { ascending: false }),
      supabase.from("special_bet_answers").select("*"),
    ]);
    if (betRes.data) {
      const filtered = seasonId
        ? (betRes.data as SpecialBet[]).filter((b) => b.season_id === seasonId)
        : (betRes.data as SpecialBet[]);
      setBets(filtered);
    }
    if (ansRes.data) setAnswers(ansRes.data as SpecialBetAnswer[]);
  };

  useEffect(() => { fetchData(); }, [seasonId]);

  const createBet = async () => {
    if (!newQuestion.trim()) return;
    const opts = newType === "options" ? newOptions.split(",").map((o) => o.trim()).filter(Boolean) : null;
    const { error } = await supabase.from("special_bets").insert({
      question: newQuestion,
      bet_type: newType,
      options: opts,
      points_reward: Number(newPoints) || 5,
      deadline: newDeadline || null,
      season_id: seasonId,
      created_by: currentUserId,
    } as any);
    if (error) { toast.error("שגיאה ביצירת הימור"); return; }
    toast.success("הימור מיוחד נוצר!");
    setDialogOpen(false);
    setNewQuestion("");
    setNewOptions("");
    setNewPoints("5");
    setNewDeadline("");
    fetchData();
  };

  const submitAnswer = async (betId: string) => {
    const answer = userAnswers[betId];
    if (!answer?.trim()) return;
    const existing = answers.find((a) => a.special_bet_id === betId && a.user_id === currentUserId);
    if (existing) {
      const { error } = await supabase.from("special_bet_answers").update({ answer, updated_at: new Date().toISOString() } as any).eq("id", existing.id);
      if (error) {
        if (error.message?.includes("row-level security")) toast.error("החשבון שלך מוקפא");
        else toast.error("שגיאה בעדכון");
        return;
      }
    } else {
      const { error } = await supabase.from("special_bet_answers").insert({
        special_bet_id: betId,
        user_id: currentUserId,
        answer,
      } as any);
      if (error) {
        if (error.message?.includes("row-level security")) toast.error("החשבון שלך מוקפא");
        else toast.error("שגיאה בשליחה");
        return;
      }
    }
    toast.success("התשובה נשמרה!");
    setUserAnswers((prev) => ({ ...prev, [betId]: "" }));
    fetchData();
  };

  const resolveBet = async (betId: string) => {
    if (!resolveAnswer.trim()) return;
    // Update the bet as resolved
    const { error: betError } = await supabase.from("special_bets").update({
      correct_answer: resolveAnswer,
      is_resolved: true,
      is_closed: true,
    } as any).eq("id", betId);
    if (betError) { toast.error("שגיאה בעדכון"); return; }

    // Award points to correct answers
    const bet = bets.find((b) => b.id === betId);
    const betAnswers = answers.filter((a) => a.special_bet_id === betId);
    for (const ans of betAnswers) {
      const isCorrect = ans.answer.trim().toLowerCase() === resolveAnswer.trim().toLowerCase();
      await supabase.from("special_bet_answers").update({
        points: isCorrect ? (bet?.points_reward || 5) : 0,
      } as any).eq("id", ans.id);
    }

    toast.success("ההימור נסגר והנקודות חולקו!");
    setResolveId(null);
    setResolveAnswer("");
    fetchData();
  };

  const closeBet = async (betId: string) => {
    await supabase.from("special_bets").update({ is_closed: true } as any).eq("id", betId);
    toast.success("ההימור נסגר");
    fetchData();
  };

  const deleteBet = async (betId: string) => {
    const { error } = await supabase.from("special_bets").delete().eq("id", betId);
    if (error) { toast.error("שגיאה במחיקה"); return; }
    toast.success("ההימור נמחק");
    fetchData();
  };

  const moveBetToSeason = async (betId: string, newSeasonId: string) => {
    const { error } = await supabase.from("special_bets").update({ season_id: newSeasonId } as any).eq("id", betId);
    if (error) { toast.error("שגיאה בהעברה"); return; }
    toast.success("ההימור הועבר לטורניר אחר");
    fetchData();
  };

  const isDeadlinePassed = (deadline: string | null) => {
    if (!deadline) return false;
    return new Date(deadline).getTime() < Date.now();
  };

  return (
    <div className="space-y-4" dir="rtl">
      {/* Admin: Create new */}
      {isAdmin && (
        <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
          <DialogTrigger asChild>
            <Button className="w-full gap-2">
              <Plus className="w-4 h-4" />
              הוסף הימור מיוחד
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>הימור מיוחד חדש</DialogTitle>
            </DialogHeader>
            <div className="space-y-3 py-2">
              <Textarea
                placeholder='למשל: "מי יהיה מלך השערים של ליגת האלופות?"'
                value={newQuestion}
                onChange={(e) => setNewQuestion(e.target.value)}
                className="bg-secondary border-border min-h-[60px]"
              />
              <div className="flex gap-2">
                <Button
                  variant={newType === "open" ? "default" : "outline"}
                  size="sm"
                  onClick={() => setNewType("open")}
                  className="text-xs flex-1"
                >
                  טקסט חופשי
                </Button>
                <Button
                  variant={newType === "options" ? "default" : "outline"}
                  size="sm"
                  onClick={() => setNewType("options")}
                  className="text-xs flex-1"
                >
                  בחירה מרשימה
                </Button>
              </div>
              {newType === "options" && (
                <Input
                  placeholder="אפשרויות (מופרדות בפסיק): ריאל מדריד, ברצלונה, באיירן"
                  value={newOptions}
                  onChange={(e) => setNewOptions(e.target.value)}
                  className="bg-secondary border-border text-sm"
                />
              )}
              <div className="flex gap-2">
                <div className="flex-1">
                  <label className="text-xs text-muted-foreground mb-1 block">נקודות לזוכה</label>
                  <Input type="number" min={1} value={newPoints} onChange={(e) => setNewPoints(e.target.value)} className="bg-secondary border-border" />
                </div>
                <div className="flex-1">
                  <label className="text-xs text-muted-foreground mb-1 block">דדליין (אופציונלי)</label>
                  <Input type="datetime-local" value={newDeadline} onChange={(e) => setNewDeadline(e.target.value)} className="bg-secondary border-border text-xs" />
                </div>
              </div>
            </div>
            <DialogFooter>
              <DialogClose asChild>
                <Button variant="outline" size="sm">ביטול</Button>
              </DialogClose>
              <Button size="sm" onClick={createBet}>צור הימור</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}

      {bets.length === 0 && (
        <div className="text-center py-12">
          <Star className="w-12 h-12 mx-auto mb-4 text-muted-foreground/30" />
          <p className="text-muted-foreground text-lg">אין הימורים מיוחדים</p>
          {isAdmin && <p className="text-muted-foreground/70 text-sm mt-1">לחץ למעלה כדי ליצור הימור חדש</p>}
        </div>
      )}

      {bets.map((bet) => {
        const betAnswers = answers.filter((a) => a.special_bet_id === bet.id);
        const myAnswer = betAnswers.find((a) => a.user_id === currentUserId);
        const isClosed = bet.is_closed || isDeadlinePassed(bet.deadline);
        const canAnswer = !isClosed && !bet.is_resolved;

        return (
          <Card key={bet.id} className="border-border bg-card">
            <CardHeader className="pb-2">
              <CardTitle className="flex items-center justify-between text-sm">
                <div className="flex items-center gap-2 flex-1">
                  <Star className="w-4 h-4 text-primary shrink-0" />
                  <span className="text-foreground">{bet.question}</span>
                </div>
                <div className="flex items-center gap-1.5 shrink-0">
                  <span className="text-xs bg-primary/20 text-primary px-2 py-0.5 rounded-full font-medium">{bet.points_reward} נק׳</span>
                  {bet.is_resolved && <span className="text-xs bg-accent/20 text-accent px-2 py-0.5 rounded-full">נסגר</span>}
                  {!bet.is_resolved && isClosed && <Lock className="w-3.5 h-3.5 text-muted-foreground" />}
                </div>
              </CardTitle>
              {bet.deadline && !bet.is_resolved && (
                <p className="text-[10px] text-muted-foreground flex items-center gap-1 mt-1">
                  <Clock className="w-3 h-3" />
                  דדליין: {new Date(bet.deadline).toLocaleString("he-IL")}
                </p>
              )}
            </CardHeader>
            <CardContent className="space-y-3">
              {/* Answer form */}
              {canAnswer && (
                <div className="flex gap-2">
                  {bet.bet_type === "options" && bet.options ? (
                    <select
                      value={userAnswers[bet.id] || myAnswer?.answer || ""}
                      onChange={(e) => setUserAnswers((prev) => ({ ...prev, [bet.id]: e.target.value }))}
                      className="flex-1 rounded-md bg-secondary border border-border text-foreground text-sm px-3 py-2"
                    >
                      <option value="">בחר תשובה...</option>
                      {bet.options.map((opt) => (
                        <option key={opt} value={opt}>{opt}</option>
                      ))}
                    </select>
                  ) : (
                    <Input
                      placeholder={myAnswer ? myAnswer.answer : "הכנס תשובה..."}
                      value={userAnswers[bet.id] || ""}
                      onChange={(e) => setUserAnswers((prev) => ({ ...prev, [bet.id]: e.target.value }))}
                      className="flex-1 bg-secondary border-border text-sm"
                    />
                  )}
                  <Button size="sm" onClick={() => submitAnswer(bet.id)}>
                    {myAnswer ? <Pencil className="w-3.5 h-3.5" /> : <Check className="w-3.5 h-3.5" />}
                  </Button>
                </div>
              )}

              {/* Resolved: show correct answer header */}
              {bet.is_resolved && (
                <div className="flex items-center gap-2 mb-2">
                  <Trophy className="w-4 h-4 text-primary" />
                  <span className="text-sm font-medium text-primary">תשובה נכונה: {bet.correct_answer}</span>
                </div>
              )}

              {/* Show all answers when closed or resolved */}
              {(isClosed || bet.is_resolved) && betAnswers.length > 0 && (
                <div className="space-y-1.5">
                  <p className="text-xs font-semibold text-muted-foreground mb-1">תשובות ({betAnswers.length}):</p>
                  {betAnswers.map((ans) => (
                    <div key={ans.id} className="flex justify-between items-center text-sm bg-secondary/50 rounded-lg px-3 py-1.5">
                      <span className="text-foreground font-medium">{getDisplayName(ans.user_id)}</span>
                      <div className="flex items-center gap-2">
                        <span className="text-muted-foreground">{ans.answer}</span>
                        {bet.is_resolved && ans.points !== null && (
                          <span className={`text-xs font-bold px-1.5 py-0.5 rounded ${ans.points > 0 ? 'bg-primary/20 text-primary' : 'bg-destructive/20 text-destructive'}`}>
                            {ans.points} נק׳
                          </span>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* Hidden answers count - only when still open */}
              {!isClosed && !bet.is_resolved && betAnswers.length > 0 && myAnswer && (
                <p className="text-xs text-muted-foreground/70 text-center">
                  🔒 {betAnswers.length} תשובות — יוצגו לאחר סגירת ההימור
                </p>
              )}

              {/* Admin actions */}
              {isAdmin && !bet.is_resolved && (
                <div className="space-y-2 border-t border-border pt-2">
                  <div className="flex gap-2 flex-wrap">
                    {!isClosed && (
                      <Button variant="outline" size="sm" className="text-xs gap-1" onClick={() => closeBet(bet.id)}>
                        <Lock className="w-3 h-3" />סגור הימור
                      </Button>
                    )}
                    {resolveId === bet.id ? (
                      <div className="flex gap-2 flex-1">
                        <Input
                          placeholder="תשובה נכונה..."
                          value={resolveAnswer}
                          onChange={(e) => setResolveAnswer(e.target.value)}
                          className="flex-1 bg-secondary border-border text-sm"
                        />
                        <Button size="sm" onClick={() => resolveBet(bet.id)}><Check className="w-3.5 h-3.5" /></Button>
                        <Button size="sm" variant="outline" onClick={() => setResolveId(null)}><X className="w-3.5 h-3.5" /></Button>
                      </div>
                    ) : (
                      <Button variant="outline" size="sm" className="text-xs gap-1" onClick={() => setResolveId(bet.id)}>
                        <Trophy className="w-3 h-3" />הכרז תוצאה
                      </Button>
                    )}
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button variant="ghost" size="sm" className="text-destructive hover:text-destructive hover:bg-destructive/10 px-2">
                          <Trash2 className="w-3.5 h-3.5" />
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent>
                        <AlertDialogHeader>
                          <AlertDialogTitle>מחיקת הימור מיוחד</AlertDialogTitle>
                          <AlertDialogDescription>האם למחוק הימור זה? כל התשובות יימחקו.</AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel>ביטול</AlertDialogCancel>
                          <AlertDialogAction className="bg-destructive text-destructive-foreground" onClick={() => deleteBet(bet.id)}>מחק</AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  </div>
                  {/* Move to season */}
                  {seasons.length > 1 && (
                    <div className="flex items-center gap-2">
                      <span className="text-xs text-muted-foreground">העבר לטורניר:</span>
                      <select
                        value={bet.season_id || ""}
                        onChange={(e) => moveBetToSeason(bet.id, e.target.value)}
                        className="rounded-md bg-secondary border border-border text-foreground text-xs px-2 py-1"
                      >
                        {seasons.map((s) => (
                          <option key={s.id} value={s.id}>{s.name}</option>
                        ))}
                      </select>
                    </div>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
};

export default SpecialBets;

import { useState, useEffect, useMemo, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Trophy, Calendar, Check, Clock, Pencil, Trash2, X, Settings, Timer } from "lucide-react";
import { format } from "date-fns";
import { he } from "date-fns/locale";

import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { getFlagUrl } from "@/lib/countryFlags";

const TeamFlag = ({ team, crest }: { team: string; crest?: string | null }) => {
  const [crestFailed, setCrestFailed] = useState(false);
  if (crest && !crestFailed) {
    return (
      <img
        src={crest}
        alt=""
        className="inline-block h-5 w-5 object-contain"
        loading="lazy"
        onError={() => setCrestFailed(true)}
      />
    );
  }
  const url = getFlagUrl(team);
  if (!url) return null;
  return (
    <img
      src={url}
      alt=""
      className="inline-block h-4 w-6 object-cover rounded-sm shadow-sm"
      loading="lazy"
    />
  );
};

interface DbMatch {
  id: string;
  home_team: string;
  away_team: string;
  match_date: string;
  match_time: string | null;
  home_score: number | null;
  away_score: number | null;
  is_finished: boolean;
  created_by: string | null;
  description: string | null;
  stage_key?: string | null;
  live_status?: string | null;
  live_home_score?: number | null;
  live_away_score?: number | null;
  live_minute?: string | null;
  home_crest?: string | null;
  away_crest?: string | null;
}


interface DbBet {
  id: string;
  match_id: string;
  user_id: string;
  home_score: number;
  away_score: number;
  points: number | null;
}

interface DbBetPresence {
  id: string;
  match_id: string;
  user_id: string;
  created_at: string;
}

interface Profile {
  id: string;
  display_name: string;
}

interface StageOption {
  key: string;
  label: string;
}

interface MatchCardProps {
  match: DbMatch;
  bets: DbBet[];
  betPresences: DbBetPresence[];
  profiles: Profile[];
  currentUserId: string;
  isAdmin: boolean;
  canFinishMatch?: boolean;
  stages?: StageOption[];
  onPlaceBet: (matchId: string, homeScore: number, awayScore: number) => void;
  onEditBet: (betId: string, homeScore: number, awayScore: number) => void;
  onFinishMatch: (matchId: string, homeScore: number, awayScore: number) => void;
  onDeleteMatch: (matchId: string) => void;
  onEditMatch: (matchId: string, homeTeam: string, awayTeam: string, date: string, time?: string, stageKey?: string | null) => void;
  onBettingClosed?: (matchId: string) => void;
}

const israelNowFormatter = new Intl.DateTimeFormat("en-CA", {
  timeZone: "Asia/Jerusalem",
  year: "numeric",
  month: "2-digit",
  day: "2-digit",
  hour: "2-digit",
  minute: "2-digit",
  second: "2-digit",
  hourCycle: "h23",
});

const getIsraelNowMs = () => {
  const parts = Object.fromEntries(
    israelNowFormatter
      .formatToParts(new Date())
      .filter((part) => part.type !== "literal")
      .map((part) => [part.type, part.value])
  );

  return Date.UTC(
    Number(parts.year),
    Number(parts.month) - 1,
    Number(parts.day),
    Number(parts.hour),
    Number(parts.minute),
    Number(parts.second)
  );
};

const getMatchWallClockMs = (match: DbMatch): number | null => {
  if (!match.match_time || !match.match_date) return null;
  const [year, month, day] = match.match_date.split("-").map(Number);
  const [hour, minute] = match.match_time.slice(0, 5).split(":").map(Number);
  return Date.UTC(year, month - 1, day, hour, minute, 0);
};

const canStillBet = (match: DbMatch): boolean => {
  if (match.is_finished) return false;
  const kickoffMs = getMatchWallClockMs(match);
  if (kickoffMs === null) return true;
  return kickoffMs - getIsraelNowMs() > 1 * 60 * 1000;
};

const shouldRevealScores = (match: DbMatch): boolean => {
  if (match.is_finished) return true;
  const kickoffMs = getMatchWallClockMs(match);
  if (kickoffMs === null) return false;
  return getIsraelNowMs() >= kickoffMs;
};

const getDeadlineMs = (match: DbMatch): number | null => {
  const kickoffMs = getMatchWallClockMs(match);
  if (match.is_finished || kickoffMs === null) return null;
  return kickoffMs - 1 * 60 * 1000;
};

const BetCountdown = ({ match }: { match: DbMatch }) => {
  const deadlineMs = useMemo(() => getDeadlineMs(match), [match.match_date, match.match_time, match.is_finished]);
  const [remaining, setRemaining] = useState<number | null>(null);

  useEffect(() => {
    if (deadlineMs === null) return;
    const update = () => setRemaining(Math.max(0, deadlineMs - getIsraelNowMs()));
    update();
    const interval = setInterval(update, 1000);
    return () => clearInterval(interval);
  }, [deadlineMs]);

  if (remaining === null || remaining <= 0) return null;

  const totalSecs = Math.floor(remaining / 1000);
  const days = Math.floor(totalSecs / 86400);
  const hours = Math.floor((totalSecs % 86400) / 3600);
  const mins = Math.floor((totalSecs % 3600) / 60);
  const secs = totalSecs % 60;

  const isUrgent = totalSecs < 300; // less than 5 minutes
  const pad = (n: number) => String(n).padStart(2, "0");

  let timeStr: string;
  if (days >= 2) timeStr = `${days} ימים`;
  else {
    const totalHours = days * 24 + hours;
    timeStr = `${pad(totalHours)}:${pad(mins)}:${pad(secs)}`;
  }

  return (
    <div className={`flex items-center justify-center gap-1.5 text-xs py-1.5 px-3 rounded-full mx-auto w-fit ${
      isUrgent ? "bg-destructive/15 text-destructive" : "bg-muted text-muted-foreground"
    }`}>
      <Timer className="w-3 h-3" />
      <span className="font-mono font-medium" dir="ltr">{timeStr}</span>
      <span>לסגירה</span>
    </div>
  );
};

const MatchCard = ({ match, bets, betPresences, profiles, currentUserId, isAdmin, canFinishMatch, stages = [], onPlaceBet, onEditBet, onFinishMatch, onDeleteMatch, onEditMatch, onBettingClosed }: MatchCardProps) => {
  const showFinishMatch = canFinishMatch ?? isAdmin;
  const [adminShowBets, setAdminShowBets] = useState(false);
  const [homeGuess, setHomeGuess] = useState("");
  const [awayGuess, setAwayGuess] = useState("");
  const [finalHome, setFinalHome] = useState("");
  const [finalAway, setFinalAway] = useState("");
  const [showResult, setShowResult] = useState(false);
  const [editingBetId, setEditingBetId] = useState<string | null>(null);
  const [editHome, setEditHome] = useState("");
  const [editAway, setEditAway] = useState("");
  const [editingMatch, setEditingMatch] = useState(false);
  const [editMatchHome, setEditMatchHome] = useState(match.home_team);
  const [editMatchAway, setEditMatchAway] = useState(match.away_team);
  const [editMatchDate, setEditMatchDate] = useState(match.match_date);
  const [editMatchTime, setEditMatchTime] = useState(match.match_time?.slice(0, 5) || "");
  const [editStageKey, setEditStageKey] = useState<string>(match.stage_key || "__none__");
  const [confirmDelete, setConfirmDelete] = useState(false);

  const [bettingOpen, setBettingOpen] = useState(() => canStillBet(match));
  const [scoresVisible, setScoresVisible] = useState(() => shouldRevealScores(match));

  const prevBettingOpen = useRef(bettingOpen);

  useEffect(() => {
    if (match.is_finished) {
      setBettingOpen(false);
      return;
    }
    if (!match.match_time || !match.match_date) {
      setBettingOpen(true);
      return;
    }
    const update = () => {
      const open = canStillBet(match);
      setBettingOpen(open);
      // When betting just closed, trigger monkey bet assignment
      if (prevBettingOpen.current && !open && onBettingClosed) {
        onBettingClosed(match.id);
      }
      prevBettingOpen.current = open;
    };
    update();
    const interval = setInterval(update, 1000);
    return () => clearInterval(interval);
  }, [match.match_date, match.match_time, match.is_finished, onBettingClosed, match.id]);

  useEffect(() => {
    if (adminShowBets) {
      setScoresVisible(true);
      return;
    }
    const update = () => setScoresVisible(shouldRevealScores(match));
    update();
    if (match.is_finished || !match.match_time || !match.match_date) return;
    const interval = setInterval(update, 1000);
    return () => clearInterval(interval);
  }, [adminShowBets, match.match_date, match.match_time, match.is_finished]);

  const userBet = bets.find((b) => b.user_id === currentUserId);
  const MONKEY_ID = "00000000-0000-0000-0000-00000000cafe";
  const getDisplayName = (userId: string) => {
    if (userId === MONKEY_ID) return "הקוף 🐒";
    return profiles.find((p) => p.id === userId)?.display_name || "אנונימי";
  };

  const participants = useMemo(() => {
    const uniqueIds = new Set<string>();
    const orderedIds = [
      ...betPresences
        .slice()
        .sort((a, b) => new Date(a.created_at).getTime() - new Date(b.created_at).getTime())
        .map((presence) => presence.user_id),
      ...bets.map((bet) => bet.user_id),
    ].filter((userId) => {
      if (uniqueIds.has(userId)) return false;
      uniqueIds.add(userId);
      return true;
    });

    return orderedIds.map((userId) => ({
      userId,
      bet: bets.find((bet) => bet.user_id === userId) || null,
    }));
  }, [betPresences, bets]);

  const handleBet = () => {
    if (homeGuess === "" || awayGuess === "") return;
    onPlaceBet(match.id, Number(homeGuess), Number(awayGuess));
    setHomeGuess("");
    setAwayGuess("");
  };

  const handleFinish = () => {
    if (finalHome === "" || finalAway === "") return;
    onFinishMatch(match.id, Number(finalHome), Number(finalAway));
    setShowResult(false);
  };

  const handleEditStart = (bet: DbBet) => {
    setEditingBetId(bet.id);
    setEditHome(String(bet.home_score));
    setEditAway(String(bet.away_score));
  };

  const handleEditSave = () => {
    if (!editingBetId || editHome === "" || editAway === "") return;
    onEditBet(editingBetId, Number(editHome), Number(editAway));
    setEditingBetId(null);
  };

  const handleMatchEditSave = () => {
    const sk = editStageKey === "__none__" ? null : editStageKey;
    onEditMatch(match.id, editMatchHome, editMatchAway, editMatchDate, editMatchTime || undefined, sk);
    setEditingMatch(false);
  };

  const matchDate = match.match_date ? format(new Date(match.match_date), "d MMMM yyyy", { locale: he }) : "";
  const currentStageLabel = match.stage_key ? stages.find((s) => s.key === match.stage_key)?.label : null;
  const isLive = !match.is_finished && (match.live_status === 'IN_PLAY' || match.live_status === 'PAUSED' || match.live_status === 'LIVE');


  if (editingMatch) {
    return (
      <div className="rounded-xl border border-primary/50 bg-card p-5" dir="rtl">
        <h3 className="text-sm font-bold text-foreground mb-3">עריכת משחק</h3>
        <div className="space-y-3">
          <Input value={editMatchHome} onChange={(e) => setEditMatchHome(e.target.value)} placeholder="קבוצת בית" className="bg-secondary border-border text-foreground text-sm" />
          <Input value={editMatchAway} onChange={(e) => setEditMatchAway(e.target.value)} placeholder="קבוצת חוץ" className="bg-secondary border-border text-foreground text-sm" />
          <Input type="date" value={editMatchDate} onChange={(e) => setEditMatchDate(e.target.value)} className="bg-secondary border-border text-foreground text-sm" />
          <Input type="time" value={editMatchTime} onChange={(e) => setEditMatchTime(e.target.value)} className="bg-secondary border-border text-foreground text-sm" />
          {stages.length > 0 && (
            <Select value={editStageKey} onValueChange={setEditStageKey}>
              <SelectTrigger className="bg-secondary border-border text-foreground text-sm">
                <SelectValue placeholder="שלב בטורניר" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="__none__">ללא שלב (ניקוד ברירת מחדל)</SelectItem>
                {stages.map((s) => (
                  <SelectItem key={s.key} value={s.key}>{s.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          )}
          <div className="flex gap-2">
            <Button size="sm" onClick={handleMatchEditSave} className="bg-primary text-primary-foreground hover:bg-primary/90 flex-1">
              <Check className="w-4 h-4 ml-1" /> שמור
            </Button>
            <Button size="sm" variant="outline" onClick={() => setEditingMatch(false)} className="border-border">
              <X className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="rounded-xl border border-border bg-card p-5 gradient-pitch transition-all hover:border-primary/30">
      <div className="flex items-center justify-between mb-1" dir="rtl">
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <Calendar className="w-3.5 h-3.5" />
          <span>{matchDate}</span>
          {match.match_time && (
            <>
              <Clock className="w-3.5 h-3.5 mr-1" />
              <span>{match.match_time.slice(0, 5)}</span>
            </>
          )}
        </div>
        <div className="flex items-center gap-2">
          {isAdmin && !match.is_finished && (
            <div className="flex gap-1">
              <Button size="sm" variant="ghost" onClick={() => setEditingMatch(true)} className="h-7 w-7 p-0 text-muted-foreground hover:text-primary">
                <Settings className="w-3.5 h-3.5" />
              </Button>
              {confirmDelete ? (
                <div className="flex gap-1 items-center">
                  <span className="text-xs text-destructive">בטוח?</span>
                  <Button size="sm" variant="ghost" onClick={() => onDeleteMatch(match.id)} className="h-7 w-7 p-0 text-destructive">
                    <Check className="w-3.5 h-3.5" />
                  </Button>
                  <Button size="sm" variant="ghost" onClick={() => setConfirmDelete(false)} className="h-7 w-7 p-0 text-muted-foreground">
                    <X className="w-3.5 h-3.5" />
                  </Button>
                </div>
              ) : (
                <Button size="sm" variant="ghost" onClick={() => setConfirmDelete(true)} className="h-7 w-7 p-0 text-muted-foreground hover:text-destructive">
                  <Trash2 className="w-3.5 h-3.5" />
                </Button>
              )}
            </div>
          )}
          {!bettingOpen && !match.is_finished && !isLive && (
            <span className="text-xs bg-destructive/20 text-destructive px-2 py-0.5 rounded-full font-medium">ההימורים נסגרו</span>
          )}
          {isLive && (
            <span className="text-xs bg-red-500/20 text-red-500 px-2 py-0.5 rounded-full font-bold flex items-center gap-1">
              <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-pulse" />
              LIVE {match.live_minute ? `${match.live_minute}'` : ""}
            </span>
          )}
          {match.is_finished && (
            <span className="text-xs bg-primary/20 text-primary px-2 py-0.5 rounded-full font-medium">הסתיים</span>
          )}
        </div>
      </div>

      {match.description && (
        <p className="text-center text-[11px] text-accent font-medium mb-1">{match.description}</p>
      )}
      {currentStageLabel && (
        <p className="text-center text-[10px] text-primary font-semibold mb-3">🏆 {currentStageLabel}</p>
      )}

      <div className="flex items-center justify-center gap-4 mb-5" dir="rtl">
        <div className="text-center flex-1">
          <p className="font-bold text-foreground text-lg flex items-center justify-center gap-1.5">
            <TeamFlag team={match.home_team} crest={match.home_crest} />
            <span>{match.home_team}</span>
          </p>
          <p className="text-xs text-muted-foreground">בית</p>
        </div>
        {match.is_finished ? (
          <div className="text-2xl font-black text-primary min-w-[60px] text-center">
            {match.home_score} - {match.away_score}
          </div>
        ) : isLive ? (
          <div className="text-2xl font-black text-red-500 min-w-[60px] text-center">
            {match.live_home_score ?? 0} - {match.live_away_score ?? 0}
          </div>
        ) : (
          <div className="text-xl font-bold text-muted-foreground">VS</div>
        )}
        <div className="text-center flex-1">
          <p className="font-bold text-foreground text-lg flex items-center justify-center gap-1.5">
            <TeamFlag team={match.away_team} crest={match.away_crest} />
            <span>{match.away_team}</span>
          </p>
          <p className="text-xs text-muted-foreground">חוץ</p>
        </div>
      </div>


      {/* Countdown timer */}
      {!match.is_finished && bettingOpen && (
        <div className="mb-3">
          <BetCountdown match={match} />
        </div>
      )}

      {/* Bet form */}
      {!match.is_finished && bettingOpen && !userBet && (
        <div className="space-y-3 border-t border-border pt-4" dir="rtl">
          <div className="flex gap-2 items-end">
            <Input type="number" min={0} placeholder="בית" value={homeGuess} onChange={(e) => setHomeGuess(e.target.value)} className="w-16 bg-secondary border-border text-foreground text-center text-sm" />
            <span className="text-muted-foreground pb-2">-</span>
            <Input type="number" min={0} placeholder="חוץ" value={awayGuess} onChange={(e) => setAwayGuess(e.target.value)} className="w-16 bg-secondary border-border text-foreground text-center text-sm" />
            <Button size="sm" onClick={handleBet} className="bg-primary text-primary-foreground hover:bg-primary/90">שמור הימור</Button>
          </div>
        </div>
      )}

      {/* User's own bet */}
      {userBet && bettingOpen && (
        <div className="border-t border-border pt-3 mt-3" dir="rtl">
          <p className="text-xs text-muted-foreground mb-1">ההימור שלך:</p>
          <div className="flex items-center justify-between bg-secondary/50 rounded-lg px-3 py-1.5">
            {editingBetId === userBet.id ? (
              <div className="flex items-center gap-1">
                <Input type="number" min={0} value={editHome} onChange={(e) => setEditHome(e.target.value)} className="w-12 h-7 bg-secondary border-border text-foreground text-center text-xs" />
                <span className="text-muted-foreground text-xs">-</span>
                <Input type="number" min={0} value={editAway} onChange={(e) => setEditAway(e.target.value)} className="w-12 h-7 bg-secondary border-border text-foreground text-center text-xs" />
                <Button size="sm" variant="ghost" onClick={handleEditSave} className="h-7 w-7 p-0 text-primary"><Check className="w-3.5 h-3.5" /></Button>
              </div>
            ) : (
              <div className="flex items-center gap-2">
                <span className="text-foreground">{userBet.home_score} - {userBet.away_score}</span>
                <Button size="sm" variant="ghost" onClick={() => handleEditStart(userBet)} className="h-7 w-7 p-0 text-muted-foreground hover:text-primary"><Pencil className="w-3 h-3" /></Button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Finish match - admin only */}
      {!match.is_finished && showFinishMatch && (
        <div className="mt-3" dir="rtl">
          {!showResult ? (
            <Button variant="outline" size="sm" onClick={() => setShowResult(true)} className="w-full border-accent/50 text-accent hover:bg-accent/10 text-xs">
              <Trophy className="w-3.5 h-3.5 ml-1" />
              עדכן תוצאה סופית
            </Button>
          ) : (
            <div className="flex gap-2 items-center">
              <Input type="number" min={0} placeholder="בית" value={finalHome} onChange={(e) => setFinalHome(e.target.value)} className="w-16 bg-secondary border-border text-foreground text-center text-sm" />
              <span className="text-muted-foreground">-</span>
              <Input type="number" min={0} placeholder="חוץ" value={finalAway} onChange={(e) => setFinalAway(e.target.value)} className="w-16 bg-secondary border-border text-foreground text-center text-sm" />
              <Button size="sm" onClick={handleFinish} className="bg-accent text-accent-foreground hover:bg-accent/90"><Check className="w-4 h-4" /></Button>
            </div>
          )}
        </div>
      )}

      {/* Bets section */}
      {participants.length > 0 && (
        <div className="mt-4 border-t border-border pt-3 space-y-1.5" dir="rtl">
          <div className="mb-2 flex items-center justify-between gap-2">
            <p className="text-xs font-semibold text-muted-foreground">הימורים ({participants.length}):</p>
            {!scoresVisible && !match.is_finished && (
              <span className="text-[11px] text-muted-foreground">השמות גלויים, התוצאות נחשפות בשריקת הפתיחה</span>
            )}
          </div>
          {participants.map(({ userId, bet }) => {
            const revealScores = scoresVisible || match.is_finished;
            return (
              <div key={userId} className="flex justify-between items-center text-sm bg-secondary/50 rounded-lg px-3 py-1.5">
                <span className="text-foreground font-medium">{getDisplayName(userId)}</span>
                <div className="flex items-center gap-2">
                  {revealScores && bet ? (
                    <div className="flex items-center gap-2 animate-enter">
                      <span className="text-foreground">{bet.home_score} - {bet.away_score}</span>
                      {match.is_finished && bet.points !== null && (
                        <span className={`text-xs font-bold px-1.5 py-0.5 rounded ${bet.points === 3 ? 'bg-primary/20 text-primary' : bet.points === 1 ? 'bg-accent/20 text-accent' : 'bg-destructive/20 text-destructive'}`}>
                          {bet.points} נק׳
                        </span>
                      )}
                    </div>
                  ) : (
                    <span className="text-muted-foreground text-xs">🔒 הימר</span>
                  )}
                </div>
              </div>
            );
          })}
          {bettingOpen && !scoresVisible && !match.is_finished && isAdmin && (
            <Button variant="ghost" size="sm" onClick={() => setAdminShowBets(true)} className="w-full text-xs text-muted-foreground hover:text-primary mt-1">
              הצג הימורים
            </Button>
          )}
        </div>
      )}

      {/* No bets yet indicator */}
      {participants.length === 0 && !match.is_finished && (
        <div className="mt-4 border-t border-border pt-3" dir="rtl">
          <p className="text-xs text-muted-foreground/70 text-center py-2">
            אין הימורים עדיין
          </p>
        </div>
      )}
    </div>
  );
};

export default MatchCard;

import { useState } from "react";
import { PlayerStats } from "@/types/betting";
import { Trophy, Target, Hash, ArrowUpDown, Pencil, Check, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

interface LeaderboardProps {
  stats: PlayerStats[];
  isAdmin?: boolean;
  seasonId?: string | null;
  onStatsEdited?: () => void;
}

const Leaderboard = ({ stats, isAdmin, seasonId, onStatsEdited }: LeaderboardProps) => {
  const sorted = [...stats].sort((a, b) => b.totalPoints - a.totalPoints);
  const [editMode, setEditMode] = useState(false);
  const [editData, setEditData] = useState<PlayerStats[]>([]);
  const [saving, setSaving] = useState(false);

  const startEditing = () => {
    setEditData(sorted.map((s) => ({ ...s })));
    setEditMode(true);
  };

  const cancelEditing = () => {
    setEditMode(false);
    setEditData([]);
  };

  const saveEditing = async () => {
    setSaving(true);
    try {
      for (const player of editData) {
        const { error } = await supabase
          .from("player_stat_overrides" as any)
          .upsert(
            {
              season_id: seasonId || null,
              player_name: player.name,
              total_points: player.totalPoints,
              total_bets: player.totalBets,
              exact_hits: player.exactHits,
              direction_hits: player.directionHits,
              updated_at: new Date().toISOString(),
            } as any,
            { onConflict: "season_id,player_name" }
          );
        if (error) {
          toast.error(`שגיאה בשמירת ${player.name}`);
          console.error(error);
          setSaving(false);
          return;
        }
      }
      toast.success("הנתונים נשמרו בהצלחה");
      setEditMode(false);
      setEditData([]);
      if (onStatsEdited) onStatsEdited();
    } catch (e) {
      toast.error("שגיאה בשמירה");
    }
    setSaving(false);
  };

  const updateField = (index: number, field: keyof PlayerStats, value: string) => {
    if (field === "name") return;
    const num = parseInt(value) || 0;
    setEditData((prev) => {
      const copy = [...prev];
      copy[index] = { ...copy[index], [field]: num };
      return copy;
    });
  };

  const displayData = editMode ? editData : sorted;

  if (sorted.length === 0) {
    return (
      <div className="text-center text-muted-foreground py-12">
        <Trophy className="w-10 h-10 mx-auto mb-3 opacity-30" />
        <p>אין נתונים עדיין</p>
        <p className="text-sm mt-1">הוסיפו משחקים והתחילו להמר!</p>
      </div>
    );
  }

  return (
    <div className="space-y-2" dir="rtl">
      {isAdmin && (
        <div className="flex justify-end gap-2">
          {editMode ? (
            <>
              <Button variant="ghost" size="sm" onClick={cancelEditing} disabled={saving} className="text-xs gap-1">
                <X className="w-3.5 h-3.5" />
                בטל
              </Button>
              <Button variant="default" size="sm" onClick={saveEditing} disabled={saving} className="text-xs gap-1">
                <Check className="w-3.5 h-3.5" />
                {saving ? "שומר..." : "שמור"}
              </Button>
            </>
          ) : (
            <Button variant="outline" size="sm" onClick={startEditing} className="text-xs gap-1">
              <Pencil className="w-3.5 h-3.5" />
              ערוך טבלה
            </Button>
          )}
        </div>
      )}
      <div className="rounded-xl border border-border bg-card overflow-hidden">
        <div className="grid grid-cols-5 gap-1 px-3 py-3 bg-secondary/50 text-[11px] font-semibold text-muted-foreground">
          <span className="flex items-center gap-1"><Hash className="w-3 h-3" />שחקן</span>
          <span className="text-center">הימורים</span>
          <span className="text-center flex items-center justify-center gap-1"><Target className="w-3 h-3" />מדויק</span>
          <span className="text-center flex items-center justify-center gap-1"><ArrowUpDown className="w-3 h-3" />כיוון</span>
          <span className="text-center flex items-center justify-center gap-1"><Trophy className="w-3 h-3" />נקודות</span>
        </div>
        {displayData.map((player, i) => (
          <div
            key={player.name}
            className={`grid grid-cols-5 gap-1 px-3 py-3 border-t border-border items-center transition-colors hover:bg-secondary/30 ${i === 0 && !editMode ? 'gradient-pitch' : ''}`}
          >
            <div className="flex items-center gap-1.5">
              {!editMode && i === 0 && <span className="text-gradient-gold text-lg">🏆</span>}
              {!editMode && i === 1 && <span className="text-lg">🥈</span>}
              {!editMode && i === 2 && <span className="text-lg">🥉</span>}
              <span className={`font-semibold text-sm ${i === 0 && !editMode ? 'text-primary' : 'text-foreground'}`}>{player.name}</span>
            </div>
            {editMode ? (
              <>
                <input type="number" value={player.totalBets} onChange={(e) => updateField(i, "totalBets", e.target.value)} className="w-full text-center bg-background border border-border rounded px-1 py-0.5 text-sm" />
                <input type="number" value={player.exactHits} onChange={(e) => updateField(i, "exactHits", e.target.value)} className="w-full text-center bg-background border border-border rounded px-1 py-0.5 text-sm" />
                <input type="number" value={player.directionHits} onChange={(e) => updateField(i, "directionHits", e.target.value)} className="w-full text-center bg-background border border-border rounded px-1 py-0.5 text-sm" />
                <input type="number" value={player.totalPoints} onChange={(e) => updateField(i, "totalPoints", e.target.value)} className="w-full text-center bg-background border border-border rounded px-1 py-0.5 text-sm font-bold" />
              </>
            ) : (
              <>
                <span className="text-center text-muted-foreground text-sm">{player.totalBets}</span>
                <span className="text-center text-muted-foreground text-sm">{player.exactHits}</span>
                <span className="text-center text-muted-foreground text-sm">{player.directionHits}</span>
                <span className={`text-center font-bold ${i === 0 ? 'text-primary text-lg' : 'text-foreground'}`}>{player.totalPoints}</span>
              </>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default Leaderboard;

import { useEffect, useState } from "react";
import { Bell, BellOff } from "lucide-react";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { isPushSupported, subscribeUserToPush } from "@/lib/push";

const STORAGE_DISMISSED_KEY = "notification_prompt_dismissed_v1";

interface Props {
  userId: string | undefined;
}

const NotificationPermissionBanner = ({ userId }: Props) => {
  const [permission, setPermission] = useState<NotificationPermission | "unsupported">(
    typeof window !== "undefined" && "Notification" in window
      ? Notification.permission
      : "unsupported",
  );
  const [dismissed, setDismissed] = useState<boolean>(() => {
    if (typeof window === "undefined") return true;
    return localStorage.getItem(STORAGE_DISMISSED_KEY) === "1";
  });

  // Auto-subscribe to push if permission is already granted (e.g. returning user)
  useEffect(() => {
    if (!userId) return;
    if (!isPushSupported()) return;
    if (Notification.permission !== "granted") return;
    subscribeUserToPush(userId).catch(() => {});
  }, [userId]);

  useEffect(() => {
    if (typeof window === "undefined" || !("Notification" in window)) return;
    const interval = setInterval(() => {
      setPermission(Notification.permission);
    }, 2000);
    return () => clearInterval(interval);
  }, []);

  if (permission === "unsupported") return null;
  if (permission === "granted") return null;
  if (permission === "denied") return null;
  if (dismissed) return null;

  const requestPermission = async () => {
    try {
      const result = await Notification.requestPermission();
      setPermission(result);
      if (result === "granted") {
        toast.success("התראות הופעלו! נזכיר לך כשמשחקים מתקרבים");
        if (userId) {
          const ok = await subscribeUserToPush(userId);
          if (!ok) toast.error("לא ניתן לרשום למנוי התראות");
        }
      } else if (result === "denied") {
        toast.error("ההתראות נחסמו. ניתן לאפשר בהגדרות הדפדפן");
      }
    } catch {
      toast.error("לא ניתן להפעיל התראות");
    }
  };

  const handleDismiss = () => {
    localStorage.setItem(STORAGE_DISMISSED_KEY, "1");
    setDismissed(true);
  };

  return (
    <div
      className="mb-4 rounded-xl border border-primary/40 bg-primary/10 p-3 flex items-center justify-between gap-3"
      dir="rtl"
    >
      <div className="flex items-center gap-2 text-sm">
        <Bell className="w-4 h-4 text-primary shrink-0" />
        <span className="text-foreground">
          הפעל התראות כדי לקבל תזכורת שעה ו-10 דקות לפני משחק שלא הימרת בו
        </span>
      </div>
      <div className="flex items-center gap-1 shrink-0">
        <Button size="sm" onClick={requestPermission} className="bg-primary text-primary-foreground hover:bg-primary/90 h-8 text-xs">
          הפעל
        </Button>
        <Button size="sm" variant="ghost" onClick={handleDismiss} className="h-8 w-8 p-0 text-muted-foreground">
          <BellOff className="w-4 h-4" />
        </Button>
      </div>
    </div>
  );
};

export default NotificationPermissionBanner;

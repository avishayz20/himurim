import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Users, ShieldCheck, Shield, Trash2, Snowflake, Play, Settings2, ChevronDown, ChevronUp, Pencil, Check, X } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { ALL_PERMISSIONS, PERMISSION_LABELS, PERMISSION_ICONS, type AppPermission } from "@/hooks/usePermissions";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

interface Profile {
  id: string;
  display_name: string;
  created_at: string;
  is_frozen?: boolean;
}

interface UserRole {
  user_id: string;
  role: "admin" | "user";
}

interface UserPermission {
  user_id: string;
  permission: string;
}

interface UsersListProps {
  profiles: Profile[];
  currentUserId: string;
  onUserRemoved?: () => void;
}

const UsersList = ({ profiles, currentUserId, onUserRemoved }: UsersListProps) => {
  const [roles, setRoles] = useState<UserRole[]>([]);
  const [permissions, setPermissions] = useState<UserPermission[]>([]);
  const [loading, setLoading] = useState<string | null>(null);
  const [frozenMap, setFrozenMap] = useState<Record<string, boolean>>({});
  const [expandedUser, setExpandedUser] = useState<string | null>(null);
  const [editingNameId, setEditingNameId] = useState<string | null>(null);
  const [editNameValue, setEditNameValue] = useState("");

  const fetchRoles = async () => {
    const { data } = await supabase.from("user_roles").select("user_id, role");
    if (data) setRoles(data as UserRole[]);
  };

  const fetchPermissions = async () => {
    const { data } = await supabase.from("user_permissions").select("user_id, permission");
    if (data) setPermissions(data as UserPermission[]);
  };

  useEffect(() => {
    fetchRoles();
    fetchPermissions();
    const map: Record<string, boolean> = {};
    profiles.forEach((p) => { map[p.id] = p.is_frozen || false; });
    setFrozenMap(map);
  }, [profiles]);

  const isUserAdmin = (userId: string) => roles.some((r) => r.user_id === userId && r.role === "admin");

  const getUserPermissions = (userId: string): Set<string> => {
    return new Set(permissions.filter((p) => p.user_id === userId).map((p) => p.permission));
  };

  const toggleAdmin = async (userId: string) => {
    setLoading(userId);
    const admin = isUserAdmin(userId);
    if (admin) {
      if (userId === currentUserId) {
        toast.error("לא ניתן להסיר ניהול מעצמך");
        setLoading(null);
        return;
      }
      const { error } = await supabase.from("user_roles").delete().eq("user_id", userId).eq("role", "admin");
      if (error) { toast.error("שגיאה בהסרת ניהול"); }
      else { toast.success("הניהול הוסר"); }
    } else {
      const { error } = await supabase.from("user_roles").insert({ user_id: userId, role: "admin" });
      if (error) { toast.error("שגיאה בהענקת ניהול"); }
      else { toast.success("ניהול הוענק בהצלחה"); }
    }
    await fetchRoles();
    setLoading(null);
  };

  const togglePermission = async (userId: string, permission: AppPermission) => {
    const userPerms = getUserPermissions(userId);
    if (userPerms.has(permission)) {
      const { error } = await supabase.from("user_permissions").delete().eq("user_id", userId).eq("permission", permission);
      if (error) { toast.error("שגיאה בהסרת הרשאה"); return; }
    } else {
      const { error } = await supabase.from("user_permissions").insert({ user_id: userId, permission } as any);
      if (error) { toast.error("שגיאה בהענקת הרשאה"); return; }
    }
    await fetchPermissions();
  };

  const toggleFreeze = async (userId: string) => {
    if (userId === currentUserId) {
      toast.error("לא ניתן להקפיא את עצמך");
      return;
    }
    setLoading(userId);
    const currentlyFrozen = frozenMap[userId] || false;
    const { error } = await supabase.from("profiles").update({ is_frozen: !currentlyFrozen } as any).eq("id", userId);
    if (error) {
      toast.error("שגיאה בעדכון סטטוס");
    } else {
      setFrozenMap((prev) => ({ ...prev, [userId]: !currentlyFrozen }));
      toast.success(currentlyFrozen ? "המשתתף שוחרר" : "המשתתף הוקפא");
      onUserRemoved?.();
    }
    setLoading(null);
  };

  const removeUser = async (userId: string) => {
    if (userId === currentUserId) {
      toast.error("לא ניתן להסיר את עצמך");
      return;
    }
    setLoading(userId);
    await supabase.from("bets").delete().eq("user_id", userId);
    await supabase.from("user_permissions").delete().eq("user_id", userId);
    await supabase.from("user_roles").delete().eq("user_id", userId);
    const { error } = await supabase.from("profiles").delete().eq("id", userId);
    if (error) { toast.error("שגיאה בהסרת משתתף"); }
    else { toast.success("המשתתף הוסר בהצלחה"); onUserRemoved?.(); }
    setLoading(null);
  };

  const saveDisplayName = async (userId: string) => {
    if (!editNameValue.trim()) { toast.error("שם לא יכול להיות ריק"); return; }
    const { error } = await supabase.from("profiles").update({ display_name: editNameValue.trim() }).eq("id", userId);
    if (error) { toast.error("שגיאה בעדכון שם"); return; }
    toast.success("השם עודכן!");
    setEditingNameId(null);
    onUserRemoved?.();
  };

  const sorted = [...profiles].sort((a, b) => a.display_name.localeCompare(b.display_name, "he"));

  return (
    <Card className="border-border bg-card">
      <CardHeader>
        <CardTitle className="flex items-center gap-2 text-lg">
          <Users className="w-5 h-5 text-primary" />
          משתמשים רשומים ({profiles.length})
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-2">
          {sorted.map((profile) => {
            const admin = isUserAdmin(profile.id);
            const frozen = frozenMap[profile.id] || false;
            const isExpanded = expandedUser === profile.id;
            const userPerms = getUserPermissions(profile.id);

            return (
              <div key={profile.id} className={`rounded-lg overflow-hidden ${frozen ? "bg-muted/50 opacity-75" : "bg-secondary"}`}>
                <div className="flex items-center justify-between p-3">
                  <div className="flex items-center gap-3">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-sm ${frozen ? "bg-blue-500/20 text-blue-400" : admin ? "bg-primary/20 text-primary" : "bg-muted text-muted-foreground"}`}>
                      {frozen ? "❄️" : profile.display_name.charAt(0)}
                    </div>
                    <div>
                      {editingNameId === profile.id ? (
                        <div className="flex items-center gap-1">
                          <Input
                            value={editNameValue}
                            onChange={(e) => setEditNameValue(e.target.value)}
                            className="h-7 text-sm w-32"
                            autoFocus
                            onKeyDown={(e) => e.key === "Enter" && saveDisplayName(profile.id)}
                          />
                          <Button size="icon" variant="ghost" className="h-6 w-6 text-primary" onClick={() => saveDisplayName(profile.id)}>
                            <Check className="w-3 h-3" />
                          </Button>
                          <Button size="icon" variant="ghost" className="h-6 w-6 text-muted-foreground" onClick={() => setEditingNameId(null)}>
                            <X className="w-3 h-3" />
                          </Button>
                        </div>
                      ) : (
                        <p className="text-foreground text-sm font-medium flex items-center gap-1">
                          {profile.display_name}
                          {admin && <span className="text-primary">👑</span>}
                          {frozen && <span className="text-blue-400 text-xs">(מוקפא)</span>}
                          {profile.id === currentUserId && (
                            <span className="text-muted-foreground text-xs">(את/ה)</span>
                          )}
                          <Button
                            size="icon"
                            variant="ghost"
                            className="h-5 w-5 text-muted-foreground hover:text-primary"
                            onClick={() => { setEditingNameId(profile.id); setEditNameValue(profile.display_name); }}
                          >
                            <Pencil className="w-2.5 h-2.5" />
                          </Button>
                        </p>
                      )}
                      <p className="text-muted-foreground text-xs">
                        הצטרף/ה: {new Date(profile.created_at).toLocaleDateString("he-IL")}
                        {!admin && userPerms.size > 0 && (
                          <span className="text-primary mr-2">• {userPerms.size} הרשאות</span>
                        )}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-1">
                    <Button
                      variant={admin ? "default" : "outline"}
                      size="sm"
                      className="text-xs gap-1 px-2"
                      disabled={loading === profile.id}
                      onClick={() => toggleAdmin(profile.id)}
                    >
                      {admin ? <ShieldCheck className="w-3.5 h-3.5" /> : <Shield className="w-3.5 h-3.5" />}
                      <span className="hidden sm:inline">{admin ? "אדמין" : "אדמין"}</span>
                    </Button>
                    {profile.id !== currentUserId && !admin && (
                      <Button
                        variant={isExpanded ? "default" : "outline"}
                        size="sm"
                        className="text-xs gap-1 px-2"
                        onClick={() => setExpandedUser(isExpanded ? null : profile.id)}
                        title="הרשאות"
                      >
                        <Settings2 className="w-3.5 h-3.5" />
                        {isExpanded ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
                      </Button>
                    )}
                    {profile.id !== currentUserId && (
                      <>
                        <Button
                          variant={frozen ? "secondary" : "outline"}
                          size="sm"
                          className={`text-xs gap-1 px-2 ${frozen ? "text-blue-400 border-blue-400/30" : ""}`}
                          disabled={loading === profile.id}
                          onClick={() => toggleFreeze(profile.id)}
                          title={frozen ? "שחרר משתתף" : "הקפא משתתף"}
                        >
                          {frozen ? <Play className="w-3.5 h-3.5" /> : <Snowflake className="w-3.5 h-3.5" />}
                        </Button>
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button variant="ghost" size="sm" className="text-destructive hover:text-destructive hover:bg-destructive/10 px-2" disabled={loading === profile.id}>
                              <Trash2 className="w-3.5 h-3.5" />
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>הסרת משתתף</AlertDialogTitle>
                              <AlertDialogDescription>
                                האם להסיר את {profile.display_name}? כל הניחושים שלו יימחקו. לא ניתן לבטל פעולה זו.
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel>ביטול</AlertDialogCancel>
                              <AlertDialogAction className="bg-destructive text-destructive-foreground hover:bg-destructive/90" onClick={() => removeUser(profile.id)}>הסר</AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </>
                    )}
                  </div>
                </div>

                {/* Permissions panel */}
                {isExpanded && !admin && (
                  <div className="px-3 pb-3 pt-1 border-t border-border/50">
                    <p className="text-xs text-muted-foreground font-medium mb-2">הרשאות:</p>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
                      {ALL_PERMISSIONS.map((perm) => (
                        <label
                          key={perm}
                          className={`flex items-center gap-2 p-2 rounded-md cursor-pointer border transition-colors text-sm ${
                            userPerms.has(perm)
                              ? "border-primary/30 bg-primary/5"
                              : "border-transparent bg-background/50 hover:bg-background/80"
                          }`}
                        >
                          <Checkbox
                            checked={userPerms.has(perm)}
                            onCheckedChange={() => togglePermission(profile.id, perm)}
                          />
                          <span className="text-xs">
                            {PERMISSION_ICONS[perm]} {PERMISSION_LABELS[perm]}
                          </span>
                        </label>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </CardContent>
    </Card>
  );
};

export default UsersList;
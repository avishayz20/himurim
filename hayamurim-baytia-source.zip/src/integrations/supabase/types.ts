export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      bet_presences: {
        Row: {
          created_at: string
          id: string
          match_id: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          match_id: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          match_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "bet_presences_match_id_fkey"
            columns: ["match_id"]
            isOneToOne: false
            referencedRelation: "matches"
            referencedColumns: ["id"]
          },
        ]
      }
      bets: {
        Row: {
          away_score: number
          created_at: string
          home_score: number
          id: string
          match_id: string
          points: number | null
          updated_at: string
          user_id: string
        }
        Insert: {
          away_score: number
          created_at?: string
          home_score: number
          id?: string
          match_id: string
          points?: number | null
          updated_at?: string
          user_id: string
        }
        Update: {
          away_score?: number
          created_at?: string
          home_score?: number
          id?: string
          match_id?: string
          points?: number | null
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "bets_match_id_fkey"
            columns: ["match_id"]
            isOneToOne: false
            referencedRelation: "matches"
            referencedColumns: ["id"]
          },
        ]
      }
      match_reminder_log: {
        Row: {
          id: string
          match_id: string
          offset_minutes: number
          sent_at: string
          user_id: string
        }
        Insert: {
          id?: string
          match_id: string
          offset_minutes: number
          sent_at?: string
          user_id: string
        }
        Update: {
          id?: string
          match_id?: string
          offset_minutes?: number
          sent_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "match_reminder_log_match_id_fkey"
            columns: ["match_id"]
            isOneToOne: false
            referencedRelation: "matches"
            referencedColumns: ["id"]
          },
        ]
      }
      matches: {
        Row: {
          away_crest: string | null
          away_score: number | null
          away_team: string
          created_at: string
          created_by: string | null
          description: string | null
          external_id: string | null
          home_crest: string | null
          home_score: number | null
          home_team: string
          id: string
          is_finished: boolean
          live_away_score: number | null
          live_home_score: number | null
          live_minute: string | null
          live_status: string | null
          live_updated_at: string | null
          match_date: string
          match_time: string | null
          season_id: string | null
          stage_key: string | null
        }
        Insert: {
          away_crest?: string | null
          away_score?: number | null
          away_team: string
          created_at?: string
          created_by?: string | null
          description?: string | null
          external_id?: string | null
          home_crest?: string | null
          home_score?: number | null
          home_team: string
          id?: string
          is_finished?: boolean
          live_away_score?: number | null
          live_home_score?: number | null
          live_minute?: string | null
          live_status?: string | null
          live_updated_at?: string | null
          match_date: string
          match_time?: string | null
          season_id?: string | null
          stage_key?: string | null
        }
        Update: {
          away_crest?: string | null
          away_score?: number | null
          away_team?: string
          created_at?: string
          created_by?: string | null
          description?: string | null
          external_id?: string | null
          home_crest?: string | null
          home_score?: number | null
          home_team?: string
          id?: string
          is_finished?: boolean
          live_away_score?: number | null
          live_home_score?: number | null
          live_minute?: string | null
          live_status?: string | null
          live_updated_at?: string | null
          match_date?: string
          match_time?: string | null
          season_id?: string | null
          stage_key?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "matches_season_id_fkey"
            columns: ["season_id"]
            isOneToOne: false
            referencedRelation: "seasons"
            referencedColumns: ["id"]
          },
        ]
      }
      player_stat_overrides: {
        Row: {
          direction_hits: number
          exact_hits: number
          id: string
          player_name: string
          season_id: string | null
          total_bets: number
          total_points: number
          updated_at: string
          updated_by: string | null
        }
        Insert: {
          direction_hits?: number
          exact_hits?: number
          id?: string
          player_name: string
          season_id?: string | null
          total_bets?: number
          total_points?: number
          updated_at?: string
          updated_by?: string | null
        }
        Update: {
          direction_hits?: number
          exact_hits?: number
          id?: string
          player_name?: string
          season_id?: string | null
          total_bets?: number
          total_points?: number
          updated_at?: string
          updated_by?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "player_stat_overrides_season_id_fkey"
            columns: ["season_id"]
            isOneToOne: false
            referencedRelation: "seasons"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          created_at: string
          display_name: string
          id: string
          is_frozen: boolean
        }
        Insert: {
          created_at?: string
          display_name: string
          id: string
          is_frozen?: boolean
        }
        Update: {
          created_at?: string
          display_name?: string
          id?: string
          is_frozen?: boolean
        }
        Relationships: []
      }
      push_subscriptions: {
        Row: {
          auth: string
          created_at: string
          endpoint: string
          id: string
          last_used_at: string
          p256dh: string
          user_agent: string | null
          user_id: string
        }
        Insert: {
          auth: string
          created_at?: string
          endpoint: string
          id?: string
          last_used_at?: string
          p256dh: string
          user_agent?: string | null
          user_id: string
        }
        Update: {
          auth?: string
          created_at?: string
          endpoint?: string
          id?: string
          last_used_at?: string
          p256dh?: string
          user_agent?: string | null
          user_id?: string
        }
        Relationships: []
      }
      rules: {
        Row: {
          content: string
          emoji: string
          id: string
          section_key: string
          sort_order: number
          title: string
          updated_at: string
        }
        Insert: {
          content: string
          emoji?: string
          id?: string
          section_key: string
          sort_order?: number
          title: string
          updated_at?: string
        }
        Update: {
          content?: string
          emoji?: string
          id?: string
          section_key?: string
          sort_order?: number
          title?: string
          updated_at?: string
        }
        Relationships: []
      }
      season_stage_scoring: {
        Row: {
          created_at: string
          direction_points: number
          exact_points: number
          id: string
          season_id: string
          sort_order: number
          stage_key: string
          stage_label: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          direction_points?: number
          exact_points?: number
          id?: string
          season_id: string
          sort_order?: number
          stage_key: string
          stage_label: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          direction_points?: number
          exact_points?: number
          id?: string
          season_id?: string
          sort_order?: number
          stage_key?: string
          stage_label?: string
          updated_at?: string
        }
        Relationships: []
      }
      seasons: {
        Row: {
          created_by: string | null
          ended_at: string | null
          id: string
          is_active: boolean
          name: string
          started_at: string
        }
        Insert: {
          created_by?: string | null
          ended_at?: string | null
          id?: string
          is_active?: boolean
          name: string
          started_at?: string
        }
        Update: {
          created_by?: string | null
          ended_at?: string | null
          id?: string
          is_active?: boolean
          name?: string
          started_at?: string
        }
        Relationships: []
      }
      special_bet_answers: {
        Row: {
          answer: string
          created_at: string
          id: string
          points: number | null
          special_bet_id: string
          updated_at: string
          user_id: string
        }
        Insert: {
          answer: string
          created_at?: string
          id?: string
          points?: number | null
          special_bet_id: string
          updated_at?: string
          user_id: string
        }
        Update: {
          answer?: string
          created_at?: string
          id?: string
          points?: number | null
          special_bet_id?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "special_bet_answers_special_bet_id_fkey"
            columns: ["special_bet_id"]
            isOneToOne: false
            referencedRelation: "special_bets"
            referencedColumns: ["id"]
          },
        ]
      }
      special_bets: {
        Row: {
          bet_type: string
          correct_answer: string | null
          created_at: string
          created_by: string | null
          deadline: string | null
          id: string
          is_closed: boolean
          is_resolved: boolean
          options: string[] | null
          points_reward: number
          question: string
          season_id: string | null
        }
        Insert: {
          bet_type?: string
          correct_answer?: string | null
          created_at?: string
          created_by?: string | null
          deadline?: string | null
          id?: string
          is_closed?: boolean
          is_resolved?: boolean
          options?: string[] | null
          points_reward?: number
          question: string
          season_id?: string | null
        }
        Update: {
          bet_type?: string
          correct_answer?: string | null
          created_at?: string
          created_by?: string | null
          deadline?: string | null
          id?: string
          is_closed?: boolean
          is_resolved?: boolean
          options?: string[] | null
          points_reward?: number
          question?: string
          season_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "special_bets_season_id_fkey"
            columns: ["season_id"]
            isOneToOne: false
            referencedRelation: "seasons"
            referencedColumns: ["id"]
          },
        ]
      }
      user_permissions: {
        Row: {
          id: string
          permission: Database["public"]["Enums"]["app_permission"]
          user_id: string
        }
        Insert: {
          id?: string
          permission: Database["public"]["Enums"]["app_permission"]
          user_id: string
        }
        Update: {
          id?: string
          permission?: Database["public"]["Enums"]["app_permission"]
          user_id?: string
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      assign_monkey_bets: { Args: { p_match_id: string }; Returns: number }
      delete_season_cascade: {
        Args: { p_season_id: string }
        Returns: undefined
      }
      generate_monkey_bet: { Args: { p_match_id: string }; Returns: undefined }
      generate_monkey_special_bets: {
        Args: { p_special_bet_id: string }
        Returns: undefined
      }
      has_permission: {
        Args: {
          _permission: Database["public"]["Enums"]["app_permission"]
          _user_id: string
        }
        Returns: boolean
      }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
    }
    Enums: {
      app_permission:
        | "manage_matches"
        | "manage_results"
        | "manage_special_bets"
        | "manage_rules"
        | "manage_tournaments"
      app_role: "admin" | "user"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_permission: [
        "manage_matches",
        "manage_results",
        "manage_special_bets",
        "manage_rules",
        "manage_tournaments",
      ],
      app_role: ["admin", "user"],
    },
  },
} as const

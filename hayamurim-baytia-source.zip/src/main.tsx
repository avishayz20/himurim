import { createRoot } from "react-dom/client";
import App from "./App.tsx";
import "./index.css";

// Register the service worker (PWA + Web Push). Skip inside iframes / Lovable
// preview hosts to avoid stale caching during in-editor development.
const isInIframe = (() => {
  try {
    return window.self !== window.top;
  } catch {
    return true;
  }
})();
const isPreviewHost =
  window.location.hostname.includes("id-preview--") ||
  window.location.hostname.includes("lovableproject.com");

if ("serviceWorker" in navigator) {
  if (isInIframe || isPreviewHost) {
    // Cleanup any leftover SW registrations in preview contexts
    navigator.serviceWorker.getRegistrations().then((regs) => {
      regs.forEach((r) => r.unregister());
    });
  } else {
    window.addEventListener("load", () => {
      import("virtual:pwa-register").then(({ registerSW }) => {
        registerSW({ immediate: true, onNeedRefresh: () => window.location.reload() });
      });
    });
  }
}

// Self-heal: if a stale service-worker cache serves an old asset manifest the app
// fails to boot (blank screen). Detect it, wipe caches + SW, and reload once.
const RECOVER_KEY = "sw-recovered-at";
const recover = async (reason: string) => {
  const last = Number(sessionStorage.getItem(RECOVER_KEY) || 0);
  if (Date.now() - last < 60000) return; // avoid reload loops
  sessionStorage.setItem(RECOVER_KEY, String(Date.now()));
  console.warn("Recovering from stale cache:", reason);
  try {
    if ("caches" in window) {
      const keys = await caches.keys();
      await Promise.all(keys.map((k) => caches.delete(k)));
    }
    if ("serviceWorker" in navigator) {
      const regs = await navigator.serviceWorker.getRegistrations();
      await Promise.all(regs.map((r) => r.unregister()));
    }
  } catch {
    /* ignore */
  }
  window.location.reload();
};

window.addEventListener("error", (e) => {
  const target = e.target as HTMLElement | null;
  if (target && (target.tagName === "SCRIPT" || target.tagName === "LINK")) {
    recover("asset failed to load");
  }
}, true);

window.addEventListener("unhandledrejection", (e) => {
  const msg = String((e.reason as { message?: string })?.message || e.reason || "");
  if (/dynamically imported module|Importing a module script failed|Failed to fetch dynamically/i.test(msg)) {
    recover("dynamic import failed");
  }
});

createRoot(document.getElementById("root")!).render(<App />);


import { useState, useEffect, useCallback } from "react";
import { supabase } from "@/integrations/supabase/client";

export type AppPermission = 
  | "manage_matches"
  | "manage_results"
  | "manage_special_bets"
  | "manage_rules"
  | "manage_tournaments";

export const PERMISSION_LABELS: Record<AppPermission, string> = {
  manage_matches: "ניהול משחקים",
  manage_results: "עדכון תוצאות",
  manage_special_bets: "הימורים מיוחדים",
  manage_rules: "עריכת חוקים",
  manage_tournaments: "ניהול טורנירים",
};

export const PERMISSION_ICONS: Record<AppPermission, string> = {
  manage_matches: "⚽",
  manage_results: "📊",
  manage_special_bets: "⭐",
  manage_rules: "📜",
  manage_tournaments: "🏆",
};

export const ALL_PERMISSIONS: AppPermission[] = [
  "manage_matches",
  "manage_results",
  "manage_special_bets",
  "manage_rules",
  "manage_tournaments",
];

export function usePermissions(userId: string | undefined, isAdmin: boolean) {
  const [permissions, setPermissions] = useState<Set<AppPermission>>(new Set());

  const fetchPermissions = useCallback(async () => {
    if (!userId) return;
    if (isAdmin) {
      setPermissions(new Set(ALL_PERMISSIONS));
      return;
    }
    const { data } = await supabase
      .from("user_permissions")
      .select("permission")
      .eq("user_id", userId);
    if (data) {
      setPermissions(new Set(data.map((d: any) => d.permission as AppPermission)));
    }
  }, [userId, isAdmin]);

  useEffect(() => { fetchPermissions(); }, [fetchPermissions]);

  const hasPermission = (perm: AppPermission) => isAdmin || permissions.has(perm);

  return { permissions, hasPermission, refetch: fetchPermissions };
}

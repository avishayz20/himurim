import { useEffect, useRef } from "react";

interface ReminderMatch {
  id: string;
  home_team: string;
  away_team: string;
  match_date: string;
  match_time: string | null;
  is_finished: boolean;
}

interface ReminderBet {
  match_id: string;
  user_id: string;
}

interface UseMatchRemindersOptions {
  matches: ReminderMatch[];
  bets: ReminderBet[];
  currentUserId: string | undefined;
}

const israelNowFormatter = new Intl.DateTimeFormat("en-CA", {
  timeZone: "Asia/Jerusalem",
  year: "numeric",
  month: "2-digit",
  day: "2-digit",
  hour: "2-digit",
  minute: "2-digit",
  second: "2-digit",
  hourCycle: "h23",
});

const getIsraelNowMs = () => {
  const parts = Object.fromEntries(
    israelNowFormatter
      .formatToParts(new Date())
      .filter((p) => p.type !== "literal")
      .map((p) => [p.type, p.value]),
  );
  return Date.UTC(
    Number(parts.year),
    Number(parts.month) - 1,
    Number(parts.day),
    Number(parts.hour),
    Number(parts.minute),
    Number(parts.second),
  );
};

const getKickoffMs = (m: ReminderMatch): number | null => {
  if (!m.match_date || !m.match_time) return null;
  const [y, mo, d] = m.match_date.split("-").map(Number);
  const [h, mi] = m.match_time.slice(0, 5).split(":").map(Number);
  return Date.UTC(y, mo - 1, d, h, mi, 0);
};

const STORAGE_KEY = "match_reminders_sent_v1";
const REMINDER_OFFSETS = [60, 10] as const; // minutes before kickoff

const loadSent = (): Set<string> => {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return new Set();
    const arr = JSON.parse(raw) as string[];
    return new Set(arr);
  } catch {
    return new Set();
  }
};

const saveSent = (s: Set<string>) => {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(Array.from(s).slice(-500)));
  } catch {
    /* noop */
  }
};

const showNotification = (title: string, body: string, tag: string) => {
  if (typeof window === "undefined") return;
  if (!("Notification" in window)) return;
  if (Notification.permission !== "granted") return;
  try {
    const n = new Notification(title, {
      body,
      tag,
      icon: "/favicon.ico",
      badge: "/favicon.ico",
    });
    n.onclick = () => {
      window.focus();
      n.close();
    };
  } catch {
    /* noop */
  }
};

export const useMatchReminders = ({ matches, bets, currentUserId }: UseMatchRemindersOptions) => {
  const sentRef = useRef<Set<string>>(loadSent());

  useEffect(() => {
    if (!currentUserId) return;
    if (typeof window === "undefined" || !("Notification" in window)) return;

    const tick = () => {
      if (Notification.permission !== "granted") return;
      const nowMs = getIsraelNowMs();
      const sent = sentRef.current;
      let dirty = false;

      for (const match of matches) {
        if (match.is_finished) continue;
        const kickoff = getKickoffMs(match);
        if (kickoff === null) continue;

        // Skip if user already bet
        const userBet = bets.find((b) => b.match_id === match.id && b.user_id === currentUserId);
        if (userBet) continue;

        for (const offset of REMINDER_OFFSETS) {
          const targetMs = kickoff - offset * 60 * 1000;
          const diff = targetMs - nowMs;
          // Fire if we're within the window: target reached, but not more than 90 seconds late
          if (diff <= 0 && diff > -90 * 1000) {
            const key = `${match.id}:${offset}`;
            if (sent.has(key)) continue;
            const label =
              offset === 60 ? "המשחק מתחיל בעוד שעה" : "המשחק מתחיל בעוד 10 דקות";
            showNotification(
              "⚽ עוד לא הימרת!",
              `${label}: ${match.home_team} נגד ${match.away_team}`,
              key,
            );
            sent.add(key);
            dirty = true;
          }
        }
      }

      if (dirty) saveSent(sent);
    };

    tick();
    const interval = setInterval(tick, 30 * 1000);
    return () => clearInterval(interval);
  }, [matches, bets, currentUserId]);
};
